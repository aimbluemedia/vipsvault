<?php
if(!defined('ABSPATH')) exit;

function vipsvault_setup(){
    add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('custom-logo'); add_theme_support('align-wide'); add_theme_support('editor-styles');
    register_nav_menus(array(
        'primary' => 'Header Navigation',
        'footer'  => 'Footer Navigation'
    ));
}
add_action('after_setup_theme','vipsvault_setup');

function vipsvault_assets(){ wp_enqueue_style('vipsvault-style', get_stylesheet_uri(), array(), '2.0'); }
add_action('wp_enqueue_scripts','vipsvault_assets');

function vipsvault_register_types(){
    register_post_type('vip_collectible', array(
        'labels'=>array('name'=>'VIP Collectibles','singular_name'=>'VIP Collectible','add_new_item'=>'Add Collectible'),
        'public'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'collectibles'),'menu_icon'=>'dashicons-vault',
        'supports'=>array('title','editor','excerpt','thumbnail'),'show_in_rest'=>true
    ));
    register_taxonomy('collectible_category','vip_collectible',array('labels'=>array('name'=>'Collectible Categories'),'public'=>true,'hierarchical'=>true,'rewrite'=>array('slug'=>'collectible-category'),'show_in_rest'=>true));
    register_taxonomy('collectible_tag','vip_collectible',array('labels'=>array('name'=>'Collectible Tags'),'public'=>true,'hierarchical'=>false,'rewrite'=>array('slug'=>'collectible-tag'),'show_in_rest'=>true));

    register_post_type('vip', array(
        'labels'=>array('name'=>'VIPS','singular_name'=>'VIP','add_new_item'=>'Add VIP','edit_item'=>'Edit VIP'),
        'public'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'vips'),'menu_icon'=>'dashicons-star-filled',
        'supports'=>array('title','editor','excerpt','thumbnail'),'show_in_rest'=>true
    ));
    register_taxonomy('vip_category','vip',array(
        'labels'=>array('name'=>'VIP Categories','singular_name'=>'VIP Category'),
        'public'=>true,'hierarchical'=>true,'rewrite'=>array('slug'=>'vips/category'),'show_in_rest'=>true
    ));
    register_post_type('vip_career', array(
        'labels'=>array('name'=>'VIP Career Items','singular_name'=>'VIP Career Item','add_new_item'=>'Add Career Item','edit_item'=>'Edit Career Item'),
        'public'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'vip-career'),'menu_icon'=>'dashicons-awards',
        'supports'=>array('title','editor','excerpt','thumbnail'),'show_in_rest'=>true
    ));
}
add_action('init','vipsvault_register_types');

function vipsvault_default_terms(){
    foreach(array('Baseball','Football','Basketball','Hockey','Golf','Movies','TV','Music') as $t){ if(!term_exists($t,'vip_category')) wp_insert_term($t,'vip_category'); }
    foreach(array('Sports','Celebrities','Music','Movies & TV','Autographs','Memorabilia','Rookie Cards','Graded Cards') as $t){ if(!term_exists($t,'collectible_category')) wp_insert_term($t,'collectible_category'); }
}
add_action('init','vipsvault_default_terms',20);

function vipsvault_add_meta_boxes(){
    add_meta_box('vv_card_details','Collectible Details','vipsvault_card_meta_box','vip_collectible','normal','high');
    add_meta_box('vv_vip_details','VIP Wiki Details','vipsvault_vip_meta_box','vip','normal','high');
    add_meta_box('vv_career_details','Career Item Details','vipsvault_career_meta_box','vip_career','normal','high');
}
add_action('add_meta_boxes','vipsvault_add_meta_boxes');

function vipsvault_input($key,$label,$type='text',$textarea=false){
    $value=get_post_meta(get_the_ID(),$key,true);
    echo '<p><label for="'.$key.'"><strong>'.esc_html($label).'</strong></label><br>';
    if($textarea) echo '<textarea style="width:100%;min-height:90px" id="'.$key.'" name="'.$key.'">'.esc_textarea($value).'</textarea>';
    else echo '<input style="width:100%" type="'.esc_attr($type).'" id="'.$key.'" name="'.$key.'" value="'.esc_attr($value).'">';
    echo '</p>';
}
function vipsvault_card_meta_box(){ wp_nonce_field('vv_save','vv_nonce'); foreach(array('_vv_person_name'=>'Player / Celebrity Name','_vv_profession'=>'Sport / Profession','_vv_team_role'=>'Team / Movie / Show / Band / Role','_vv_year'=>'Year','_vv_brand'=>'Brand / Set','_vv_card_number'=>'Card Number','_vv_condition'=>'Condition','_vv_grade'=>'Grade','_vv_price'=>'Asking Price','_vv_marketplace_url'=>'Marketplace URL','_vv_related_vip'=>'Related VIP Slug, example: jack-nicholson') as $k=>$l) vipsvault_input($k,$l); vipsvault_input('_vv_ebay_shortcode','eBay Plugin Shortcode / Embed Code','text',true); }

function vipsvault_decode_unicode_escapes($value){
    $value = (string)$value;
    if(strpos($value, '\\u') === false) return $value;
    $decoded = json_decode('"' . str_replace('"', '\\"', $value) . '"');
    return is_string($decoded) ? $decoded : $value;
}
function vipsvault_clean_repeater_text($value, $type = 'text'){
    $value = vipsvault_decode_unicode_escapes(wp_unslash((string)$value));
    $value = str_replace(array("
", "
"), "
", $value);
    if($type === 'url') return esc_url_raw(trim($value));
    if($type === 'textarea') return wp_kses_post($value);
    return sanitize_text_field($value);
}
function vipsvault_prepare_repeater_summary($summary){
    $summary = vipsvault_decode_unicode_escapes((string)$summary);
    $summary = str_replace(array("
", "
"), "
", $summary);
    // If the user pasted a one-line structured description with pipes, show each part on a separate line.
    if(strpos($summary, ' | ') !== false && strpos($summary, "
") === false){
        $summary = str_replace(' | ', "
", $summary);
    }
    return $summary;
}
function vipsvault_normalize_repeater_items($items){
    if(!is_array($items)) return array();
    $clean = array();
    foreach($items as $item){
        if(!is_array($item)) continue;
        $title = isset($item['title']) ? vipsvault_decode_unicode_escapes((string)$item['title']) : '';
        $summary = isset($item['summary']) ? vipsvault_prepare_repeater_summary((string)$item['summary']) : '';
        $api = isset($item['api']) ? vipsvault_decode_unicode_escapes((string)$item['api']) : '';
        if($title !== '' || $summary !== '' || $api !== '') $clean[] = array('title'=>$title, 'summary'=>$summary, 'api'=>$api);
    }
    return $clean;
}
function vipsvault_get_repeater_items($post_id, $key){
    $raw = get_post_meta($post_id, $key, true);
    if(is_array($raw)) return vipsvault_normalize_repeater_items($raw);
    $raw_string = (string)$raw;
    $items = json_decode($raw_string, true);
    if(!is_array($items)) $items = json_decode(wp_unslash($raw_string), true);
    if(!is_array($items)) $items = json_decode(html_entity_decode($raw_string, ENT_QUOTES, get_bloginfo('charset')), true);
    if(!is_array($items)) return array();
    return vipsvault_normalize_repeater_items($items);
}
function vipsvault_vip_repeater_field($key,$label){
    $items=vipsvault_get_repeater_items(get_the_ID(), $key);
    $third_label = ($key === '_vip_news') ? 'URL' : 'Memorabilia API Code';
    $third_type  = ($key === '_vip_news') ? 'url' : 'textarea';
    echo '<div class="vv-repeater" data-key="'.esc_attr($key).'"><h3>'.esc_html($label).'</h3><p><button type="button" class="button button-primary vv-add-row">Create</button></p><div class="vv-rows">';
    foreach($items as $i=>$item){
        $title=isset($item['title'])?$item['title']:''; $summary=isset($item['summary'])?$item['summary']:''; $api=isset($item['api'])?$item['api']:'';
        $display_title = $title ? $title : 'Untitled Entry';
        echo '<div class="vv-row vv-row-collapsed" style="border:1px solid #ccd0d4;margin:10px 0;background:#fff">';
        echo '<div class="vv-row-summary" style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;background:#f6f7f7">';
        echo '<strong class="vv-row-title">'.esc_html($display_title).'</strong><span><button type="button" class="button vv-edit-row">Edit</button> <button type="button" class="button vv-remove-row">Delete</button></span></div>';
        echo '<div class="vv-row-body" style="display:none;padding:12px"><p><label><strong>Title</strong></label><br><input class="vv-title-input" style="width:100%" name="'.esc_attr($key).'['.$i.'][title]" value="'.esc_attr($title).'"></p><p><label><strong>Summary</strong></label><br><textarea style="width:100%;min-height:80px" name="'.esc_attr($key).'['.$i.'][summary]">'.esc_textarea($summary).'</textarea></p><p><label><strong>'.esc_html($third_label).'</strong></label><br>';
        if($third_type === 'url') echo '<input type="url" style="width:100%" name="'.esc_attr($key).'['.$i.'][api]" value="'.esc_url($api).'" placeholder="https://example.com">';
        else echo '<textarea style="width:100%;min-height:80px" name="'.esc_attr($key).'['.$i.'][api]">'.esc_textarea($api).'</textarea>';
        echo '</p></div></div>';
    }
    echo '</div><template class="vv-template"><div class="vv-row" style="border:1px solid #ccd0d4;margin:10px 0;background:#fff"><div class="vv-row-summary" style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 12px;background:#f6f7f7"><strong class="vv-row-title">New Entry</strong><span><button type="button" class="button vv-edit-row">Collapse</button> <button type="button" class="button vv-remove-row">Delete</button></span></div><div class="vv-row-body" style="padding:12px"><p><label><strong>Title</strong></label><br><input class="vv-title-input" style="width:100%" data-name="title"></p><p><label><strong>Summary</strong></label><br><textarea style="width:100%;min-height:80px" data-name="summary"></textarea></p><p><label><strong>'.esc_html($third_label).'</strong></label><br>';
    if($third_type === 'url') echo '<input type="url" style="width:100%" data-name="api" placeholder="https://example.com">';
    else echo '<textarea style="width:100%;min-height:80px" data-name="api"></textarea>';
    echo '</p></div></div></template></div>';
}

function vipsvault_vip_meta_box(){ wp_nonce_field('vv_save','vv_nonce');
    vipsvault_input('_vip_full_name','Full Name');
    vipsvault_input('_vip_real_name','Real Name');
    vipsvault_input('_vip_birth','Born','date');
    vipsvault_input('_vip_died','Died','date');
    foreach(array('_vip_birthplace'=>'Birthplace','_vip_profession'=>'Profession / Position','_vip_active_years'=>'Active Years') as $k=>$l) vipsvault_input($k,$l);
    vipsvault_input('_vip_ebay_keywords_top','Top eBay Memorabilia Keywords or Shortcode');
    vipsvault_input('_vip_ebay_keywords_bottom','Bottom eBay Memorabilia Keywords or Shortcode');
    vipsvault_input('_vip_ebay_item_count','eBay Item Count (1-20)','number');
    vipsvault_input('_vip_bio','Bio Section','text',true);
    vipsvault_vip_repeater_field('_vip_accomplishments','Accomplishments');
    vipsvault_vip_repeater_field('_vip_news','News');
    echo '<script>
    function vvReindexRows(wrap){
      if(!wrap) return;
      const key = wrap.dataset.key;
      wrap.querySelectorAll(".vv-rows .vv-row").forEach(function(row, index){
        row.querySelectorAll("[data-name], input[name], textarea[name]").forEach(function(el){
          const field = el.dataset.name || ((el.name.match(/\[([^\]]+)\]$/)||[])[1]);
          if(field) el.name = key + "[" + index + "][" + field + "]";
        });
      });
    }
    document.addEventListener("click", function(e){
      if(e.target.classList.contains("vv-add-row")){
        const wrap=e.target.closest(".vv-repeater"); const rows=wrap.querySelector(".vv-rows"); const node=wrap.querySelector(".vv-template").content.cloneNode(true);
        rows.appendChild(node); vvReindexRows(wrap);
      }
      if(e.target.classList.contains("vv-edit-row")){
        const row=e.target.closest(".vv-row"); const body=row.querySelector(".vv-row-body"); const visible=body.style.display!=="none";
        body.style.display=visible?"none":"block"; e.target.textContent=visible?"Edit":"Collapse";
      }
      if(e.target.classList.contains("vv-remove-row")){
        if(confirm("Delete this entry?")){ const wrap=e.target.closest(".vv-repeater"); e.target.closest(".vv-row").remove(); vvReindexRows(wrap); }
      }
    });
    document.addEventListener("input", function(e){
      if(e.target.classList.contains("vv-title-input")){
        const row=e.target.closest(".vv-row"); const title=row.querySelector(".vv-row-title"); title.textContent=e.target.value || "Untitled Entry";
      }
    });
    document.querySelectorAll(".vv-repeater").forEach(vvReindexRows);
    </script>';

}
function vipsvault_career_meta_box(){ wp_nonce_field('vv_save','vv_nonce');
    vipsvault_input('_career_year','Year / Season'); vipsvault_input('_career_type','Type: Movie, TV Show, Album, Team, Event'); vipsvault_input('_career_role','Role / Team / Credit'); vipsvault_input('_career_vip_slug','Related VIP Slug, example: jack-nicholson'); vipsvault_input('_career_summary','Summary','text',true); vipsvault_input('_career_memorabilia','Career Item Memorabilia API Shortcode / Embed','text',true);
}
function vipsvault_normalize_date($date){
    $date = trim((string)$date);
    if($date === '') return '';
    $formats = array('Y-m-d','m/d/Y','n/j/Y','m-d-Y','n-j-Y','F j, Y','M j, Y');
    foreach($formats as $format){
        $dt = DateTime::createFromFormat($format, $date);
        if($dt instanceof DateTime) return $dt->format('Y-m-d');
    }
    $timestamp = strtotime($date);
    return $timestamp ? date('Y-m-d', $timestamp) : sanitize_text_field($date);
}
function vipsvault_format_vip_date($date){
    $date = trim((string)$date);
    if($date === '') return '';
    $timestamp = strtotime($date);
    return $timestamp ? date_i18n('F j, Y', $timestamp) : $date;
}
function vipsvault_save_meta($post_id){
    if(!isset($_POST['vv_nonce']) || !wp_verify_nonce($_POST['vv_nonce'],'vv_save') || defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    $keys=array('_vv_person_name','_vv_profession','_vv_team_role','_vv_year','_vv_brand','_vv_card_number','_vv_condition','_vv_grade','_vv_price','_vv_marketplace_url','_vv_related_vip','_vv_ebay_shortcode','_vip_full_name','_vip_real_name','_vip_birth','_vip_died','_vip_birthplace','_vip_profession','_vip_active_years','_vip_ebay_keywords_top','_vip_ebay_keywords_bottom','_vip_ebay_item_count','_vip_bio','_career_year','_career_type','_career_role','_career_vip_slug','_career_summary','_career_memorabilia');
    foreach($keys as $key){ if(isset($_POST[$key])){ if(in_array($key,array('_vip_birth','_vip_died'), true)) { $val = vipsvault_normalize_date(wp_unslash($_POST[$key])); } else { $raw_value = vipsvault_decode_unicode_escapes(wp_unslash($_POST[$key])); $val=in_array($key,array('_vv_ebay_shortcode','_vip_ebay_keywords_top','_vip_ebay_keywords_bottom','_vip_ebay_item_count','_vip_bio','_career_summary','_career_memorabilia'), true) ? wp_kses_post($raw_value) : sanitize_text_field($raw_value); } update_post_meta($post_id,$key,$val); }}
    foreach(array('_vip_accomplishments','_vip_news') as $rkey){
        $clean=array();
        if(isset($_POST[$rkey]) && is_array($_POST[$rkey])){
            foreach($_POST[$rkey] as $row){
                $title=isset($row['title']) ? vipsvault_clean_repeater_text($row['title'], 'text') : '';
                $summary=isset($row['summary']) ? vipsvault_clean_repeater_text($row['summary'], 'textarea') : '';
                $api=isset($row['api']) ? ($rkey === '_vip_news' ? vipsvault_clean_repeater_text($row['api'], 'url') : vipsvault_clean_repeater_text($row['api'], 'textarea')) : '';
                if($title || $summary || $api) $clean[]=array('title'=>$title,'summary'=>vipsvault_prepare_repeater_summary($summary),'api'=>$api);
            }
        }
        update_post_meta($post_id,$rkey, $clean);
    }
}
add_action('save_post','vipsvault_save_meta');

function vv_meta($key){ return get_post_meta(get_the_ID(),$key,true); }
function vv_api_box($title,$content){ if(!$content) return; echo '<section class="api-box"><h2>'.esc_html($title).'</h2><div class="api-embed">'.do_shortcode(wp_kses_post($content)).'</div></section>'; }
function vv_repeater_section($title,$key){ $items=vipsvault_get_repeater_items(get_the_ID(), $key); if(!is_array($items) || empty($items)) return; echo '<section class="wiki-section"><h2>'.esc_html($title).'</h2><div class="vv-info-list">'; foreach($items as $item){ echo '<div class="vv-info-card"><h3>'.esc_html($item['title'] ?? '').'</h3><div class="content-box">'.wpautop(wp_kses_post($item['summary'] ?? '')).'</div>'; if(!empty($item['api'])){ if($key === '_vip_news'){ echo '<p><a class="btn btn-primary vv-news-more" href="'.esc_url($item['api']).'" target="_blank" rel="noopener nofollow">View More</a></p>'; } else { echo '<div class="api-embed mini-api">'.do_shortcode(wp_kses_post($item['api'])).'</div>'; } } echo '</div>'; } echo '</div></section>'; }

function vipsvault_price_number($price){
    return floatval(preg_replace('/[^0-9.]/','',$price));
}

function vipsvault_collectible_search_form(){
    $q = isset($_GET['vvq']) ? sanitize_text_field(wp_unslash($_GET['vvq'])) : '';
    $cat = isset($_GET['vvcat']) ? sanitize_text_field(wp_unslash($_GET['vvcat'])) : '';
    $sort = isset($_GET['vvsort']) ? sanitize_text_field(wp_unslash($_GET['vvsort'])) : 'newest';
    echo '<form class="filter-bar vv-search-filters vv-collectibles-clean-filter" method="get" action="'.esc_url(get_post_type_archive_link('vip_collectible')).'">';
    echo '<input type="search" name="vvq" value="'.esc_attr($q).'" placeholder="Search name, team, movie, artist, brand, year...">';
    echo '<select name="vvcat"><option value="">All Collectible Categories</option>';
    $terms = get_terms(array('taxonomy'=>'collectible_category','hide_empty'=>false));
    if(!is_wp_error($terms)){ foreach($terms as $term){ echo '<option value="'.esc_attr($term->slug).'" '.selected($cat,$term->slug,false).'>'.esc_html($term->name).'</option>'; }}
    echo '</select>';
    echo '<select name="vvsort">';
    foreach(array('newest'=>'Newest','oldest'=>'Oldest','az'=>'A-Z','za'=>'Z-A','price_high'=>'Highest Price','price_low'=>'Lowest Price') as $value=>$label){ echo '<option value="'.esc_attr($value).'" '.selected($sort,$value,false).'>'.esc_html($label).'</option>'; }
    echo '</select><button class="btn btn-primary" type="submit">Search Collectibles</button><a class="btn btn-secondary" href="'.esc_url(get_post_type_archive_link('vip_collectible')).'">Reset</a></form>';
}

function vipsvault_header_search_form(){
    echo '<form class="header-search" method="get" action="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'"><input type="search" name="vvq" placeholder="Search VIPS" value="'.esc_attr(isset($_GET['vvq']) ? sanitize_text_field(wp_unslash($_GET['vvq'])) : '').'"><button type="submit">Search</button></form>';
}


function vipsvault_vip_search_form(){
    $q = isset($_GET['vvq']) ? sanitize_text_field(wp_unslash($_GET['vvq'])) : '';
    $cat = isset($_GET['vipcat']) ? sanitize_text_field(wp_unslash($_GET['vipcat'])) : '';
    $sort = isset($_GET['vipsort']) ? sanitize_text_field(wp_unslash($_GET['vipsort'])) : 'newest';
    echo '<form class="filter-bar vv-search-filters vip-search-filters" method="get" action="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">';
    echo '<input type="search" name="vvq" value="'.esc_attr($q).'" placeholder="Search VIP name, movie, team, profession, keyword...">';
    echo '<select name="vipcat"><option value="">All VIP Categories</option>';
    $terms = get_terms(array('taxonomy'=>'vip_category','hide_empty'=>false));
    if(!is_wp_error($terms)){ foreach($terms as $term){ echo '<option value="'.esc_attr($term->slug).'" '.selected($cat,$term->slug,false).'>'.esc_html($term->name).'</option>'; }}
    echo '</select>';
    echo '<select name="vipsort">';
    foreach(array('newest'=>'Newest','oldest'=>'Oldest','az'=>'A-Z','za'=>'Z-A') as $value=>$label){ echo '<option value="'.esc_attr($value).'" '.selected($sort,$value,false).'>'.esc_html($label).'</option>'; }
    echo '</select><button class="btn btn-primary" type="submit">Search VIPS</button><a class="btn btn-secondary" href="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">Reset</a></form>';
}

function vipsvault_filter_vips_query($query){
    if(is_admin() || !$query->is_main_query()) return;
    if(is_post_type_archive('vip') || is_tax('vip_category') || (isset($_GET['post_type']) && $_GET['post_type']==='vip')){
        $query->set('posts_per_page', 12);
        if(!empty($_GET['vvq'])){
            $query->set('_vip_custom_search', sanitize_text_field(wp_unslash($_GET['vvq'])));
        }
        $tax_query = array();
        if(!empty($_GET['vipcat'])){
            $tax_query[] = array('taxonomy'=>'vip_category','field'=>'slug','terms'=>sanitize_text_field(wp_unslash($_GET['vipcat'])));
        }
        if($tax_query) $query->set('tax_query', $tax_query);
        $sort = !empty($_GET['vipsort']) ? sanitize_text_field(wp_unslash($_GET['vipsort'])) : 'newest';
        if($sort==='oldest'){ $query->set('orderby','date'); $query->set('order','ASC'); }
        elseif($sort==='az'){ $query->set('orderby','title'); $query->set('order','ASC'); }
        elseif($sort==='za'){ $query->set('orderby','title'); $query->set('order','DESC'); }
        else { $query->set('orderby','date'); $query->set('order','DESC'); }
    }
}
add_action('pre_get_posts','vipsvault_filter_vips_query');

function vipsvault_filter_collectibles_query($query){
    if(is_admin() || !$query->is_main_query()) return;
    if(is_post_type_archive('vip_collectible') || (isset($_GET['post_type']) && $_GET['post_type']==='vip_collectible')){
        $query->set('posts_per_page', 12);
        if(!empty($_GET['vvq'])){
            $query->set('_vv_custom_search', sanitize_text_field(wp_unslash($_GET['vvq'])));
        }
        $tax_query = array();
        if(!empty($_GET['vvcat'])){
            $tax_query[] = array('taxonomy'=>'collectible_category','field'=>'slug','terms'=>sanitize_text_field(wp_unslash($_GET['vvcat'])));
        }
        if($tax_query) $query->set('tax_query', $tax_query);
        $sort = !empty($_GET['vvsort']) ? sanitize_text_field(wp_unslash($_GET['vvsort'])) : 'newest';
        if($sort==='oldest'){ $query->set('orderby','date'); $query->set('order','ASC'); }
        elseif($sort==='az'){ $query->set('orderby','title'); $query->set('order','ASC'); }
        elseif($sort==='za'){ $query->set('orderby','title'); $query->set('order','DESC'); }
        elseif($sort==='price_high' || $sort==='price_low'){ $query->set('meta_key','_vv_price'); $query->set('orderby','meta_value_num'); $query->set('order',$sort==='price_high'?'DESC':'ASC'); }
        else { $query->set('orderby','date'); $query->set('order','DESC'); }
    }
}
add_action('pre_get_posts','vipsvault_filter_collectibles_query');

function vipsvault_collectible_search_join($join, $query){
    global $wpdb;
    if($query->get('_vv_custom_search') || $query->get('_vip_custom_search')){
        $join .= " LEFT JOIN {$wpdb->postmeta} vvsearchmeta ON ({$wpdb->posts}.ID = vvsearchmeta.post_id) ";
    }
    return $join;
}
add_filter('posts_join','vipsvault_collectible_search_join',10,2);
function vipsvault_collectible_search_where($where, $query){
    global $wpdb;
    $term = $query->get('_vv_custom_search') ?: $query->get('_vip_custom_search');
    if($term){
        $like = '%' . $wpdb->esc_like($term) . '%';
        $where .= $wpdb->prepare(" AND ({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_content LIKE %s OR vvsearchmeta.meta_value LIKE %s)", $like, $like, $like);
    }
    return $where;
}
add_filter('posts_where','vipsvault_collectible_search_where',10,2);
function vipsvault_collectible_search_groupby($groupby, $query){
    global $wpdb;
    if($query->get('_vv_custom_search') || $query->get('_vip_custom_search')) return "{$wpdb->posts}.ID";
    return $groupby;
}
add_filter('posts_groupby','vipsvault_collectible_search_groupby',10,2);


function vipsvault_related_collectibles($vip_id=null){
    if(!$vip_id) $vip_id = get_the_ID();
    $slug = get_post_field('post_name', $vip_id);
    $name = get_post_meta($vip_id,'_vip_full_name',true) ?: get_the_title($vip_id);
    $args = array(
        'post_type'=>'vip_collectible',
        'posts_per_page'=>8,
        'meta_query'=>array('relation'=>'OR', array('key'=>'_vv_related_vip','value'=>$slug,'compare'=>'='), array('key'=>'_vv_person_name','value'=>$name,'compare'=>'LIKE')),
    );
    $related = new WP_Query($args);
    echo '<section id="related-collectibles" class="wiki-section related-collectibles"><h2>Related Collectibles</h2><p class="meta-line">Cards and memorabilia connected to this VIP. Add the VIP slug to a collectible using the Related VIP Slug field.</p>';
    if($related->have_posts()){ echo '<div class="card-grid">'; while($related->have_posts()){ $related->the_post(); get_template_part('template-parts/collectible-card'); } echo '</div>'; wp_reset_postdata(); }
    else { echo '<div class="api-embed">No related collectibles yet. Edit a collectible and add <strong>'.esc_html($slug).'</strong> in the Related VIP Slug field.</div>'; }
    echo '</section>';
}


function vipsvault_demo_content(){
    if(get_option('vipsvault_vips_demo_imported')) return; vipsvault_default_terms();
    $home=get_page_by_title('VIPSVault Home'); if(!$home){ $hero='<!-- wp:group {"className":"vv-hero-edit"} --><div class="wp-block-group vv-hero-edit"><!-- wp:columns {"verticalAlignment":"center","className":"vv-hero-columns"} --><div class="wp-block-columns are-vertically-aligned-center vv-hero-columns"><!-- wp:column {"width":"45%","className":"vv-hero-image"} --><div class="wp-block-column vv-hero-image" style="flex-basis:45%"><!-- wp:image --><figure class="wp-block-image"><img src="'.esc_url(get_template_directory_uri().'/assets/vipsvault-logo.png').'" alt="VIPSVault logo vault image"/></figure><!-- /wp:image --></div><!-- /wp:column --><!-- wp:column {"width":"55%","className":"vv-hero-copy"} --><div class="wp-block-column vv-hero-copy" style="flex-basis:55%"><!-- wp:paragraph {"className":"kicker"} --><p class="kicker">The Vault for Iconic Collectibles</p><!-- /wp:paragraph --><!-- wp:heading {"level":1} --><h1>Rare cards. Famous names. One powerful vault.</h1><!-- /wp:heading --><!-- wp:paragraph --><p>VIPSVault.com showcases sports cards, celebrity cards, music legends, movie icons, autographs, graded collectibles, and memorabilia with a premium visual experience built to get attention.</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"className":"btn-primary"} --><div class="wp-block-button btn-primary"><a class="wp-block-button__link wp-element-button" href="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">Explore VIPS</a></div><!-- /wp:button --><!-- wp:button {"className":"btn-secondary"} --><div class="wp-block-button btn-secondary"><a class="wp-block-button__link wp-element-button" href="'.esc_url(admin_url('post-new.php?post_type=vip_collectible')).'">Add Collectible</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:column --></div><!-- /wp:columns --></div><!-- /wp:group -->'; $id=wp_insert_post(array('post_type'=>'page','post_title'=>'VIPSVault Home','post_content'=>$hero,'post_status'=>'publish')); update_option('show_on_front','page'); update_option('page_on_front',$id); }
    $vip_id=wp_insert_post(array('post_type'=>'vip','post_title'=>'Jack Nicholson','post_content'=>'A demo VIP wiki profile for movies, famous names, and memorabilia listings.','post_status'=>'publish','post_excerpt'=>'Academy Award-winning actor and screen icon.'));
    if($vip_id && !is_wp_error($vip_id)){ wp_set_object_terms($vip_id,'Movies','vip_category'); update_post_meta($vip_id,'_vip_full_name','Jack Nicholson'); update_post_meta($vip_id,'_vip_birth','April 22, 1937'); update_post_meta($vip_id,'_vip_birthplace','Neptune City, New Jersey'); update_post_meta($vip_id,'_vip_died',''); update_post_meta($vip_id,'_vip_profession','Actor / Filmmaker'); update_post_meta($vip_id,'_vip_active_years','1950s–2010s'); update_post_meta($vip_id,'Paste your memorabilia shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson memorabilia" item_count="4"]'); update_post_meta($vip_id,'_vip_ebay_keywords_top','Jack Nicholson memorabilia'); update_post_meta($vip_id,'_vip_ebay_keywords_bottom','Jack Nicholson cards memorabilia'); update_post_meta($vip_id,'_vip_ebay_item_count','4'); update_post_meta($vip_id,'_vip_bio','Jack Nicholson is one of the most recognizable actors in modern film history, known for intense performances, dark humor, and iconic screen presence.'); update_post_meta($vip_id,'_vip_accomplishments', wp_json_encode(array(array('title'=>'Academy Award Winner','summary'=>'Add major awards, records, career milestones, championships, albums, films, or cultural moments here.','api'=>'Paste memorabilia API shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson Oscar memorabilia"]')))); update_post_meta($vip_id,'_vip_news', wp_json_encode(array(array('title'=>'Latest Collecting Interest','summary'=>'Add news items, market interest, auctions, card releases, or memorabilia updates here.','api'=>'Paste news memorabilia API shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson autograph"]')))); update_post_meta($vip_id,'Paste bottom memorabilia API shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson cards memorabilia"]'); }
    $cid=wp_insert_post(array('post_type'=>'vip_collectible','post_title'=>'Jack Nicholson Signed Movie Icon Card','post_content'=>'Demo related collectible connected to the Jack Nicholson VIP page.','post_status'=>'publish','post_excerpt'=>'Related VIP collectible demo.')); if($cid){ wp_set_object_terms($cid,array('Celebrities','Movies & TV'),'collectible_category'); update_post_meta($cid,'_vv_person_name','Jack Nicholson'); update_post_meta($cid,'_vv_profession','Actor'); update_post_meta($cid,'_vv_team_role','Movies'); update_post_meta($cid,'_vv_year','1980'); update_post_meta($cid,'_vv_brand','VIPSVault Demo Series'); update_post_meta($cid,'_vv_card_number','VIP-JN-01'); update_post_meta($cid,'_vv_condition','Near Mint'); update_post_meta($cid,'_vv_grade','Raw'); update_post_meta($cid,'_vv_price','250'); update_post_meta($cid,'_vv_related_vip','jack-nicholson'); }
    foreach(array(array('1975','Movie','One Flew Over the Cuckoo’s Nest','A rebellious patient clashes with institutional control in one of Nicholson’s defining performances.'),array('1980','Movie','The Shining','A psychological horror classic featuring one of the most famous performances in movie history.'),array('1989','Movie','Batman','Nicholson brought a bold, theatrical version of the Joker to a blockbuster comic-book film.')) as $m){ $pid=wp_insert_post(array('post_type'=>'vip_career','post_title'=>$m[2],'post_content'=>$m[3],'post_status'=>'publish')); if($pid){ update_post_meta($pid,'_career_year',$m[0]); update_post_meta($pid,'_career_type',$m[1]); update_post_meta($pid,'_career_vip_slug','jack-nicholson'); update_post_meta($pid,'_career_summary',$m[3]); update_post_meta($pid,'_career_memorabilia','Paste career item memorabilia API shortcode here. Example: [vipsvault_ebay keywords="'.$m[2].' Jack Nicholson card"]'); }}
    $menu=wp_create_nav_menu('VIPSVault Main Menu'); if(!is_wp_error($menu)){ wp_update_nav_menu_item($menu,0,array('menu-item-title'=>'Home','menu-item-url'=>home_url('/'),'menu-item-status'=>'publish')); wp_update_nav_menu_item($menu,0,array('menu-item-title'=>'Collectibles','menu-item-url'=>get_post_type_archive_link('vip_collectible'),'menu-item-status'=>'publish')); wp_update_nav_menu_item($menu,0,array('menu-item-title'=>'VIPS','menu-item-url'=>(function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip')),'menu-item-status'=>'publish')); $loc=get_theme_mod('nav_menu_locations'); $loc['primary']=$menu; set_theme_mod('nav_menu_locations',$loc); }
    update_option('vipsvault_vips_demo_imported',current_time('mysql')); flush_rewrite_rules();
}
// Demo content import disabled to prevent duplicate demo VIP cards on live sites.
// add_action('after_switch_theme','vipsvault_demo_content');

/* WordPress menu support: map the header nav to Appearance > Menus without overwriting user edits. */
function vipsvault_primary_menu_fallback(){
    echo '<ul class="primary-menu">';
    echo '<li><a href="'.esc_url(home_url('/')).'">Home</a></li>';
    echo '<li><a href="'.esc_url(home_url('/psa10/')).'">PSA10</a></li>';
    echo '<li><a href="'.esc_url(get_post_type_archive_link('vip_collectible')).'">Collectibles</a></li>';
    echo '<li><a href="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">VIPS</a></li>';
    $about = get_page_by_title('About VIPSVault');
    if($about){ echo '<li><a href="'.esc_url(get_permalink($about)).'">About</a></li>'; }
    $blog = get_page_by_title('Blog');
    if($blog){ echo '<li><a href="'.esc_url(get_permalink($blog)).'">Blog</a></li>'; }
    echo '</ul>';
}
function vipsvault_get_or_create_page($title, $content=''){
    $page = get_page_by_title($title);
    if($page) return $page->ID;
    return wp_insert_post(array('post_type'=>'page','post_title'=>$title,'post_content'=>$content,'post_status'=>'publish'));
}
function vipsvault_ensure_primary_menu_mapping(){
    vipsvault_default_terms();
    $menu = wp_get_nav_menu_object('VIPSVault Main Menu');
    if(!$menu){
        $menu_id = wp_create_nav_menu('VIPSVault Main Menu');
        if(is_wp_error($menu_id)) return;
    } else {
        $menu_id = $menu->term_id;
    }

    $items = wp_get_nav_menu_items($menu_id);
    if(empty($items)){
        $about_id = vipsvault_get_or_create_page('About VIPSVault','<h2>The Vault for Iconic Collectibles</h2><p>VIPSVault.com showcases sports cards, celebrity cards, music legends, movie icons, autographs, graded collectibles, and memorabilia.</p>');
        $blog_id  = vipsvault_get_or_create_page('Blog','');
        wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'Home','menu-item-url'=>home_url('/'),'menu-item-status'=>'publish'));
        wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'Collectibles','menu-item-url'=>get_post_type_archive_link('vip_collectible'),'menu-item-status'=>'publish'));
        wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'VIPS','menu-item-url'=>(function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip')),'menu-item-status'=>'publish'));
        if($about_id && !is_wp_error($about_id)) wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'About','menu-item-url'=>get_permalink($about_id),'menu-item-status'=>'publish'));
        if($blog_id && !is_wp_error($blog_id)) wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'Blog','menu-item-url'=>get_permalink($blog_id),'menu-item-status'=>'publish'));
    }

    $locations = get_theme_mod('nav_menu_locations');
    if(!is_array($locations)) $locations = array();
    if(empty($locations['primary'])){
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
    update_option('vipsvault_nav_mapping_version','5');
}
add_action('after_switch_theme','vipsvault_ensure_primary_menu_mapping',30);
add_action('admin_init', function(){
    if(get_option('vipsvault_nav_mapping_version') !== '5'){
        vipsvault_ensure_primary_menu_mapping();
    }
});

/* VIPS archive/single rewrite hardening: keeps /vips/ as main VIPS directory and /vips/person-name/ as VIP profiles. */
function vipsvault_vips_rewrite_rules(){
    add_rewrite_rule('^vips/category/([^/]+)/?$', 'index.php?vip_category=$matches[1]', 'top');
    add_rewrite_rule('^vips/page/([0-9]+)/?$', 'index.php?post_type=vip&paged=$matches[1]', 'top');
    add_rewrite_rule('^vips/([^/]+)/?$', 'index.php?vip=$matches[1]', 'top');
    add_rewrite_rule('^vips/?$', 'index.php?post_type=vip', 'top');
}
add_action('init','vipsvault_vips_rewrite_rules',30);

function vipsvault_flush_rewrites_for_vips_fix(){
    $version = 'vips-directory-fix-1';
    if(get_option('vipsvault_rewrite_version') !== $version){
        flush_rewrite_rules(false);
        update_option('vipsvault_rewrite_version', $version);
    }
}
add_action('admin_init','vipsvault_flush_rewrites_for_vips_fix');
add_action('after_switch_theme','vipsvault_flush_rewrites_for_vips_fix',50);


/* Nav fix: replace any top-menu Sell link with Blog and make sure Blog links to /blog/. */
function vipsvault_replace_sell_nav_with_blog(){
    $blog_id = vipsvault_get_or_create_page('Blog','');
    if($blog_id && !is_wp_error($blog_id)){
        $blog_page = array(
            'ID' => $blog_id,
            'post_name' => 'blog',
            'post_status' => 'publish',
        );
        wp_update_post($blog_page);
    }
    $blog_url = $blog_id && !is_wp_error($blog_id) ? get_permalink($blog_id) : home_url('/blog/');

    $locations = get_theme_mod('nav_menu_locations');
    $menu_ids = array();
    if(is_array($locations) && !empty($locations['primary'])) $menu_ids[] = (int) $locations['primary'];
    $main_menu = wp_get_nav_menu_object('VIPSVault Main Menu');
    if($main_menu) $menu_ids[] = (int) $main_menu->term_id;
    $menu_ids = array_unique(array_filter($menu_ids));

    foreach($menu_ids as $menu_id){
        $items = wp_get_nav_menu_items($menu_id);
        if(empty($items)) continue;
        $has_blog = false;
        $sell_item_id = 0;
        foreach($items as $item){
            $title = strtolower(trim(wp_strip_all_tags($item->title)));
            $url = strtolower((string) $item->url);
            if($title === 'blog' || strpos($url, '/blog') !== false){
                $has_blog = true;
                wp_update_nav_menu_item($menu_id, $item->ID, array(
                    'menu-item-title' => 'Blog',
                    'menu-item-url' => $blog_url,
                    'menu-item-status' => 'publish',
                ));
            }
            if($title === 'sell' || strpos($title, 'sell your') !== false || strpos($url, '/sell') !== false){
                $sell_item_id = $item->ID;
            }
        }
        if($sell_item_id){
            wp_update_nav_menu_item($menu_id, $sell_item_id, array(
                'menu-item-title' => 'Blog',
                'menu-item-url' => $blog_url,
                'menu-item-status' => 'publish',
            ));
        } elseif(!$has_blog){
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' => 'Blog',
                'menu-item-url' => $blog_url,
                'menu-item-status' => 'publish',
            ));
        }
    }
    update_option('vipsvault_nav_sell_blog_version','1');
}
add_action('after_switch_theme','vipsvault_replace_sell_nav_with_blog',60);
add_action('admin_init', function(){
    if(get_option('vipsvault_nav_sell_blog_version') !== '1'){
        vipsvault_replace_sell_nav_with_blog();
    }
});

function vipsvault_vips_archive_url(){
    return home_url('/vips/');
}

/* VIPSVault category fallback images and VIP age helper */
function vipsvault_category_fallback_image_url($post_id = null){
    $post_id = $post_id ?: get_the_ID();
    $type = get_post_type($post_id);
    $taxonomy = ($type === 'vip') ? 'vip_category' : 'collectible_category';
    $terms = get_the_terms($post_id, $taxonomy);
    $slugs = array();
    if($terms && !is_wp_error($terms)){
        foreach($terms as $term){ $slugs[] = strtolower($term->slug); $slugs[] = strtolower($term->name); }
    }
    $map = array(
        'baseball'=>'category-baseball.svg','football'=>'category-football.svg','basketball'=>'category-basketball.svg','hockey'=>'category-hockey.svg','golf'=>'category-golf.svg',
        'movies'=>'category-movies.svg','movies-tv'=>'category-movies.svg','movie'=>'category-movies.svg','tv'=>'category-tv.svg','music'=>'category-music.svg',
        'celebrities'=>'category-celebrity.svg','celebrity'=>'category-celebrity.svg','autographs'=>'category-autograph.svg','autograph'=>'category-autograph.svg',
        'memorabilia'=>'category-memorabilia.svg','rookie-cards'=>'category-basketball.svg','graded-cards'=>'category-memorabilia.svg','sports'=>'category-basketball.svg'
    );
    foreach($map as $needle=>$file){
        if(in_array($needle, $slugs, true)) return get_template_directory_uri().'/assets/'.$file;
    }
    return get_template_directory_uri().'/assets/category-default.svg';
}
function vipsvault_post_image_html($post_id = null, $alt = ''){
    $post_id = $post_id ?: get_the_ID();
    if(has_post_thumbnail($post_id)) return get_the_post_thumbnail($post_id, 'large', array('alt'=>$alt ?: get_the_title($post_id)));

    // For VIP profiles without a featured image, show one eBay auction item image in the same image slot.
    // This keeps the page monetized without changing stored VIP content.
    if(get_post_type($post_id) === 'vip' && function_exists('vipsvault_vip_ebay_featured_image_html')){
        $ebay_image = vipsvault_vip_ebay_featured_image_html($post_id, $alt ?: get_the_title($post_id));
        if($ebay_image){ return $ebay_image; }
    }

    return '<img src="'.esc_url(vipsvault_category_fallback_image_url($post_id)).'" alt="'.esc_attr($alt ?: get_the_title($post_id)).'">';
}
function vipsvault_calculate_vip_age($born, $died = ''){
    if(!$born) return '';
    try { $birth = new DateTime($born); } catch(Exception $e) { $birth = date_create($born); }
    if(!$birth) return '';
    if($died){
        try { $end = new DateTime($died); } catch(Exception $e) { $end = date_create($died); }
    } else { $end = new DateTime('now'); }
    if(!$end || $end < $birth) return '';
    return (string)$birth->diff($end)->y;
}

require_once get_template_directory() . '/inc/ebay-partner-api.php';


/* VIP featured image eBay auction fallback.
 * If a VIP has no featured image, the image slot can show a single active eBay auction image.
 * Safe fallback order: WP featured image -> eBay auction image -> category default image.
 */
function vipsvault_vip_ebay_featured_keywords($post_id){
    $raw = get_post_meta($post_id, '_vip_ebay_keywords_top', true);
    if(function_exists('vipsvault_ebay_parse_input')){
        $parsed = vipsvault_ebay_parse_input($raw, 1, '');
        if(!empty($parsed['keywords'])) return $parsed['keywords'];
    }
    $name = get_post_meta($post_id, '_vip_full_name', true);
    if(!$name) $name = get_the_title($post_id);
    return trim($name . ' memorabilia autograph card');
}

function vipsvault_vip_ebay_featured_auction_item($post_id){
    if(!function_exists('vipsvault_ebay_options') || !function_exists('vipsvault_ebay_get_token')) return false;
    if(function_exists('vipsvault_ebay_is_configured') && !vipsvault_ebay_is_configured()) return false;

    $o = vipsvault_ebay_options();
    $keywords = function_exists('vipsvault_ebay_clean_keywords') ? vipsvault_ebay_clean_keywords(vipsvault_vip_ebay_featured_keywords($post_id)) : sanitize_text_field(vipsvault_vip_ebay_featured_keywords($post_id));
    if($keywords === '') return false;

    $cache_key = 'vv_vip_featured_auction_' . md5($post_id . '|' . strtolower($keywords) . '|' . ($o['marketplace_id'] ?? '') . '|' . ($o['campaign_id'] ?? '') . '|v1');
    $cached = get_transient($cache_key);
    if($cached !== false) return $cached;

    $token = vipsvault_ebay_get_token();
    if(is_wp_error($token)){
        if(function_exists('vipsvault_ebay_store_last_error')) vipsvault_ebay_store_last_error($token->get_error_message());
        return false;
    }

    $params = array(
        'q'      => $keywords,
        'limit'  => 1,
        'filter' => 'buyingOptions:{AUCTION}',
        'sort'   => 'endingSoonest',
    );
    $endpoint = !empty($o['endpoint']) ? $o['endpoint'] : 'https://api.ebay.com';
    $url = trailingslashit($endpoint) . 'buy/browse/v1/item_summary/search?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    $headers = array(
        'Authorization' => 'Bearer ' . $token,
        'X-EBAY-C-MARKETPLACE-ID' => !empty($o['marketplace_id']) ? $o['marketplace_id'] : 'EBAY_US',
        'Accept' => 'application/json',
    );
    if(!empty($o['campaign_id'])){
        $ctx = 'affiliateCampaignId=' . rawurlencode($o['campaign_id']);
        if(!empty($o['custom_id'])) $ctx .= ',affiliateReferenceId=' . rawurlencode($o['custom_id']);
        $headers['X-EBAY-C-ENDUSERCTX'] = $ctx;
    }

    $response = wp_remote_get($url, array('timeout'=>12, 'headers'=>$headers));
    if(is_wp_error($response)) return false;
    $code = wp_remote_retrieve_response_code($response);
    if($code < 200 || $code >= 300) return false;
    $body = json_decode(wp_remote_retrieve_body($response), true);
    $items = isset($body['itemSummaries']) && is_array($body['itemSummaries']) ? $body['itemSummaries'] : array();
    $item = !empty($items[0]) && is_array($items[0]) ? $items[0] : false;

    set_transient($cache_key, $item, HOUR_IN_SECONDS * max(1, intval($o['cache_hours'] ?? 6)));
    return $item;
}

function vipsvault_vip_ebay_featured_image_html($post_id, $alt = ''){
    $item = vipsvault_vip_ebay_featured_auction_item($post_id);
    if(empty($item) || empty($item['image']['imageUrl'])) return '';

    $title = !empty($item['title']) ? $item['title'] : ($alt ?: get_the_title($post_id));
    $raw_url = $item['itemAffiliateWebUrl'] ?? ($item['itemWebUrl'] ?? '');
    $url = function_exists('vipsvault_ebay_affiliate_item_url') ? vipsvault_ebay_affiliate_item_url($raw_url) : $raw_url;
    $price = '';
    if(!empty($item['price']['value'])) $price = trim(($item['price']['currency'] ?? 'USD') . ' ' . $item['price']['value']);

    $html  = '<a class="vv-vip-ebay-featured-image" target="_blank" rel="nofollow sponsored noopener" href="'.esc_url($url ?: '#').'">';
    $html .= '<img src="'.esc_url($item['image']['imageUrl']).'" alt="'.esc_attr($title).'">';
    $html .= '<span class="vv-vip-ebay-featured-badge">eBay Auction</span>';
    if($price) $html .= '<span class="vv-vip-ebay-featured-price">'.esc_html($price).'</span>';
    $html .= '</a>';
    return $html;
}


/* Homepage random VIP refresh: uses AJAX so 8 unique VIPS refresh on every browser load, even when page cache is active. */
function vipsvault_get_random_vips_html($limit = 8){
    $limit = max(1, min(24, absint($limit)));
    $q = new WP_Query(array(
        'post_type'              => 'vip',
        'post_status'            => 'publish',
        'posts_per_page'         => 48,
        'orderby'                => 'rand',
        'no_found_rows'          => true,
        'ignore_sticky_posts'    => true,
        'cache_results'          => false,
        'update_post_meta_cache' => true,
        'update_post_term_cache' => true,
        'suppress_filters'       => false,
    ));
    $shown = array();
    $count = 0;
    ob_start();
    if($q->have_posts()){
        while($q->have_posts() && $count < $limit){
            $q->the_post();
            $unique_key = strtolower(trim(get_post_meta(get_the_ID(), '_vip_full_name', true) ?: get_the_title()));
            if(!$unique_key){ $unique_key = 'vip-' . get_the_ID(); }
            $unique_key = sanitize_title($unique_key);
            if(isset($shown[$unique_key])){ continue; }
            $shown[$unique_key] = true;
            $count++;
            get_template_part('template-parts/vip-card');
        }
        wp_reset_postdata();
    }
    return ob_get_clean();
}

function vipsvault_ajax_random_vips(){
    if(function_exists('nocache_headers')){ nocache_headers(); }
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    wp_send_json_success(array('html' => vipsvault_get_random_vips_html(8)));
}
add_action('wp_ajax_vipsvault_random_vips', 'vipsvault_ajax_random_vips');
add_action('wp_ajax_nopriv_vipsvault_random_vips', 'vipsvault_ajax_random_vips');

function vipsvault_random_vips_footer_script(){
    if(!is_front_page()){ return; }
    $ajax_url = admin_url('admin-ajax.php');
    ?>
    <script>
    (function(){
        var grid = document.getElementById('vipsvault-random-vips-grid');
        if(!grid){ return; }
        var url = <?php echo wp_json_encode($ajax_url); ?> + '?action=vipsvault_random_vips&_=' + Date.now() + Math.random().toString(36).slice(2);
        fetch(url, { cache: 'no-store', credentials: 'same-origin' })
            .then(function(response){ return response.json(); })
            .then(function(data){
                if(data && data.success && data.data && data.data.html){
                    grid.innerHTML = data.data.html;
                }
            })
            .catch(function(){});
    })();
    </script>
    <?php
}
add_action('wp_footer', 'vipsvault_random_vips_footer_script', 99);

/* Blog card archive: 15 recent posts + AJAX load 15 more. */
function vipsvault_blog_total_posts(){
    $counts = wp_count_posts('post');
    return isset($counts->publish) ? (int) $counts->publish : 0;
}

function vipsvault_render_blog_title_items($offset = 0, $limit = 15){
    $offset = max(0, absint($offset));
    $limit  = max(1, min(50, absint($limit)));
    $q = new WP_Query(array(
        'post_type'              => 'post',
        'post_status'            => 'publish',
        'posts_per_page'         => $limit,
        'offset'                 => $offset,
        'orderby'                => 'date',
        'order'                  => 'DESC',
        'ignore_sticky_posts'    => true,
        'no_found_rows'          => true,
        'update_post_meta_cache' => true,
        'update_post_term_cache' => true,
    ));
    ob_start();
    if($q->have_posts()){
        while($q->have_posts()){
            $q->the_post();
            $excerpt = get_the_excerpt();
            if(!$excerpt){
                $excerpt = wp_trim_words(wp_strip_all_tags(get_the_content()), 26, '...');
            }
            $word_count = str_word_count(wp_strip_all_tags(get_the_content()));
            $read_time = max(1, (int) ceil($word_count / 225));
            $cats = get_the_category();
            ?>
            <article <?php post_class('vv-blog-article-card vv-blog-no-image-card'); ?>>
                <div class="vv-blog-card-content">
                    <div class="vv-blog-card-meta">
                        <span><?php echo esc_html(get_the_date('M j, Y')); ?></span>
                        <span><?php echo esc_html($read_time); ?> min read</span>
                        <?php if(!empty($cats)) : ?><span><?php echo esc_html($cats[0]->name); ?></span><?php endif; ?>
                    </div>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php echo esc_html(wp_trim_words($excerpt, 28, '...')); ?></p>
                    <a class="vv-blog-card-button" href="<?php the_permalink(); ?>">Read Article</a>
                </div>
            </article>
            <?php
        }
        wp_reset_postdata();
    } elseif($offset === 0) {
        echo '<article class="detail-panel"><p>No blog posts found.</p></article>';
    }
    return ob_get_clean();
}

function vipsvault_ajax_load_more_blog_posts(){
    $offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;
    $limit  = isset($_POST['limit']) ? absint($_POST['limit']) : 20;
    $html   = vipsvault_render_blog_title_items($offset, $limit);
    $total  = vipsvault_blog_total_posts();
    wp_send_json_success(array(
        'html'        => $html,
        'next_offset' => $offset + $limit,
        'has_more'    => (($offset + $limit) < $total),
    ));
}
add_action('wp_ajax_vipsvault_load_more_blog_posts', 'vipsvault_ajax_load_more_blog_posts');
add_action('wp_ajax_nopriv_vipsvault_load_more_blog_posts', 'vipsvault_ajax_load_more_blog_posts');

function vipsvault_blog_load_more_script(){
    if(!(is_home() || is_page('blog'))){ return; }
    ?>
    <script>
    (function(){
        var button = document.getElementById('vipsvault-load-more-posts');
        var list = document.getElementById('vipsvault-blog-title-list');
        if(!button || !list){ return; }
        button.addEventListener('click', function(){
            var offset = parseInt(button.getAttribute('data-offset') || '15', 10);
            var step = parseInt(button.getAttribute('data-step') || '15', 10);
            var originalText = button.textContent;
            button.disabled = true;
            button.textContent = 'Loading...';
            var form = new FormData();
            form.append('action', 'vipsvault_load_more_blog_posts');
            form.append('offset', offset);
            form.append('limit', step);
            fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                body: form,
                credentials: 'same-origin'
            }).then(function(response){ return response.json(); })
              .then(function(data){
                if(data && data.success && data.data && data.data.html){
                    list.insertAdjacentHTML('beforeend', data.data.html);
                    button.setAttribute('data-offset', data.data.next_offset);
                    if(!data.data.has_more){ button.remove(); return; }
                }
                button.disabled = false;
                button.textContent = originalText;
              }).catch(function(){
                button.disabled = false;
                button.textContent = originalText;
              });
        });
    })();
    </script>
    <?php
}
add_action('wp_footer', 'vipsvault_blog_load_more_script', 100);

/* VIPS page fallback fix: if WordPress has a normal Page using slug /vips/, force it to use the VIPS directory template so existing VIP posts display. */
function vipsvault_force_vips_page_template($template){
    if(is_page('vips')){
        $vips_template = locate_template('page-vips.php');
        if($vips_template){ return $vips_template; }
    }
    return $template;
}
add_filter('template_include','vipsvault_force_vips_page_template',99);

/* Keep the /vips/ menu URL pointed to the VIPS directory and refresh permalinks after this fix. */
function vipsvault_flush_rewrites_for_vips_page_template_fix(){
    $version = 'vips-page-template-force-1';
    if(get_option('vipsvault_vips_page_template_fix_version') !== $version){
        flush_rewrite_rules(false);
        update_option('vipsvault_vips_page_template_fix_version', $version);
    }
}
add_action('admin_init','vipsvault_flush_rewrites_for_vips_page_template_fix');
add_action('after_switch_theme','vipsvault_flush_rewrites_for_vips_page_template_fix',60);

/* Ensure /vips/ directory page and rewrites stay connected */
function vipsvault_ensure_vips_directory_page(){
    $page = get_page_by_path('vips');
    if(!$page){
        $page_id = wp_insert_post(array(
            'post_type'    => 'page',
            'post_title'   => 'VIPS',
            'post_name'    => 'vips',
            'post_status'  => 'publish',
            'post_content' => ''
        ));
        if(!is_wp_error($page_id) && $page_id){ update_post_meta($page_id, '_wp_page_template', 'default'); }
    }
    flush_rewrite_rules(false);
}
add_action('after_switch_theme','vipsvault_ensure_vips_directory_page',90);
