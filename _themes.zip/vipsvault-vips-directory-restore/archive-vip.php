<?php get_header(); ?>
<main>
  <section class="archive-hero vips-directory-hero">
    <div class="container">
      <div class="kicker">VIPS</div>
      <h1>VIPS Directory</h1>
      <p class="meta-line">Browse VIP profiles for athletes, actors, musicians, movie icons, TV stars, legends, and collectible-related names.</p>
      <?php if(function_exists('vipsvault_vip_search_form')) vipsvault_vip_search_form(); ?>
      <div class="cat-pills">
        <?php
        $terms = get_terms(array('taxonomy'=>'vip_category','hide_empty'=>false));
        if(!is_wp_error($terms) && !empty($terms)){
            foreach($terms as $term){ echo '<a href="'.esc_url(get_term_link($term)).'">'.esc_html($term->name).'</a>'; }
        }
        ?>
      </div>
    </div>
  </section>
  <section class="section">
    <div class="container">
      <?php
      $paged = max(1, (int)get_query_var('paged'), (int)get_query_var('page'));
      $args = array(
          'post_type'           => 'vip',
          'post_status'         => 'publish',
          'posts_per_page'      => 12,
          'paged'               => $paged,
          'ignore_sticky_posts' => true,
      );

      if(!empty($_GET['vvq'])){
          $args['s'] = sanitize_text_field(wp_unslash($_GET['vvq']));
      }
      if(!empty($_GET['vipcat'])){
          $args['tax_query'] = array(array(
              'taxonomy' => 'vip_category',
              'field'    => 'slug',
              'terms'    => sanitize_text_field(wp_unslash($_GET['vipcat']))
          ));
      } elseif(is_tax('vip_category')) {
          $term = get_queried_object();
          if($term && !is_wp_error($term) && !empty($term->slug)){
              $args['tax_query'] = array(array(
                  'taxonomy' => 'vip_category',
                  'field'    => 'slug',
                  'terms'    => $term->slug
              ));
          }
      }

      $sort = !empty($_GET['vipsort']) ? sanitize_text_field(wp_unslash($_GET['vipsort'])) : 'newest';
      if($sort === 'oldest'){ $args['orderby'] = 'date'; $args['order'] = 'ASC'; }
      elseif($sort === 'az'){ $args['orderby'] = 'title'; $args['order'] = 'ASC'; }
      elseif($sort === 'za'){ $args['orderby'] = 'title'; $args['order'] = 'DESC'; }
      else { $args['orderby'] = 'date'; $args['order'] = 'DESC'; }

      $vips_query = new WP_Query($args);
      if($vips_query->have_posts()): ?>
        <div class="section-title"><h2>All VIPS</h2><p>Click a VIP to view their bio, accomplishments, career items, news, and related memorabilia.</p></div>
        <div class="vip-grid">
          <?php while($vips_query->have_posts()): $vips_query->the_post(); get_template_part('template-parts/vip-card'); endwhile; ?>
        </div>
        <div class="pagination"><?php echo paginate_links(array('total'=>$vips_query->max_num_pages,'current'=>$paged)); ?></div>
      <?php else: ?>
        <div class="api-embed">No VIP pages were found. Your VIP records are stored in WordPress under Dashboard &gt; VIPS. If you recently changed themes, go to Settings &gt; Permalinks and click Save Changes once.</div>
      <?php endif; wp_reset_postdata(); ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
