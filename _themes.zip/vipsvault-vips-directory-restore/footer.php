<footer class="footer"><div class="container">VIPSVault.com — The vault for iconic collectibles, VIP profiles, cards, autographs, memorabilia, and famous names.</div></footer><?php wp_footer(); ?></body></html>
<script>
(function(){
  function stripEmojiText(text){
    if(!text) return text;
    try {
      return text
        .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu, '')
        .replace(/\s+/g, ' ')
        .trim();
    } catch(e) {
      return text;
    }
  }
  function cleanPsa10Titles(){
    var nodes = document.querySelectorAll('.psa10-product-card .ebay-title, .vv-home-psa10-grid .ebay-title');
    nodes.forEach(function(node){
      node.textContent = stripEmojiText(node.textContent);
    });
  }
  if(document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', cleanPsa10Titles);
  } else {
    cleanPsa10Titles();
  }
})();
</script>
