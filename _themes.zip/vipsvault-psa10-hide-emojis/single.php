<?php get_header(); ?>
<main class="single-wrap blog-single-wrap">
  <div class="container">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <article <?php post_class('detail-panel blog-post-panel'); ?>>
        <div class="kicker">VIPSVault Blog</div>
        <h1><?php the_title(); ?></h1>
        <div class="meta-line blog-meta">
          <?php echo esc_html(get_the_date()); ?>
          <?php if (has_category()) : ?> &bull; <?php the_category(', '); ?><?php endif; ?>
        </div>
        <?php if (has_post_thumbnail()) : ?>
          <div class="blog-featured-image">
            <?php the_post_thumbnail('large'); ?>
          </div>
        <?php endif; ?>
        <div class="content-box blog-content">
          <?php the_content(); ?>
          <?php wp_link_pages(array('before' => '<div class="page-links">Pages: ', 'after' => '</div>')); ?>
        </div>
      </article>
    <?php endwhile; endif; ?>
  </div>
</main>
<?php get_footer(); ?>
