<article class="collectible-card">
    <a href="<?php the_permalink(); ?>">
        <div class="card-image">
            <?php if (has_post_thumbnail()) { the_post_thumbnail('large'); } else { echo '<span class="kicker">VIP Vault</span>'; } ?>
        </div>
        <div class="card-body">
            <div class="badges">
                <?php $cats = get_the_terms(get_the_ID(), 'collectible_category'); if ($cats && !is_wp_error($cats)) { echo '<span class="badge">'.esc_html($cats[0]->name).'</span>'; } ?>
                <?php if (get_post_meta(get_the_ID(), '_vv_autograph', true) === 'Yes') echo '<span class="badge dark">Auto</span>'; ?>
                <?php if (get_post_meta(get_the_ID(), '_vv_rookie', true) === 'Yes') echo '<span class="badge dark">Rookie</span>'; ?>
            </div>
            <h3><?php the_title(); ?></h3>
            <div class="meta-line"><?php echo vipsvault_get_meta('_vv_year'); ?> <?php echo vipsvault_get_meta('_vv_brand'); ?></div>
            <div class="meta-line"><?php echo vipsvault_get_meta('_vv_grade'); ?> <?php echo vipsvault_get_meta('_vv_condition'); ?></div>
            <?php if (get_post_meta(get_the_ID(), '_vv_price', true)) : ?><div class="price"><?php echo vipsvault_get_meta('_vv_price'); ?></div><?php endif; ?>
        </div>
    </a>
</article>
