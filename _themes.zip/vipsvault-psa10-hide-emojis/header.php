<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
    <div class="container nav">
        <a class="brand" href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo esc_url(get_template_directory_uri().'/assets/vipsvault-logo.png'); ?>" alt="VIPSVault">
            <span>VIPSVault</span>
        </a>

        <nav class="menu" aria-label="Main menu">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'primary-menu',
                'fallback_cb'    => 'vipsvault_primary_menu_fallback',
                'depth'          => 3,
            ));
            ?>
        </nav>

        <?php if(function_exists('vipsvault_header_search_form')) vipsvault_header_search_form(); ?>
    </div>
</header>
