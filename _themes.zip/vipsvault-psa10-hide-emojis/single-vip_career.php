<?php get_header(); ?>
<main class="single-wrap">
    <div class="container single-grid">
        <aside>
            <div class="feature-image">
                <?php if(has_post_thumbnail()) the_post_thumbnail('large'); else echo '<img src="'.esc_url(get_template_directory_uri().'/assets/vipsvault-logo.png').'" alt="VIPSVault career item">'; ?>
            </div>
            <?php vv_api_box('Memorabilia API', get_post_meta(get_the_ID(),'_career_memorabilia',true)); ?>
        </aside>
        <article class="detail-panel">
            <div class="kicker"><?php echo esc_html(get_post_meta(get_the_ID(),'_career_type',true)); ?> Career Item</div>
            <h1><?php the_title(); ?></h1>
            <div class="stats">
                <div class="stat"><b>Year / Season</b><?php echo esc_html(get_post_meta(get_the_ID(),'_career_year',true)); ?></div>
                <div class="stat"><b>Type</b><?php echo esc_html(get_post_meta(get_the_ID(),'_career_type',true)); ?></div>
                <div class="stat"><b>Role / Team</b><?php echo esc_html(get_post_meta(get_the_ID(),'_career_role',true)); ?></div>
            </div>
            <section class="wiki-section">
                <h2>Summary</h2>
                <div class="content-box"><?php echo wpautop(wp_kses_post(get_post_meta(get_the_ID(),'_career_summary',true) ?: get_the_content())); ?></div>
            </section>
            <?php $slug=get_post_meta(get_the_ID(),'_career_vip_slug',true); $vip=get_page_by_path($slug,OBJECT,'vip'); if($vip): ?>
                <p><a class="btn btn-secondary" href="<?php echo esc_url(get_permalink($vip)); ?>">Back to <?php echo esc_html(get_the_title($vip)); ?></a></p>
            <?php endif; ?>
        </article>
    </div>
</main>
<?php get_footer(); ?>
