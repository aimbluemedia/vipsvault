<?php get_header(); ?>
<main>
  <section class="archive-hero vips-directory-hero">
    <div class="container">
      <div class="kicker">VIPS</div>
      <h1>VIPS Directory</h1>
      <p class="meta-line">Browse VIP profiles for athletes, actors, musicians, movie icons, TV stars, legends, and collectible-related names.</p>
      <?php if(function_exists('vipsvault_vip_search_form')) vipsvault_vip_search_form(); ?>
      <div class="cat-pills">
        <?php
        $terms=get_terms(array('taxonomy'=>'vip_category','hide_empty'=>false));
        if(!is_wp_error($terms)){ foreach($terms as $term) echo '<a href="'.esc_url(get_term_link($term)).'">'.esc_html($term->name).'</a>'; }
        ?>
      </div>
    </div>
  </section>
  <section class="section">
    <div class="container">
      <?php if(have_posts()): ?>
        <div class="section-title"><h2>All VIPS</h2><p>Click a VIP to view their bio, accomplishments, career items, news, and related memorabilia.</p></div>
        <div class="vip-grid"><?php while(have_posts()):the_post(); get_template_part('template-parts/vip-card'); endwhile; ?></div>
        <div class="pagination"><?php the_posts_pagination(array('mid_size'=>2)); ?></div>
      <?php else: ?>
        <div class="api-embed">No VIP pages matched your search. Try another name, category, profession, movie, team, or keyword. You can add one from Dashboard &gt; VIPS &gt; Add VIP.</div>
      <?php endif; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
