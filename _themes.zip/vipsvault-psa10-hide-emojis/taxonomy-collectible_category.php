<?php get_template_part('archive', 'vip_collectible'); ?>
