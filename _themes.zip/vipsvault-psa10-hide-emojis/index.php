<?php get_header(); ?>
<main class="section">
  <div class="container">
    <div class="section-title">
      <h2><?php echo is_singular() ? esc_html(get_the_title()) : esc_html(single_post_title('', false)); ?></h2>
    </div>
    <div class="content-box">
      <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article <?php post_class('detail-panel blog-list-card'); ?>>
          <?php if (is_singular()) : ?>
            <h1><?php the_title(); ?></h1>
            <?php if (has_post_thumbnail()) : ?><div class="blog-featured-image"><?php the_post_thumbnail('large'); ?></div><?php endif; ?>
            <div class="content-box blog-content"><?php the_content(); ?></div>
          <?php else : ?>
            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <?php the_excerpt(); ?>
            <a class="btn btn-secondary" href="<?php the_permalink(); ?>">Read More</a>
          <?php endif; ?>
        </article>
      <?php endwhile; endif; ?>
    </div>
  </div>
</main>
<?php get_footer(); ?>
