<?php
if(!defined('ABSPATH')) exit;

/*
 * VIPSVault Amazon Associates / PA-API Memorabilia Integration
 * Adds: Appearance > VIPSVault Amazon settings, VIP keyword fields,
 * shortcode [vipsvault_amazon keywords="harry potter" item_count="4" title="Amazon Memorabilia"],
 * and auto-rendering helpers for VIP profile pages.
 */

function vipsvault_amazon_default_options(){
    return array(
        'access_key' => '',
        'secret_key' => '',
        'partner_tag' => '',
        'marketplace' => 'www.amazon.com',
        'region' => 'us-east-1',
        'cache_hours' => 12,
    );
}

function vipsvault_amazon_options(){
    $saved = get_option('vipsvault_amazon_options', array());
    return wp_parse_args(is_array($saved) ? $saved : array(), vipsvault_amazon_default_options());
}

function vipsvault_amazon_admin_menu(){
    add_theme_page('VIPSVault Amazon API', 'VIPSVault Amazon API', 'manage_options', 'vipsvault-amazon-api', 'vipsvault_amazon_settings_page');
}
add_action('admin_menu','vipsvault_amazon_admin_menu');

function vipsvault_amazon_register_settings(){
    register_setting('vipsvault_amazon_group', 'vipsvault_amazon_options', 'vipsvault_amazon_sanitize_options');
}
add_action('admin_init','vipsvault_amazon_register_settings');

function vipsvault_amazon_sanitize_options($input){
    $defaults = vipsvault_amazon_default_options();
    $out = array();
    $out['access_key'] = isset($input['access_key']) ? sanitize_text_field($input['access_key']) : '';
    $out['secret_key'] = isset($input['secret_key']) ? sanitize_text_field($input['secret_key']) : '';
    $out['partner_tag'] = isset($input['partner_tag']) ? sanitize_text_field($input['partner_tag']) : '';
    $out['marketplace'] = isset($input['marketplace']) ? sanitize_text_field($input['marketplace']) : $defaults['marketplace'];
    $out['region'] = isset($input['region']) ? sanitize_text_field($input['region']) : $defaults['region'];
    $out['cache_hours'] = isset($input['cache_hours']) ? max(1, min(72, intval($input['cache_hours']))) : 12;
    return $out;
}

function vipsvault_amazon_settings_page(){
    if(!current_user_can('manage_options')) return;
    $o = vipsvault_amazon_options();
    ?>
    <div class="wrap">
        <h1>VIPSVault Amazon API</h1>
        <p>Connect Amazon Associates PA-API so VIP pages can display affiliate memorabilia products. Use the shortcode <code>[vipsvault_amazon keywords="harry potter" item_count="4"]</code> anywhere a memorabilia embed/code field appears.</p>
        <form method="post" action="options.php">
            <?php settings_fields('vipsvault_amazon_group'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="vv_amz_access_key">Access Key</label></th><td><input class="regular-text" id="vv_amz_access_key" name="vipsvault_amazon_options[access_key]" value="<?php echo esc_attr($o['access_key']); ?>"></td></tr>
                <tr><th scope="row"><label for="vv_amz_secret_key">Secret Key</label></th><td><input class="regular-text" type="password" id="vv_amz_secret_key" name="vipsvault_amazon_options[secret_key]" value="<?php echo esc_attr($o['secret_key']); ?>"><p class="description">Stored in WordPress options. Keep admin access limited.</p></td></tr>
                <tr><th scope="row"><label for="vv_amz_partner_tag">Partner Tag</label></th><td><input class="regular-text" id="vv_amz_partner_tag" name="vipsvault_amazon_options[partner_tag]" value="<?php echo esc_attr($o['partner_tag']); ?>" placeholder="xyz-20"></td></tr>
                <tr><th scope="row"><label for="vv_amz_marketplace">Marketplace Host</label></th><td><input class="regular-text" id="vv_amz_marketplace" name="vipsvault_amazon_options[marketplace]" value="<?php echo esc_attr($o['marketplace']); ?>" placeholder="www.amazon.com"><p class="description">Examples: www.amazon.com, www.amazon.co.uk, www.amazon.ca.</p></td></tr>
                <tr><th scope="row"><label for="vv_amz_region">AWS Region</label></th><td><input class="regular-text" id="vv_amz_region" name="vipsvault_amazon_options[region]" value="<?php echo esc_attr($o['region']); ?>" placeholder="us-east-1"><p class="description">For Amazon.com use us-east-1.</p></td></tr>
                <tr><th scope="row"><label for="vv_amz_cache">Cache Hours</label></th><td><input type="number" min="1" max="72" id="vv_amz_cache" name="vipsvault_amazon_options[cache_hours]" value="<?php echo esc_attr($o['cache_hours']); ?>"></td></tr>
            </table>
            <?php submit_button('Save Amazon API Settings'); ?>
        </form>
    </div>
    <?php
}

function vipsvault_amazon_is_configured(){
    $o = vipsvault_amazon_options();
    return !empty($o['access_key']) && !empty($o['secret_key']) && !empty($o['partner_tag']);
}

function vipsvault_amazon_hash($data){ return hash('sha256', $data); }
function vipsvault_amazon_hmac($key, $data, $raw = true){ return hash_hmac('sha256', $data, $key, $raw); }

function vipsvault_amazon_signing_key($secret, $date, $region, $service){
    $kDate = vipsvault_amazon_hmac('AWS4' . $secret, $date);
    $kRegion = vipsvault_amazon_hmac($kDate, $region);
    $kService = vipsvault_amazon_hmac($kRegion, $service);
    return vipsvault_amazon_hmac($kService, 'aws4_request');
}

function vipsvault_amazon_search_items($keywords, $item_count = 4){
    $keywords = trim(wp_strip_all_tags((string)$keywords));
    if($keywords === '') return new WP_Error('vv_amz_no_keywords','No Amazon keywords were provided.');
    if(!vipsvault_amazon_is_configured()) return new WP_Error('vv_amz_not_configured','Amazon API is not configured yet. Go to Appearance > VIPSVault Amazon API.');

    $o = vipsvault_amazon_options();
    $item_count = max(1, min(10, intval($item_count)));
    $cache_key = 'vv_amz_' . md5($keywords . '|' . $item_count . '|' . $o['partner_tag'] . '|' . $o['marketplace']);
    $cached = get_transient($cache_key);
    if($cached !== false) return $cached;

    $host = $o['marketplace'];
    $region = $o['region'];
    $service = 'ProductAdvertisingAPI';
    $uri = '/paapi5/searchitems';
    $target = 'com.amazon.paapi5.v1.ProductAdvertisingAPIv1.SearchItems';
    $payload_array = array(
        'PartnerTag' => $o['partner_tag'],
        'PartnerType' => 'Associates',
        'Marketplace' => $host,
        'Keywords' => $keywords,
        'ItemCount' => $item_count,
        'Resources' => array('Images.Primary.Medium','ItemInfo.Title','OffersV2.Listings.Price')
    );
    $payload = wp_json_encode($payload_array);
    $amzdate = gmdate('Ymd\THis\Z');
    $datestamp = gmdate('Ymd');

    $canonical_headers =
        'content-encoding:amz-1.0' . "\n" .
        'content-type:application/json; charset=utf-8' . "\n" .
        'host:' . $host . "\n" .
        'x-amz-date:' . $amzdate . "\n" .
        'x-amz-target:' . $target . "\n";
    $signed_headers = 'content-encoding;content-type;host;x-amz-date;x-amz-target';
    $canonical_request = "POST\n" . $uri . "\n\n" . $canonical_headers . "\n" . $signed_headers . "\n" . vipsvault_amazon_hash($payload);
    $credential_scope = $datestamp . '/' . $region . '/' . $service . '/aws4_request';
    $string_to_sign = "AWS4-HMAC-SHA256\n" . $amzdate . "\n" . $credential_scope . "\n" . vipsvault_amazon_hash($canonical_request);
    $signing_key = vipsvault_amazon_signing_key($o['secret_key'], $datestamp, $region, $service);
    $signature = hash_hmac('sha256', $string_to_sign, $signing_key);
    $authorization = 'AWS4-HMAC-SHA256 Credential=' . $o['access_key'] . '/' . $credential_scope . ', SignedHeaders=' . $signed_headers . ', Signature=' . $signature;

    $response = wp_remote_post('https://' . $host . $uri, array(
        'timeout' => 18,
        'headers' => array(
            'Content-Encoding' => 'amz-1.0',
            'Content-Type' => 'application/json; charset=utf-8',
            'Host' => $host,
            'X-Amz-Date' => $amzdate,
            'X-Amz-Target' => $target,
            'Authorization' => $authorization,
        ),
        'body' => $payload,
    ));

    if(is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if($code < 200 || $code >= 300){
        $msg = isset($body['Errors'][0]['Message']) ? $body['Errors'][0]['Message'] : 'Amazon API request failed.';
        return new WP_Error('vv_amz_api_error', $msg);
    }
    $items = isset($body['SearchResult']['Items']) && is_array($body['SearchResult']['Items']) ? $body['SearchResult']['Items'] : array();
    set_transient($cache_key, $items, HOUR_IN_SECONDS * intval($o['cache_hours']));
    return $items;
}

function vipsvault_amazon_item_price($item){
    if(isset($item['OffersV2']['Listings'][0]['Price']['DisplayAmount'])) return $item['OffersV2']['Listings'][0]['Price']['DisplayAmount'];
    if(isset($item['Offers']['Listings'][0]['Price']['DisplayAmount'])) return $item['Offers']['Listings'][0]['Price']['DisplayAmount'];
    return '';
}

function vipsvault_amazon_render($keywords, $item_count = 4, $title = 'Amazon Memorabilia'){
    $items = vipsvault_amazon_search_items($keywords, $item_count);
    ob_start();
    echo '<section class="api-box amazon-memorabilia-box"><h2>'.esc_html($title).'</h2>';
    if(is_wp_error($items)){
        echo '<div class="api-embed vv-amazon-error">'.esc_html($items->get_error_message()).'</div></section>';
        return ob_get_clean();
    }
    if(empty($items)){
        echo '<div class="api-embed">No Amazon memorabilia items found for <strong>'.esc_html($keywords).'</strong>.</div></section>';
        return ob_get_clean();
    }
    echo '<div class="amazon-products-grid">';
    foreach($items as $item){
        $title_text = $item['ItemInfo']['Title']['DisplayValue'] ?? 'Amazon item';
        $url = $item['DetailPageURL'] ?? '#';
        $img = $item['Images']['Primary']['Medium']['URL'] ?? '';
        $price = vipsvault_amazon_item_price($item);
        echo '<a class="amazon-product-card" href="'.esc_url($url).'" target="_blank" rel="nofollow sponsored noopener">';
        if($img) echo '<img src="'.esc_url($img).'" alt="'.esc_attr($title_text).'">';
        echo '<span class="amazon-title">'.esc_html($title_text).'</span>';
        if($price) echo '<strong class="amazon-price">'.esc_html($price).'</strong>';
        echo '<span class="amazon-button">View on Amazon</span></a>';
    }
    echo '</div></section>';
    return ob_get_clean();
}

function vipsvault_amazon_shortcode($atts){
    $atts = shortcode_atts(array('keywords'=>'','item_count'=>4,'title'=>'Amazon Memorabilia'), $atts, 'vipsvault_amazon');
    return vipsvault_amazon_render($atts['keywords'], $atts['item_count'], $atts['title']);
}
add_shortcode('vipsvault_amazon','vipsvault_amazon_shortcode');

function vipsvault_vip_amazon_box($position = 'bottom', $vip_id = null){
    $vip_id = $vip_id ?: get_the_ID();
    $keywords = get_post_meta($vip_id, $position === 'top' ? '_vip_amazon_keywords_top' : '_vip_amazon_keywords_bottom', true);
    if(!$keywords) $keywords = get_post_meta($vip_id, '_vip_amazon_keywords', true);
    if(!$keywords) $keywords = (get_post_meta($vip_id, '_vip_full_name', true) ?: get_the_title($vip_id)) . ' memorabilia';
    $count = get_post_meta($vip_id, '_vip_amazon_item_count', true);
    $count = $count ? intval($count) : 4;
    $title = $position === 'top' ? 'Featured Amazon Memorabilia' : 'Related Amazon Memorabilia';
    echo vipsvault_amazon_render($keywords, $count, $title);
}
