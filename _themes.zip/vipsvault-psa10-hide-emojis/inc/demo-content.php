<?php
if (!defined('ABSPATH')) { exit; }

function vipsvault_demo_card_svgs() {
    return array(
        'vault-sports.svg' => array('#f5c542', '#ff3d81', 'SPORTS', 'GRADED ICON'),
        'vault-celebrity.svg' => array('#55d6ff', '#ff3d81', 'CELEBRITY', 'STAR CARD'),
        'vault-music.svg' => array('#a855f7', '#f5c542', 'MUSIC', 'LEGEND VAULT'),
        'vault-movie.svg' => array('#22c55e', '#55d6ff', 'MOVIE', 'SCREEN ICON'),
        'vault-auto.svg' => array('#fb7185', '#facc15', 'AUTO', 'SIGNED CARD'),
        'vault-rookie.svg' => array('#38bdf8', '#818cf8', 'ROOKIE', 'FIRST YEAR'),
    );
}

function vipsvault_create_demo_svgs() {
    $dir = get_template_directory() . '/assets/cards';
    if (!file_exists($dir)) { wp_mkdir_p($dir); }
    foreach (vipsvault_demo_card_svgs() as $file => $d) {
        $path = trailingslashit($dir) . $file;
        if (file_exists($path)) { continue; }
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="900" height="1200" viewBox="0 0 900 1200"><defs><linearGradient id="g" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="'.$d[0].'"/><stop offset="1" stop-color="'.$d[1].'"/></linearGradient><radialGradient id="r" cx="50%" cy="24%" r="60%"><stop offset="0" stop-color="#fff" stop-opacity=".35"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient></defs><rect width="900" height="1200" fill="#090a12"/><rect x="42" y="42" width="816" height="1116" rx="64" fill="url(#g)"/><rect x="78" y="78" width="744" height="1044" rx="46" fill="#111322" opacity=".92"/><rect x="112" y="116" width="676" height="610" rx="36" fill="url(#r)"/><circle cx="450" cy="370" r="155" fill="#fff" opacity=".13"/><path d="M210 760h480v26H210zM250 825h400v20H250zM295 885h310v18H295z" fill="#fff" opacity=".55"/><text x="450" y="965" font-family="Arial, sans-serif" font-size="54" font-weight="900" text-anchor="middle" fill="#ffffff">'.$d[2].'</text><text x="450" y="1036" font-family="Arial, sans-serif" font-size="38" font-weight="700" text-anchor="middle" fill="#f5c542">'.$d[3].'</text><text x="450" y="1102" font-family="Arial, sans-serif" font-size="24" font-weight="700" text-anchor="middle" fill="#a8aec7">VIPSVault.com</text></svg>';
        file_put_contents($path, $svg);
    }
}

function vipsvault_demo_attachment($filename, $title) {
    vipsvault_create_demo_svgs();
    $source_path = get_template_directory() . '/assets/cards/' . $filename;
    if (!file_exists($source_path)) { return 0; }
    $existing = get_posts(array('post_type'=>'attachment','post_status'=>'inherit','meta_key'=>'_vipsvault_demo_file','meta_value'=>$filename,'fields'=>'ids','posts_per_page'=>1));
    if (!empty($existing)) { return (int) $existing[0]; }

    $upload_dir = wp_upload_dir();
    $target_dir = trailingslashit($upload_dir['basedir']) . 'vipsvault-demo';
    if (!file_exists($target_dir)) { wp_mkdir_p($target_dir); }
    $target_path = trailingslashit($target_dir) . $filename;
    copy($source_path, $target_path);

    $attachment_id = wp_insert_attachment(array(
        'guid' => trailingslashit($upload_dir['baseurl']) . 'vipsvault-demo/' . $filename,
        'post_mime_type' => 'image/svg+xml',
        'post_title' => sanitize_text_field($title),
        'post_content' => '',
        'post_status' => 'inherit'
    ), $target_path);
    if (!is_wp_error($attachment_id)) {
        update_post_meta($attachment_id, '_wp_attached_file', 'vipsvault-demo/' . $filename);
        update_post_meta($attachment_id, '_vipsvault_demo_file', $filename);
        return (int) $attachment_id;
    }
    return 0;
}

function vipsvault_demo_posts_data() {
    return array(
        array('title'=>'Michael Jordan 1990s Tribute Card - PSA 10', 'cat'=>'Sports', 'tags'=>array('Basketball','Graded Cards','Michael Jordan'), 'image'=>'vault-sports.svg', 'meta'=>array('_vv_person_name'=>'Michael Jordan','_vv_profession'=>'Basketball','_vv_team_role'=>'Chicago Basketball Legend','_vv_year'=>'1996','_vv_brand'=>'VIPSVault Tribute Series','_vv_card_number'=>'VVS-023','_vv_condition'=>'Gem Mint','_vv_grade'=>'PSA 10','_vv_price'=>'$2,499','_vv_marketplace_url'=>'#','_vv_rookie'=>'','_vv_autograph'=>'','_vv_relic'=>'','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
        array('title'=>'Taylor Swift Music Icon Foil Card', 'cat'=>'Music', 'tags'=>array('Music','Pop Culture','Foil'), 'image'=>'vault-music.svg', 'meta'=>array('_vv_person_name'=>'Taylor Swift','_vv_profession'=>'Music Artist','_vv_team_role'=>'Global Pop Icon','_vv_year'=>'2024','_vv_brand'=>'Stage Lights Collection','_vv_card_number'=>'SL-013','_vv_condition'=>'Near Mint','_vv_grade'=>'Raw','_vv_price'=>'$189','_vv_marketplace_url'=>'#','_vv_rookie'=>'','_vv_autograph'=>'','_vv_relic'=>'','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
        array('title'=>'Tom Brady Championship Legacy Card', 'cat'=>'Sports', 'tags'=>array('Football','Tom Brady','Championship'), 'image'=>'vault-rookie.svg', 'meta'=>array('_vv_person_name'=>'Tom Brady','_vv_profession'=>'Football','_vv_team_role'=>'Championship Quarterback','_vv_year'=>'2000','_vv_brand'=>'Legacy Vault','_vv_card_number'=>'LV-012','_vv_condition'=>'Excellent','_vv_grade'=>'BGS 9','_vv_price'=>'$1,250','_vv_marketplace_url'=>'#','_vv_rookie'=>'Yes','_vv_autograph'=>'','_vv_relic'=>'','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
        array('title'=>'Marilyn Monroe Classic Hollywood Card', 'cat'=>'Celebrities', 'tags'=>array('Hollywood','Celebrity','Vintage'), 'image'=>'vault-celebrity.svg', 'meta'=>array('_vv_person_name'=>'Marilyn Monroe','_vv_profession'=>'Actor / Celebrity','_vv_team_role'=>'Classic Hollywood Star','_vv_year'=>'1955','_vv_brand'=>'Hollywood Vault','_vv_card_number'=>'HV-007','_vv_condition'=>'Very Good','_vv_grade'=>'Raw','_vv_price'=>'$325','_vv_marketplace_url'=>'#','_vv_rookie'=>'','_vv_autograph'=>'','_vv_relic'=>'','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
        array('title'=>'Elvis Presley Signed Style Display Card', 'cat'=>'Autographs', 'tags'=>array('Music','Autograph','Elvis Presley'), 'image'=>'vault-auto.svg', 'meta'=>array('_vv_person_name'=>'Elvis Presley','_vv_profession'=>'Music Legend','_vv_team_role'=>'Rock and Roll Icon','_vv_year'=>'1972','_vv_brand'=>'Signature Vault','_vv_card_number'=>'SV-001','_vv_condition'=>'Near Mint','_vv_grade'=>'Authenticated','_vv_price'=>'$4,800','_vv_marketplace_url'=>'#','_vv_rookie'=>'','_vv_autograph'=>'Yes','_vv_relic'=>'','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
        array('title'=>'Star Wars Screen Legend Collector Card', 'cat'=>'Movies & TV', 'tags'=>array('Movies','Sci-Fi','Pop Culture'), 'image'=>'vault-movie.svg', 'meta'=>array('_vv_person_name'=>'Screen Legend','_vv_profession'=>'Movie Character','_vv_team_role'=>'Sci-Fi Franchise Icon','_vv_year'=>'1980','_vv_brand'=>'Cinema Vault','_vv_card_number'=>'CV-080','_vv_condition'=>'Near Mint','_vv_grade'=>'SGC 9','_vv_price'=>'$675','_vv_marketplace_url'=>'#','_vv_rookie'=>'','_vv_autograph'=>'','_vv_relic'=>'','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
        array('title'=>'Babe Ruth Vintage Baseball Vault Card', 'cat'=>'Sports', 'tags'=>array('Baseball','Vintage','Babe Ruth'), 'image'=>'vault-sports.svg', 'meta'=>array('_vv_person_name'=>'Babe Ruth','_vv_profession'=>'Baseball','_vv_team_role'=>'New York Baseball Legend','_vv_year'=>'1933','_vv_brand'=>'Vintage Vault Reissue','_vv_card_number'=>'VV-033','_vv_condition'=>'Good','_vv_grade'=>'PSA 4','_vv_price'=>'$3,200','_vv_marketplace_url'=>'#','_vv_rookie'=>'','_vv_autograph'=>'','_vv_relic'=>'Yes','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
        array('title'=>'Beyonce Superstar Performance Card', 'cat'=>'Music', 'tags'=>array('Music','Celebrity','Performance'), 'image'=>'vault-music.svg', 'meta'=>array('_vv_person_name'=>'Beyonce','_vv_profession'=>'Music Artist','_vv_team_role'=>'Live Performance Icon','_vv_year'=>'2023','_vv_brand'=>'Superstar Stage Set','_vv_card_number'=>'SS-004','_vv_condition'=>'Mint','_vv_grade'=>'Raw','_vv_price'=>'$225','_vv_marketplace_url'=>'#','_vv_rookie'=>'','_vv_autograph'=>'','_vv_relic'=>'','_vv_front_image'=>'','_vv_back_image'=>'','_vv_ebay_shortcode'=>'')),
    );
}


function vipsvault_homepage_demo_content() {
    $logo = esc_url(get_template_directory_uri() . '/assets/vipsvault-logo.png');
    $vault_url = esc_url(get_post_type_archive_link('vip_collectible'));
    $add_url = esc_url(admin_url('post-new.php?post_type=vip_collectible'));
    return '<!-- wp:group {"className":"vv-hero-edit","layout":{"type":"constrained"}} -->
<div class="wp-block-group vv-hero-edit"><!-- wp:columns {"verticalAlignment":"center","className":"vv-hero-columns"} -->
<div class="wp-block-columns are-vertically-aligned-center vv-hero-columns"><!-- wp:column {"verticalAlignment":"center","width":"45%","className":"vv-hero-image"} -->
<div class="wp-block-column is-vertically-aligned-center vv-hero-image" style="flex-basis:45%"><!-- wp:image {"sizeSlug":"large","linkDestination":"none"} -->
<figure class="wp-block-image size-large"><img src="' . $logo . '" alt="VIPSVault logo vault image"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","width":"55%","className":"vv-hero-copy"} -->
<div class="wp-block-column is-vertically-aligned-center vv-hero-copy" style="flex-basis:55%"><!-- wp:paragraph {"className":"kicker"} -->
<p class="kicker">The Vault for Iconic Collectibles</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":1} -->
<h1>Rare cards. Famous names. One powerful vault.</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>VIPSVault.com showcases sports cards, celebrity cards, music legends, movie icons, autographs, graded collectibles, and memorabilia with a premium visual experience built to get attention.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"className":"hero-actions"} -->
<div class="wp-block-buttons hero-actions"><!-- wp:button {"className":"btn btn-primary"} -->
<div class="wp-block-button btn btn-primary"><a class="wp-block-button__link wp-element-button" href="' . $vault_url . '">Explore The Vault</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"btn btn-secondary"} -->
<div class="wp-block-button btn btn-secondary"><a class="wp-block-button__link wp-element-button" href="' . $add_url . '">Add Collectible</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->';
}

function vipsvault_import_demo_content($force = false) {
    if (!$force && get_option('vipsvault_demo_imported')) { return; }
    vipsvault_add_default_terms();
    vipsvault_create_demo_svgs();

    foreach (vipsvault_demo_posts_data() as $item) {
        $exists = get_page_by_title($item['title'], OBJECT, 'vip_collectible');
        if ($exists) { continue; }
        $post_id = wp_insert_post(array(
            'post_type' => 'vip_collectible',
            'post_title' => $item['title'],
            'post_excerpt' => 'A premium demo collectible listing built for VIPSVault.com.',
            'post_content' => '<p>This demo listing shows how VIPSVault can present sports cards, celebrity cards, music collectibles, movie icons, autographs, graded cards, and memorabilia in a clean marketplace-style layout.</p><p>Replace this sample text with the card story, ownership notes, grading details, condition notes, and marketplace information.</p>',
            'post_status' => 'publish'
        ));
        if (is_wp_error($post_id) || !$post_id) { continue; }
        wp_set_object_terms($post_id, $item['cat'], 'collectible_category');
        wp_set_object_terms($post_id, $item['tags'], 'collectible_tag');
        foreach ($item['meta'] as $key => $value) { update_post_meta($post_id, $key, $value); }
        $attachment_id = vipsvault_demo_attachment($item['image'], $item['title']);
        if ($attachment_id) { set_post_thumbnail($post_id, $attachment_id); }
    }

    $home_id = get_option('page_on_front');
    if (!$home_id) {
        $home = get_page_by_title('VIPSVault Home');
        if (!$home) {
            $hero_content = vipsvault_homepage_demo_content();
            $home_id = wp_insert_post(array('post_type'=>'page','post_title'=>'VIPSVault Home','post_content'=>$hero_content,'post_status'=>'publish'));
        } else { $home_id = $home->ID; wp_update_post(array('ID'=>$home_id, 'post_content'=>vipsvault_homepage_demo_content())); }
        if ($home_id && !is_wp_error($home_id)) {
            update_option('show_on_front', 'page');
            update_option('page_on_front', $home_id);
        }
    }

    $about = get_page_by_title('About VIPSVault');
    if (!$about) {
        wp_insert_post(array('post_type'=>'page','post_title'=>'About VIPSVault','post_content'=>'<h2>The vault for iconic collectibles</h2><p>VIPSVault.com is built to showcase cards and collectibles tied to athletes, celebrities, musicians, movie stars, pop culture icons, autographs, memorabilia, and graded cards.</p>','post_status'=>'publish'));
    }
    $sell = get_page_by_title('Sell Your Collectibles');
    if (!$sell) {
        wp_insert_post(array('post_type'=>'page','post_title'=>'Sell Your Collectibles','post_content'=>'<h2>List your cards and collectibles</h2><p>Use VIP Collectibles in the dashboard to add the person, category, year, set, grade, condition, price, marketplace link, front image, and back image.</p>','post_status'=>'publish'));
    }

    if (!wp_get_nav_menu_object('VIPSVault Main Menu')) {
        $menu_id = wp_create_nav_menu('VIPSVault Main Menu');
        if (!is_wp_error($menu_id)) {
            wp_update_nav_menu_item($menu_id, 0, array('menu-item-title'=>'Home','menu-item-url'=>home_url('/'),'menu-item-status'=>'publish'));
            wp_update_nav_menu_item($menu_id, 0, array('menu-item-title'=>'The Vault','menu-item-url'=>get_post_type_archive_link('vip_collectible'),'menu-item-status'=>'publish'));
            foreach (array('Sports','Celebrities','Music','Movies & TV','Autographs') as $term_name) {
                $term = get_term_by('name', $term_name, 'collectible_category');
                if ($term) { wp_update_nav_menu_item($menu_id, 0, array('menu-item-title'=>$term_name,'menu-item-url'=>get_term_link($term),'menu-item-status'=>'publish')); }
            }
            $locations = get_theme_mod('nav_menu_locations');
            $locations['primary'] = $menu_id;
            set_theme_mod('nav_menu_locations', $locations);
        }
    }

    update_option('vipsvault_demo_imported', current_time('mysql'));
    flush_rewrite_rules();
}
add_action('after_switch_theme', function() { vipsvault_import_demo_content(false); });

function vipsvault_demo_admin_menu() {
    add_theme_page('VIPSVault Demo Content', 'VIPSVault Demo', 'manage_options', 'vipsvault-demo', 'vipsvault_demo_admin_page');
}
add_action('admin_menu', 'vipsvault_demo_admin_menu');

function vipsvault_demo_admin_page() {
    if (!current_user_can('manage_options')) { return; }
    if (isset($_POST['vipsvault_import_demo']) && check_admin_referer('vipsvault_import_demo_action')) {
        vipsvault_import_demo_content(true);
        echo '<div class="notice notice-success"><p>VIPSVault demo content imported.</p></div>';
    }
    echo '<div class="wrap"><h1>VIPSVault Demo Content</h1><p>This theme includes demo collectibles, categories, tags, pages, a menu, and placeholder card artwork.</p><form method="post">';
    wp_nonce_field('vipsvault_import_demo_action');
    echo '<p><button class="button button-primary" name="vipsvault_import_demo" value="1">Import / Rebuild Demo Content</button></p></form></div>';
}
