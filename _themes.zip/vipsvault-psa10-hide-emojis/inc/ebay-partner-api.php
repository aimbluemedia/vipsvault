<?php
if(!defined('ABSPATH')) exit;

/**
 * VIPSVault eBay Partner Network / Browse API Memorabilia Integration
 * Adds Appearance > VIPSVault eBay API settings, VIP keyword fields,
 * shortcode [vipsvault_ebay keywords="frank sinatra memorabilia" item_count="4"],
 * cached eBay Browse API Search results with affiliate tracking URLs.
 */
function vipsvault_ebay_default_options(){
    return array(
        'client_id' => '', // App ID / Client ID
        'dev_id' => '', // Dev ID is stored for completeness; Browse API OAuth does not send it.
        'client_secret' => '', // Cert ID / Client Secret
        'campaign_id' => '',
        'custom_id' => 'vipsvault',
        'marketplace_id' => 'EBAY_US',
        'endpoint' => 'https://api.ebay.com',
        'cache_hours' => 12,
        'debug' => 0,
        'fallback_links' => 1,
        'last_error' => '',
        'last_test' => '',
    );
}
function vipsvault_ebay_options(){
    $saved = get_option('vipsvault_ebay_options', array());
    return wp_parse_args(is_array($saved) ? $saved : array(), vipsvault_ebay_default_options());
}
function vipsvault_ebay_admin_menu(){
    add_theme_page('VIPSVault eBay API', 'VIPSVault eBay API', 'manage_options', 'vipsvault-ebay-api', 'vipsvault_ebay_settings_page');
}
add_action('admin_menu','vipsvault_ebay_admin_menu');
function vipsvault_ebay_register_settings(){
    register_setting('vipsvault_ebay_group', 'vipsvault_ebay_options', 'vipsvault_ebay_sanitize_options');
}
add_action('admin_init','vipsvault_ebay_register_settings');
function vipsvault_ebay_sanitize_options($input){
    $defaults = vipsvault_ebay_default_options();
    $out = array();
    $out['client_id'] = sanitize_text_field($input['client_id'] ?? '');
    $out['dev_id'] = sanitize_text_field($input['dev_id'] ?? '');
    $out['client_secret'] = sanitize_text_field($input['client_secret'] ?? '');
    $out['campaign_id'] = sanitize_text_field($input['campaign_id'] ?? '');
    $out['custom_id'] = sanitize_text_field($input['custom_id'] ?? 'vipsvault');
    $out['marketplace_id'] = sanitize_text_field($input['marketplace_id'] ?? $defaults['marketplace_id']);
    $out['endpoint'] = esc_url_raw($input['endpoint'] ?? $defaults['endpoint']);
    $out['cache_hours'] = max(1, min(72, intval($input['cache_hours'] ?? 12)));
    $out['debug'] = 0;
    $out['fallback_links'] = !empty($input['fallback_links']) ? 1 : 0;
    $out['last_error'] = sanitize_textarea_field($input['last_error'] ?? '');
    $out['last_test'] = sanitize_text_field($input['last_test'] ?? '');
    delete_transient('vipsvault_ebay_oauth_token');
    return $out;
}
function vipsvault_ebay_settings_page(){
    if(!current_user_can('manage_options')) return;
    $o = vipsvault_ebay_options();
    if(isset($_POST['vipsvault_ebay_clear_cache']) && check_admin_referer('vipsvault_ebay_tools')){
        delete_transient('vipsvault_ebay_oauth_token');
        echo '<div class="notice notice-success"><p>eBay token cache cleared.</p></div>';
    }
    if(isset($_POST['vipsvault_ebay_test']) && check_admin_referer('vipsvault_ebay_tools')){
        delete_transient('vipsvault_ebay_oauth_token');
        $test_keywords = sanitize_text_field($_POST['vv_test_keywords'] ?? 'Frank Sinatra memorabilia');
        $test = vipsvault_ebay_search_items($test_keywords, 1, true);
        if(is_wp_error($test)){
            $msg = $test->get_error_message();
            vipsvault_ebay_store_last_error($msg);
            echo '<div class="notice notice-error"><p><strong>eBay test failed:</strong> '.esc_html($msg).'</p></div>';
        } else {
            echo '<div class="notice notice-success"><p>eBay test successful. Returned '.count($test).' item(s).</p></div>';
        }
        $o = vipsvault_ebay_options();
    }
    ?>
    <div class="wrap">
        <h1>VIPSVault eBay API</h1>
        <p>Connect eBay Buy Browse API and eBay Partner Network so VIP pages can display affiliate memorabilia products. Use <code>[vipsvault_ebay keywords="frank sinatra memorabilia" item_count="4"]</code> in any memorabilia field.</p>
        <div class="notice notice-info"><p><strong>Use your three eBay Developer keys here:</strong> App ID goes in Client ID, Dev ID goes in Dev ID, and Cert ID goes in Client Secret. The modern Browse API uses App ID + Cert ID to create an OAuth app token; Dev ID is saved in the settings but is mainly for legacy APIs.</p></div>
        <form method="post" action="options.php">
            <?php settings_fields('vipsvault_ebay_group'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="vv_ebay_client_id">App ID / Client ID</label></th><td><input class="regular-text" id="vv_ebay_client_id" name="vipsvault_ebay_options[client_id]" value="<?php echo esc_attr($o['client_id']); ?>"><p class="description">Paste your eBay App ID here. Use Production keys, not Sandbox keys, for live eBay.com results.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_dev_id">Dev ID</label></th><td><input class="regular-text" id="vv_ebay_dev_id" name="vipsvault_ebay_options[dev_id]" value="<?php echo esc_attr($o['dev_id'] ?? ''); ?>"><p class="description">Stored for your eBay keyset. The Buy Browse API token flow does not send this field, but keeping it here makes your keyset complete.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_client_secret">Cert ID / Client Secret</label></th><td><input class="regular-text" type="password" id="vv_ebay_client_secret" name="vipsvault_ebay_options[client_secret]" value="<?php echo esc_attr($o['client_secret']); ?>"><p class="description">Paste your eBay Cert ID here. It must be from the same Production keyset as the App ID.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_campaign_id">ePN Campaign ID</label></th><td><input class="regular-text" id="vv_ebay_campaign_id" name="vipsvault_ebay_options[campaign_id]" value="<?php echo esc_attr($o['campaign_id']); ?>" placeholder="10 digit campaign ID"><p class="description">This is your eBay Partner Network campid. It is not your App ID.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_custom_id">Affiliate Reference ID / Custom ID</label></th><td><input class="regular-text" id="vv_ebay_custom_id" name="vipsvault_ebay_options[custom_id]" value="<?php echo esc_attr($o['custom_id']); ?>" placeholder="vipsvault"><p class="description">Optional tracking label. eBay calls this customid / SUB-ID.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_marketplace">Marketplace ID</label></th><td><input class="regular-text" id="vv_ebay_marketplace" name="vipsvault_ebay_options[marketplace_id]" value="<?php echo esc_attr($o['marketplace_id']); ?>" placeholder="EBAY_US"><p class="description">Examples: EBAY_US, EBAY_GB, EBAY_CA, EBAY_AU.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_endpoint">API Endpoint</label></th><td><input class="regular-text" id="vv_ebay_endpoint" name="vipsvault_ebay_options[endpoint]" value="<?php echo esc_attr($o['endpoint']); ?>" placeholder="https://api.ebay.com"><p class="description">Live: https://api.ebay.com. Sandbox: https://api.sandbox.ebay.com.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_cache">Cache Hours</label></th><td><input type="number" min="1" max="72" id="vv_ebay_cache" name="vipsvault_ebay_options[cache_hours]" value="<?php echo esc_attr($o['cache_hours']); ?>"></td></tr>
                <tr><th scope="row">Fallback Search Links</th><td><label><input type="checkbox" name="vipsvault_ebay_options[fallback_links]" value="1" <?php checked($o['fallback_links'],1); ?>> If API fails, show a direct eBay search button instead of a blank section</label></td></tr>
                <input type="hidden" name="vipsvault_ebay_options[last_error]" value="<?php echo esc_attr($o['last_error']); ?>">
                <input type="hidden" name="vipsvault_ebay_options[last_test]" value="<?php echo esc_attr($o['last_test']); ?>">
            </table>
            <?php submit_button('Save eBay API Settings'); ?>
        </form>
        <hr>
        <h2>Test Connection</h2>
        <form method="post">
            <?php wp_nonce_field('vipsvault_ebay_tools'); ?>
            <p><input class="regular-text" name="vv_test_keywords" value="Frank Sinatra memorabilia"> <button class="button button-primary" name="vipsvault_ebay_test" value="1">Run eBay API Test</button> <button class="button" name="vipsvault_ebay_clear_cache" value="1">Clear Token Cache</button></p>
        </form>
        <?php if(!empty($o['last_error'])): ?><h2>Last eBay Error</h2><textarea class="large-text code" rows="5" readonly><?php echo esc_textarea($o['last_error']); ?></textarea><?php endif; ?>
        <h2>Shortcode Examples</h2>
        <p><code>[vipsvault_ebay keywords="Frank Sinatra memorabilia" item_count="4"]</code></p>
        <p><code>[vipsvault_ebay keywords="Harry Potter cards" item_count="6" title="Harry Potter on eBay"]</code></p>
    </div>
    <?php
}
function vipsvault_ebay_store_last_error($message){
    $o = vipsvault_ebay_options();
    $o['last_error'] = wp_strip_all_tags((string)$message);
    $o['last_test'] = current_time('mysql');
    update_option('vipsvault_ebay_options', $o, false);
}
function vipsvault_ebay_error_to_message($error){
    if(!is_wp_error($error)) return '';
    return $error->get_error_message();
}
function vipsvault_ebay_affiliate_search_url($keywords){
    $o = vipsvault_ebay_options();
    $url = 'https://www.ebay.com/sch/i.html?_nkw=' . rawurlencode($keywords);
    if(!empty($o['campaign_id'])){
        $url .= '&mkevt=1&mkcid=1&mkrid=711-53200-19255-0&campid=' . rawurlencode($o['campaign_id']) . '&toolid=10001';
        if(!empty($o['custom_id'])) $url .= '&customid=' . rawurlencode($o['custom_id']);
    }
    return $url;
}
function vipsvault_ebay_is_configured(){
    $o = vipsvault_ebay_options();
    return !empty($o['client_id']) && !empty($o['client_secret']);
}
function vipsvault_ebay_get_token(){
    $o = vipsvault_ebay_options();
    $cached = get_transient('vipsvault_ebay_oauth_token');
    if($cached) return $cached;
    if(!vipsvault_ebay_is_configured()) return new WP_Error('not_configured','eBay API is not configured. Add App ID / Client ID and Cert ID / Client Secret in Appearance > VIPSVault eBay API.');
    $url = trailingslashit($o['endpoint']) . 'identity/v1/oauth2/token';
    $response = wp_remote_post($url, array(
        'timeout' => 20,
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($o['client_id'] . ':' . $o['client_secret']),
            'Content-Type' => 'application/x-www-form-urlencoded',
        ),
        'body' => http_build_query(array('grant_type'=>'client_credentials','scope'=>'https://api.ebay.com/oauth/api_scope')),
    ));
    if(is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if($code < 200 || $code >= 300 || empty($body['access_token'])){
        $err = new WP_Error('token_failed', 'eBay OAuth failed: HTTP '.$code.' '.wp_remote_retrieve_body($response)); vipsvault_ebay_store_last_error($err->get_error_message()); return $err;
    }
    $ttl = max(300, intval($body['expires_in'] ?? 7200) - 300);
    set_transient('vipsvault_ebay_oauth_token', $body['access_token'], $ttl);
    return $body['access_token'];
}
function vipsvault_ebay_clean_keywords($keywords){
    $keywords = trim(wp_strip_all_tags((string)$keywords));
    $keywords = html_entity_decode($keywords, ENT_QUOTES, get_bloginfo('charset'));
    $keywords = str_replace(array('+','%20'), ' ', $keywords);
    $keywords = preg_replace('/\s+/', ' ', $keywords);
    return trim($keywords);
}
function vipsvault_ebay_parse_input($input, $default_count = 4, $default_title = ''){
    $raw = trim((string)$input);
    $out = array(
        'keywords' => vipsvault_ebay_clean_keywords($raw),
        'item_count' => max(1, min(20, intval($default_count ?: 4))),
        'title' => $default_title,
    );
    if($raw === '') return $out;

    // Accept either plain keywords OR a full shortcode pasted into the VIP field.
    if(stripos($raw, '[vipsvault_ebay') !== false || stripos($raw, '[ebay_search') !== false){
        $inner = trim($raw, "[] \t\n\r\0\x0B");
        $inner = preg_replace('/^(vipsvault_ebay|ebay_search)\s*/i', '', $inner);
        $atts = shortcode_parse_atts($inner);
        if(is_array($atts)){
            if(!empty($atts['keywords'])) $out['keywords'] = vipsvault_ebay_clean_keywords($atts['keywords']);
            if(!empty($atts['item_count'])) $out['item_count'] = max(1, min(20, intval($atts['item_count'])));
            if(!empty($atts['title'])) $out['title'] = sanitize_text_field($atts['title']);
        }
    }
    return $out;
}

function vipsvault_ebay_search_items($keywords, $limit = 4, $force = false){
    $o = vipsvault_ebay_options();
    $keywords = vipsvault_ebay_clean_keywords($keywords);
    $limit = max(1, min(20, intval($limit)));
    if($keywords === '') return new WP_Error('missing_keywords','No eBay keywords were provided.');
    $cache_key = 'vv_ebay_' . md5(strtolower($keywords).'|'.$limit.'|'.$o['marketplace_id'].'|'.$o['campaign_id'].'|v2');
    $cached = get_transient($cache_key);
    if(!$force && $cached !== false) return $cached;
    $token = vipsvault_ebay_get_token();
    if(is_wp_error($token)){ vipsvault_ebay_store_last_error($token->get_error_message()); return $token; }
    $url = trailingslashit($o['endpoint']) . 'buy/browse/v1/item_summary/search?' . http_build_query(array('q'=>$keywords,'limit'=>$limit));
    $headers = array(
        'Authorization' => 'Bearer ' . $token,
        'X-EBAY-C-MARKETPLACE-ID' => $o['marketplace_id'],
        'Accept' => 'application/json',
    );
    if(!empty($o['campaign_id'])){
        $ctx = 'affiliateCampaignId=' . rawurlencode($o['campaign_id']);
        if(!empty($o['custom_id'])) $ctx .= ',affiliateReferenceId=' . rawurlencode($o['custom_id']);
        $headers['X-EBAY-C-ENDUSERCTX'] = $ctx;
    }
    $response = wp_remote_get($url, array('timeout'=>20, 'headers'=>$headers));
    if(is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $body = json_decode($raw, true);
    if($code < 200 || $code >= 300){ $err = new WP_Error('search_failed', 'eBay Search failed: HTTP '.$code.' '.$raw); vipsvault_ebay_store_last_error($err->get_error_message()); return $err; }
    $items = isset($body['itemSummaries']) && is_array($body['itemSummaries']) ? $body['itemSummaries'] : array();
    set_transient($cache_key, $items, HOUR_IN_SECONDS * intval($o['cache_hours']));
    return $items;
}
function vipsvault_ebay_keyword_variations($keywords){
    $keywords = vipsvault_ebay_clean_keywords($keywords);
    $base = $keywords;
    $variations = array();
    if($base !== '') $variations[] = $base;
    foreach(array('memorabilia','autograph','signed photo','trading card','collectible','card') as $suffix){
        if($base && stripos($base, $suffix) === false) $variations[] = trim($base . ' ' . $suffix);
    }
    return array_values(array_unique(array_filter($variations)));
}
function vipsvault_ebay_search_with_fallbacks($keywords, $limit = 4){
    $searched = array();
    $last_error = null;
    foreach(vipsvault_ebay_keyword_variations($keywords) as $term){
        $items = vipsvault_ebay_search_items($term, $limit);
        $searched[] = array('term'=>$term, 'count'=>is_wp_error($items) ? 'error' : count($items));
        if(is_wp_error($items)){ $last_error = $items; break; }
        if(!empty($items)) return array('items'=>$items, 'used_term'=>$term, 'searched'=>$searched, 'error'=>null);
    }
    return array('items'=>array(), 'used_term'=>$keywords, 'searched'=>$searched, 'error'=>$last_error);
}

function vipsvault_ebay_affiliate_item_url($url){
    $url = trim((string)$url);
    if($url === '') return '#';
    $o = vipsvault_ebay_options();
    $parts = wp_parse_url($url);
    if(empty($parts['host'])) return $url;
    $base = $parts['scheme'].'://'.$parts['host'].($parts['path'] ?? '');
    $query = array();
    if(!empty($parts['query'])) parse_str($parts['query'], $query);
    unset($query['_skw']);
    if(!empty($o['campaign_id'])){
        $query['mkevt']='1'; $query['mkcid']='1'; $query['mkrid']='711-53200-19255-0'; $query['campid']=$o['campaign_id']; $query['customid']=$o['custom_id']; $query['toolid']='10049';
    }
    return $base . (!empty($query) ? '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986) : '');
}

function vipsvault_ebay_render_products($keywords, $limit = 4, $title = 'eBay Memorabilia'){
    $o = vipsvault_ebay_options();
    $result = vipsvault_ebay_search_with_fallbacks($keywords, $limit);
    $items = $result['items'];
    echo '<section class="ebay-memorabilia-box api-box"><h2>'.esc_html($title).'</h2>';
    if(is_wp_error($result['error'])){
        $message = 'Memorabilia is temporarily unavailable. Please check back soon.';
        echo '<p class="vv-ebay-error">'.esc_html($message).'</p>';
        if(!empty($o['fallback_links'])){
            echo '<p><a class="btn btn-primary" target="_blank" rel="nofollow sponsored noopener" href="'.esc_url(vipsvault_ebay_affiliate_search_url($keywords)).'">Search '.esc_html($keywords).' on eBay</a></p>';
        }
        echo '</section>'; return;
    }
    if(empty($items)){
        echo '<p class="meta-line">No memorabilia currently available for this VIP. Check back soon as new items are added daily.</p>';
        if(!empty($o['fallback_links'])) echo '<p><a class="btn btn-primary" target="_blank" rel="nofollow sponsored noopener" href="'.esc_url(vipsvault_ebay_affiliate_search_url($keywords)).'">Search '.esc_html($keywords).' on eBay</a></p>';
        echo '</section>'; return;
    }
    echo '<div class="ebay-products-grid">';
    foreach($items as $item){
        $url = vipsvault_ebay_affiliate_item_url($item['itemAffiliateWebUrl'] ?? ($item['itemWebUrl'] ?? '#'));
        $image = $item['image']['imageUrl'] ?? '';
        $item_title = $item['title'] ?? 'eBay item';
        $price = '';
        if(!empty($item['price']['value'])) $price = ($item['price']['currency'] ?? 'USD') . ' ' . $item['price']['value'];
        echo '<a class="ebay-product-card" target="_blank" rel="nofollow sponsored noopener" href="'.esc_url($url).'">';
        if($image) echo '<img src="'.esc_url($image).'" alt="'.esc_attr($item_title).'">';
        echo '<span class="ebay-title">'.esc_html($item_title).'</span>';
        if($price) echo '<strong class="ebay-price">'.esc_html($price).'</strong>';
        echo '<span class="ebay-button">View on eBay</span></a>';
    }
    echo '</div></section>';
}
function vipsvault_ebay_shortcode($atts){
    $atts = shortcode_atts(array('keywords'=>'','item_count'=>'4','title'=>'eBay Memorabilia'), $atts, 'vipsvault_ebay');
    $keywords = vipsvault_ebay_clean_keywords($atts['keywords']);
    ob_start(); vipsvault_ebay_render_products($keywords, intval($atts['item_count']), $atts['title']); return ob_get_clean();
}
add_shortcode('vipsvault_ebay','vipsvault_ebay_shortcode');
add_shortcode('ebay_search','vipsvault_ebay_shortcode');
function vipsvault_vip_ebay_box($position, $post_id){
    $raw = get_post_meta($post_id, $position === 'top' ? '_vip_ebay_keywords_top' : '_vip_ebay_keywords_bottom', true);
    $count = intval(get_post_meta($post_id, '_vip_ebay_item_count', true));
    if($count < 1) $count = 4;
    $title = $position === 'top' ? 'Featured eBay Memorabilia' : 'More eBay Memorabilia';
    $parsed = vipsvault_ebay_parse_input($raw, $count, $title);
    $keywords = $parsed['keywords'] ?: (get_the_title($post_id) . ' memorabilia');
    vipsvault_ebay_render_products($keywords, $parsed['item_count'], $parsed['title'] ?: $title);
}

/* VIPSVault PSA10 auction search page - uses saved eBay Partner API settings. */
function vipsvault_psa10_allowed_sports(){
    return array('football'=>'Football','basketball'=>'Basketball','baseball'=>'Baseball','hockey'=>'Hockey','golf'=>'Golf');
}
function vipsvault_psa10_clean_sport($sport){
    $sport = sanitize_key($sport);
    $allowed = vipsvault_psa10_allowed_sports();
    return isset($allowed[$sport]) ? $sport : '';
}
function vipsvault_psa10_build_query($search, $sport){
    $allowed = vipsvault_psa10_allowed_sports();
    $parts = array();
    $search = vipsvault_ebay_clean_keywords($search);
    if($search !== '') $parts[] = $search;
    if($sport && isset($allowed[$sport])) $parts[] = $allowed[$sport];
    $parts[] = 'PSA 10';
    $parts[] = 'card';
    $query = implode(' ', array_unique(array_filter($parts)));
    return vipsvault_ebay_clean_keywords($query);
}
function vipsvault_ebay_psa10_auction_search_single($search = '', $sport = '', $limit = 20, $force = false){
    $o = vipsvault_ebay_options();
    $sport = vipsvault_psa10_clean_sport($sport);
    $query = vipsvault_psa10_build_query($search, $sport);
    $limit = max(1, min(20, intval($limit)));
    if($query === '') return new WP_Error('missing_keywords','No PSA10 search keywords were provided.');

    $cache_key = 'vv_psa10_' . md5(strtolower($query).'|'.$sport.'|'.$limit.'|'.$o['marketplace_id'].'|'.$o['campaign_id'].'|auctions-v1');
    $cached = get_transient($cache_key);
    if(!$force && $cached !== false) return $cached;

    $token = vipsvault_ebay_get_token();
    if(is_wp_error($token)){ vipsvault_ebay_store_last_error($token->get_error_message()); return $token; }

    $params = array(
        'q'      => $query,
        'limit'  => $limit,
        'filter' => 'buyingOptions:{AUCTION}',
        'sort'   => 'endingSoonest',
    );
    $url = trailingslashit($o['endpoint']) . 'buy/browse/v1/item_summary/search?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    $headers = array(
        'Authorization' => 'Bearer ' . $token,
        'X-EBAY-C-MARKETPLACE-ID' => $o['marketplace_id'],
        'Accept' => 'application/json',
    );
    if(!empty($o['campaign_id'])){
        $ctx = 'affiliateCampaignId=' . rawurlencode($o['campaign_id']);
        if(!empty($o['custom_id'])) $ctx .= ',affiliateReferenceId=' . rawurlencode($o['custom_id']);
        $headers['X-EBAY-C-ENDUSERCTX'] = $ctx;
    }
    $response = wp_remote_get($url, array('timeout'=>20, 'headers'=>$headers));
    if(is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $body = json_decode($raw, true);
    if($code < 200 || $code >= 300){
        $err = new WP_Error('psa10_search_failed', 'eBay PSA10 auction search failed: HTTP '.$code.' '.$raw);
        vipsvault_ebay_store_last_error($err->get_error_message());
        return $err;
    }
    $items = isset($body['itemSummaries']) && is_array($body['itemSummaries']) ? $body['itemSummaries'] : array();
    set_transient($cache_key, $items, HOUR_IN_SECONDS * intval($o['cache_hours']));
    return $items;
}
function vipsvault_ebay_psa10_auction_search($search = '', $sport = '', $limit = 20){
    $sport = vipsvault_psa10_clean_sport($sport);
    $limit = max(1, min(20, intval($limit)));
    if($sport){
        return vipsvault_ebay_psa10_auction_search_single($search, $sport, $limit);
    }
    $all = array();
    $errors = array();
    foreach(array_keys(vipsvault_psa10_allowed_sports()) as $sport_key){
        $items = vipsvault_ebay_psa10_auction_search_single($search, $sport_key, 8);
        if(is_wp_error($items)){ $errors[] = $items; continue; }
        foreach($items as $item){
            if(!empty($item['itemId'])) $all[$item['itemId']] = $item; else $all[] = $item;
        }
    }
    if(empty($all) && !empty($errors)) return $errors[0];
    $all = array_values($all);
    usort($all, function($a,$b){
        $at = !empty($a['itemEndDate']) ? strtotime($a['itemEndDate']) : PHP_INT_MAX;
        $bt = !empty($b['itemEndDate']) ? strtotime($b['itemEndDate']) : PHP_INT_MAX;
        return $at <=> $bt;
    });
    return array_slice($all, 0, $limit);
}
function vipsvault_psa10_affiliate_search_url($search = '', $sport = ''){
    $sport = vipsvault_psa10_clean_sport($sport);
    $query = vipsvault_psa10_build_query($search, $sport ?: '');
    $url = vipsvault_ebay_affiliate_search_url($query);
    $url .= '&LH_Auction=1&_sop=1';
    return $url;
}
function vipsvault_psa10_format_end_date($item){
    if(empty($item['itemEndDate'])) return '';
    $ts = strtotime($item['itemEndDate']);
    if(!$ts) return '';
    return date_i18n(get_option('date_format').' '.get_option('time_format'), $ts);
}

if(!function_exists('vipsvault_strip_emojis')){
    function vipsvault_strip_emojis($text){
        $text = (string) $text;
        // Remove common emoji and pictograph unicode ranges from eBay item titles.
        $text = preg_replace('/[\x{1F000}-\x{1FAFF}\x{2600}-\x{27BF}\x{FE0F}]/u', '', $text);
        return trim(preg_replace('/\s+/', ' ', $text));
    }
}

function vipsvault_render_psa10_page(){
    $search = isset($_GET['psaq']) ? vipsvault_ebay_clean_keywords(wp_unslash($_GET['psaq'])) : '';
    $sport = isset($_GET['sport']) ? vipsvault_psa10_clean_sport(wp_unslash($_GET['sport'])) : '';
    $sports = vipsvault_psa10_allowed_sports();
    $items = vipsvault_ebay_psa10_auction_search($search, $sport, 20);
    ?>
    <section class="archive-hero psa10-hero">
        <div class="container">
            <div class="kicker">PSA 10 Auctions</div>
            <h1>PSA10 Card Auctions</h1>
            <p class="meta-line">Ending-soonest eBay auctions for PSA 10 Football, Basketball, Baseball, Hockey, and Golf cards. Links use the saved VIPSVault eBay Partner settings.</p>
            <form class="filter-bar vv-search-filters vv-collectibles-clean-filter psa10-search" method="get" action="<?php echo esc_url(home_url('/psa10/')); ?>">
                <input type="search" name="psaq" value="<?php echo esc_attr($search); ?>" placeholder="Search player, year, set, rookie, team...">
                <select name="sport">
                    <option value="">All PSA10 Sports</option>
                    <?php foreach($sports as $key=>$label): ?>
                        <option value="<?php echo esc_attr($key); ?>" <?php selected($sport,$key); ?>><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
                <select class="psa10-sort-select" aria-label="Auction sort order">
                    <option>Ending Soonest</option>
                </select>
                <button class="btn btn-primary" type="submit">Search Auctions</button>
                <a class="btn btn-secondary" href="<?php echo esc_url(home_url('/psa10/')); ?>">Reset</a>
            </form>
            <div class="cat-pills psa10-pills">
                <a href="<?php echo esc_url(home_url('/psa10/')); ?>">All</a>
                <?php foreach($sports as $key=>$label): ?>
                    <a href="<?php echo esc_url(add_query_arg('sport',$key,home_url('/psa10/'))); ?>"><?php echo esc_html($label); ?></a>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <section class="section psa10-results-section">
        <div class="container">
            <div class="section-title"><h2><?php echo $sport ? esc_html($sports[$sport].' PSA 10 Auctions') : 'Ending Soon: PSA 10 Auctions'; ?></h2><p>Showing up to 20 auction listings, sorted by the first ending auctions.</p></div>
            <?php if(is_wp_error($items)): ?>
                <div class="api-embed"><p>PSA10 auctions are temporarily unavailable.</p><p><a class="btn btn-primary" target="_blank" rel="nofollow sponsored noopener" href="<?php echo esc_url(vipsvault_psa10_affiliate_search_url($search,$sport)); ?>">Search PSA10 auctions on eBay</a></p></div>
            <?php elseif(empty($items)): ?>
                <div class="api-embed"><p>No PSA10 auctions matched this search right now.</p><p><a class="btn btn-primary" target="_blank" rel="nofollow sponsored noopener" href="<?php echo esc_url(vipsvault_psa10_affiliate_search_url($search,$sport)); ?>">Search PSA10 auctions on eBay</a></p></div>
            <?php else: ?>
                <div class="ebay-products-grid psa10-products-grid">
                    <?php foreach($items as $item):
                        $url = vipsvault_ebay_affiliate_item_url($item['itemAffiliateWebUrl'] ?? ($item['itemWebUrl'] ?? '#'));
                        $image = $item['image']['imageUrl'] ?? '';
                        $title = vipsvault_strip_emojis($item['title'] ?? 'PSA 10 eBay auction');
                        $price = '';
                        if(!empty($item['currentBidPrice']['value'])) $price = ($item['currentBidPrice']['currency'] ?? 'USD') . ' ' . $item['currentBidPrice']['value'];
                        elseif(!empty($item['price']['value'])) $price = ($item['price']['currency'] ?? 'USD') . ' ' . $item['price']['value'];
                        $end = vipsvault_psa10_format_end_date($item);
                    ?>
                        <a class="ebay-product-card psa10-product-card" target="_blank" rel="nofollow sponsored noopener" href="<?php echo esc_url($url); ?>">
                            <span class="psa10-card-badge">PSA 10 Auction</span>
                            <span class="psa10-image-wrap"><?php if($image): ?><img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($title); ?>"><?php endif; ?></span>
                            <span class="ebay-title"><?php echo esc_html($title); ?></span>
                            <?php if($price): ?><span class="psa10-bid-label">Current bid</span><strong class="ebay-price psa10-price"><?php echo esc_html($price); ?></strong><?php endif; ?>
                            <?php if($end): ?><span class="psa10-ending">Ending soon: <?php echo esc_html($end); ?></span><?php endif; ?>
                            <span class="ebay-button">View Auction on eBay</span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
    <?php
}
function vipsvault_ensure_psa10_page_and_nav(){
    $page_id = vipsvault_get_or_create_page('PSA10','');
    if($page_id && !is_wp_error($page_id)){
        wp_update_post(array('ID'=>$page_id,'post_name'=>'psa10','post_status'=>'publish'));
    }
    $psa_url = $page_id && !is_wp_error($page_id) ? get_permalink($page_id) : home_url('/psa10/');
    $locations = get_theme_mod('nav_menu_locations');
    $menu_ids = array();
    if(is_array($locations) && !empty($locations['primary'])) $menu_ids[] = (int)$locations['primary'];
    $main_menu = wp_get_nav_menu_object('VIPSVault Main Menu');
    if($main_menu) $menu_ids[] = (int)$main_menu->term_id;
    $menu_ids = array_unique(array_filter($menu_ids));
    foreach($menu_ids as $menu_id){
        $items = wp_get_nav_menu_items($menu_id);
        $has_psa = false;
        if(!empty($items)){
            foreach($items as $item){
                $title = strtolower(trim(wp_strip_all_tags($item->title)));
                $url = strtolower((string)$item->url);
                if($title === 'psa10' || strpos($url, '/psa10') !== false){
                    $has_psa = true;
                    wp_update_nav_menu_item($menu_id, $item->ID, array('menu-item-title'=>'PSA10','menu-item-url'=>$psa_url,'menu-item-status'=>'publish'));
                }
            }
        }
        if(!$has_psa){
            wp_update_nav_menu_item($menu_id, 0, array('menu-item-title'=>'PSA10','menu-item-url'=>$psa_url,'menu-item-status'=>'publish'));
        }
    }
    update_option('vipsvault_psa10_page_nav_version','1');
}
add_action('after_switch_theme','vipsvault_ensure_psa10_page_and_nav',70);
add_action('admin_init', function(){
    if(get_option('vipsvault_psa10_page_nav_version') !== '1') vipsvault_ensure_psa10_page_and_nav();
});
function vipsvault_force_psa10_page_template($template){
    if(is_page('psa10') || is_page('PSA10')){
        $psa_template = locate_template('page-psa10.php');
        if($psa_template) return $psa_template;
    }
    return $template;
}
add_filter('template_include','vipsvault_force_psa10_page_template',98);
function vipsvault_flush_rewrites_for_psa10_page(){
    $version = 'psa10-page-1';
    if(get_option('vipsvault_psa10_rewrite_version') !== $version){
        flush_rewrite_rules(false);
        update_option('vipsvault_psa10_rewrite_version',$version);
    }
}
add_action('admin_init','vipsvault_flush_rewrites_for_psa10_page');
add_action('after_switch_theme','vipsvault_flush_rewrites_for_psa10_page',80);
