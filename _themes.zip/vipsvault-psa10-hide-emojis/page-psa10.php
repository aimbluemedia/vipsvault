<?php get_header(); ?>
<main>
    <?php
    if(function_exists('vipsvault_render_psa10_page')){
        vipsvault_render_psa10_page();
    } else {
        echo '<section class="section"><div class="container"><div class="api-embed">PSA10 auction search is unavailable.</div></div></section>';
    }
    ?>
</main>
<?php get_footer(); ?>
