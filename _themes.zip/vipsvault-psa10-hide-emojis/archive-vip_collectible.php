<?php get_header(); ?>
<main>
  <section class="archive-hero">
    <div class="container">
      <div class="kicker">The Vault</div>
      <h1>Collectibles</h1>
      <p class="meta-line">Search sports cards, celebrity cards, music legends, movie icons, autographs, graded collectibles, and memorabilia.</p>
      <?php vipsvault_collectible_search_form(); ?>
    </div>
  </section>
  <section class="section">
    <div class="container">
      <?php if(have_posts()): ?>
        <div class="card-grid"><?php while(have_posts()):the_post(); get_template_part('template-parts/collectible-card'); endwhile; ?></div>
        <div class="pagination"><?php the_posts_pagination(array('mid_size'=>2)); ?></div>
      <?php else: ?>
        <div class="api-embed">No collectibles matched your search. Try a different name, year, team, set, or category.</div>
      <?php endif; ?>
    </div>
  </section>
</main><?php get_footer(); ?>
