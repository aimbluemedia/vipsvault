<?php get_header(); ?>
<main class="vv-blog-page">
  <section class="vv-blog-hero">
    <div class="container vv-blog-hero-inner">
      <div>
        <span class="kicker">VIPSVault Blog</span>
        <h1>Recent Blog Posts</h1>
      </div>
      <p>Browse the latest collecting guides, VIP features, card history, memorabilia updates, market notes, and smart resale ideas.</p>
    </div>
  </section>

  <section class="vv-blog-list-section">
    <div class="container">
      <div class="vv-blog-panel">
        <div class="vv-blog-panel-head">
          <div>
            <span class="kicker">Latest Posts</span>
            <h2>Fresh from the Vault</h2>
          </div>
          <span class="vv-blog-count">Showing latest 15</span>
        </div>

        <div id="vipsvault-blog-title-list" class="vv-blog-title-list">
          <?php echo vipsvault_render_blog_title_items(0, 15); ?>
        </div>

        <?php if (vipsvault_blog_total_posts() > 15) : ?>
          <div class="vv-load-more-wrap">
            <button id="vipsvault-load-more-posts" class="btn btn-primary vv-load-more-posts" data-offset="15" data-step="15">Show 15 More</button>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </section>
</main>
<?php get_footer(); ?>
