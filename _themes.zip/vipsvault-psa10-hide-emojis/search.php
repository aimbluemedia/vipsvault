<?php get_header(); ?>
<main>
  <section class="archive-hero">
    <div class="container">
      <div class="kicker">Search VIPSVault</div>
      <h1>Search Results</h1>
      <p class="meta-line">Results for: <?php echo esc_html(get_search_query()); ?></p>
      <div class="search-switches">
        <a class="btn btn-secondary" href="<?php echo esc_url(add_query_arg(array('s'=>get_search_query(),'post_type'=>'vip'), home_url('/'))); ?>">Search VIPS</a>
        <a class="btn btn-secondary" href="<?php echo esc_url(add_query_arg(array('vvq'=>get_search_query()), get_post_type_archive_link('vip_collectible'))); ?>">Search Collectibles</a>
      </div>
    </div>
  </section>
  <section class="section">
    <div class="container">
      <?php if(have_posts()): ?>
        <div class="card-grid">
          <?php while(have_posts()): the_post();
            if(get_post_type()==='vip') get_template_part('template-parts/vip-card');
            elseif(get_post_type()==='vip_collectible') get_template_part('template-parts/collectible-card');
            else echo '<article class="card"><div class="card-body"><h3><a href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a></h3><p class="meta-line">'.esc_html(get_the_excerpt()).'</p></div></article>';
          endwhile; ?>
        </div>
        <div class="pagination"><?php the_posts_pagination(array('mid_size'=>2)); ?></div>
      <?php else: ?>
        <div class="api-embed">No results found.</div>
      <?php endif; ?>
    </div>
  </section>
</main><?php get_footer(); ?>
