<?php get_header(); ?>
<main>
  <section class="archive-hero">
    <div class="container">
      <div class="kicker">VIP Category</div>
      <h1><?php single_term_title(); ?></h1>
      <p class="meta-line">Search VIP pages in this category or browse all VIPS.</p>
      <?php vipsvault_vip_search_form(); ?>
    </div>
  </section>
  <section class="section">
    <div class="container">
      <?php if(have_posts()): ?>
        <div class="vip-grid"><?php while(have_posts()):the_post(); get_template_part('template-parts/vip-card'); endwhile; ?></div>
        <div class="pagination"><?php the_posts_pagination(array('mid_size'=>2)); ?></div>
      <?php else: ?>
        <div class="api-embed">No VIP pages matched your search in this category.</div>
      <?php endif; ?>
    </div>
  </section>
</main>
<?php get_footer(); ?>
