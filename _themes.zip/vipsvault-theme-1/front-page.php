<?php get_header(); ?>
<main>
<?php
if(have_posts()):
    while(have_posts()): the_post();
        if(trim(get_the_content())) echo '<div class="editable-home-content">'.apply_filters('the_content',get_the_content()).'</div>';
    endwhile;
endif;
?>



<section class="section psa10-results-section vv-home-psa10-section">
    <div class="container">
        <div class="section-title">
            <h2>Latest PSA10 Auctions</h2>
        </div>
        <?php
        if(function_exists('vipsvault_ebay_psa10_auction_search')):
            $items = vipsvault_ebay_psa10_auction_search('', '', 8);
            if(is_wp_error($items)):
        ?>
                <div class="api-embed"><p>Latest PSA10 auctions are temporarily unavailable.</p><p><a class="btn btn-primary" target="_blank" rel="nofollow sponsored noopener" href="<?php echo esc_url(function_exists('vipsvault_psa10_affiliate_search_url') ? vipsvault_psa10_affiliate_search_url('', '') : home_url('/psa10/')); ?>">Search PSA10 auctions on eBay</a></p></div>
            <?php elseif(empty($items)): ?>
                <div class="api-embed"><p>No PSA10 auctions are available right now.</p><p><a class="btn btn-primary" href="<?php echo esc_url(home_url('/psa10/')); ?>">View PSA10 Auctions</a></p></div>
            <?php else: ?>
                <div class="ebay-products-grid psa10-products-grid vv-home-psa10-grid">
                    <?php foreach(array_slice($items,0,8) as $item):
                        $url = function_exists('vipsvault_ebay_affiliate_item_url') ? vipsvault_ebay_affiliate_item_url($item['itemAffiliateWebUrl'] ?? ($item['itemWebUrl'] ?? '#')) : ($item['itemWebUrl'] ?? '#');
                        $image = $item['image']['imageUrl'] ?? '';
                        $title = $item['title'] ?? 'PSA 10 eBay auction';
                        $price = '';
                        if(!empty($item['currentBidPrice']['value'])) $price = ($item['currentBidPrice']['currency'] ?? 'USD') . ' ' . $item['currentBidPrice']['value'];
                        elseif(!empty($item['price']['value'])) $price = ($item['price']['currency'] ?? 'USD') . ' ' . $item['price']['value'];
                        $end = function_exists('vipsvault_psa10_format_end_date') ? vipsvault_psa10_format_end_date($item) : '';
                    ?>
                        <a class="ebay-product-card psa10-product-card" target="_blank" rel="nofollow sponsored noopener" href="<?php echo esc_url($url); ?>">
                            <span class="psa10-card-badge">PSA 10 Auction</span>
                            <span class="psa10-image-wrap"><?php if($image): ?><img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($title); ?>"><?php endif; ?></span>
                            <span class="ebay-title"><?php echo esc_html($title); ?></span>
                            <?php if($price): ?><span class="psa10-bid-label">Current bid</span><strong class="ebay-price psa10-price"><?php echo esc_html($price); ?></strong><?php endif; ?>
                            <?php if($end): ?><span class="psa10-ending">Ending soon: <?php echo esc_html($end); ?></span><?php endif; ?>
                            <span class="ebay-button">View Auction on eBay</span>
                        </a>
                    <?php endforeach; ?>
                </div>
                <p class="vv-home-psa10-link"><a class="btn btn-primary" href="<?php echo esc_url(home_url('/psa10/')); ?>">View All PSA10 Auctions</a></p>
            <?php endif; ?>
        <?php else: ?>
            <div class="api-embed"><p>PSA10 auction tools are unavailable.</p></div>
        <?php endif; ?>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-title">
            <h2>Featured VIPS</h2>
        </div>
        <div class="vip-grid" id="vipsvault-random-vips-grid" data-random-vips-grid="1">
            <?php echo function_exists('vipsvault_get_random_vips_html') ? vipsvault_get_random_vips_html(8) : ''; ?>
        </div>
        <div class="cat-pills vv-home-vip-pills">
            <?php
            $terms = get_terms(array('taxonomy'=>'vip_category','hide_empty'=>false));
            if(!is_wp_error($terms)){
                foreach($terms as $term){
                    echo '<a href="'.esc_url(get_term_link($term)).'">'.esc_html($term->name).'</a>';
                }
            }
            ?>
        </div>
    </div>
</section>
</main>
<?php get_footer(); ?>
