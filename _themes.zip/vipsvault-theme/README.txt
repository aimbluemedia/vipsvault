VIPSVault Theme — VIPS Wiki + Collectibles

This WordPress theme includes:
- VIP Collectibles for cards, autographs, graded collectibles, memorabilia, and marketplace listings.
- VIPS section for Wikipedia-style profiles.
- VIP Categories: Baseball, Football, Basketball, Hockey, Golf, Movies, TV, Music.
- VIP Career Items for movies, TV shows, albums, teams, seasons, events, roles, credits, and major career entries.
- Unlimited Accomplishments on each VIP profile.
- Unlimited News entries on each VIP profile.

VIP PROFILE FIELDS
- Full Name
- Born
- Died
- Birthplace
- Profession / Position
- Active Years
- Top Memorabilia API Shortcode / Embed
- Bio Section
- Bottom Memorabilia API Shortcode / Embed

REMOVED FROM VIP PROFILES
- Known For
- Personal Section
- Professional Section
- VIP Timeline Items

ACCOMPLISHMENTS
Each VIP profile can have unlimited accomplishments.
Use the Create button and add:
- Title
- Summary
- Memorabilia API Code

NEWS
Each VIP profile can have unlimited news items.
Use the Create button and add:
- Title
- Summary
- Memorabilia API Code

CAREER ITEMS
Go to WordPress Admin > VIP Career Items > Add Career Item.
Each career item includes:
- Title
- Year / Season
- Type: Movie, TV Show, Album, Team, Event
- Role / Team / Credit
- Related VIP Slug, example: jack-nicholson
- Summary
- Career Item Memorabilia API Shortcode / Embed

Example structure:
VIPS > Movies > Jack Nicholson
- Featured Memorabilia at the top
- Bio
- Accomplishments
- Career Items such as movies
- News
- Bottom Memorabilia API section

For sports VIPS, Career Items can be teams, seasons, championships, or Hall of Fame entries.
For music VIPS, Career Items can be albums, tours, awards, or major performances.
For movies and TV VIPS, Career Items can be films, shows, episodes, roles, or awards.

Version 2.1 update:
- Added Collectibles search and filters to /collectibles/.
- Added filters for category, sports/type, and sort order.
- Added VIPS dropdown to the main navigation demo menu.
- Added header Search VIPS form.
- Added VIP -> Collectibles relationship using Related VIP Slug on collectible records.
- Added Related Collectibles section to each VIP profile page.
- Added search.php for better VIPSVault search results.

Update included:
- Removed the VIPS submenu/dropdown from the top navigation.
- VIPS is now a single main navigation link to the All VIPS archive page.
- Added an All VIPS archive page search bar and filters similar to Collectibles.
- Added VIP category filtering and A-Z/newest sorting.
- Header VIP search now routes to the All VIPS page.

VIPS Directory Fix
- Added a proper /vips/ directory archive that displays VIP cards like Collectibles.
- Added page-vips.php fallback in case WordPress has an existing page using the vips slug.
- Hardened rewrite rules so /vips/ opens the VIPS directory and /vips/person-name/ opens the individual VIP profile.
- Updated the individual VIP template so newly created VIPS like Frank Sinatra still show title, category, bio/content, career placeholder, news, memorabilia, and related collectibles even if custom fields are empty.
- Added automatic rewrite refresh from the dashboard after upload/activation.

Latest update:
- Removed the Collectibles "All Sports / Types" dropdown.
- Made Collectibles and VIPS archive filters more visually consistent.
- Added category-based fallback images when no featured image is provided.
- Added VIP age calculation box: current age when living, age at death when Died is filled in.

Header Menu Mapping Fix
- Header navigation now uses WordPress Appearance > Menus.
- The theme location is Header Navigation / primary.
- Existing VIPSVault Main Menu items are preserved and will not be overwritten.
- Dropdowns/submenus created in Appearance > Menus are supported.
- If no menu exists, the theme creates a starter menu only once.

Date field update:
- Born and Died fields now use calendar date pickers in the VIP editor.
- Dates save in a consistent YYYY-MM-DD format for calculations.
- VIP pages display dates in a consistent Month Day, Year format.
- Age calculation uses Died date for Age at Death, or current date for living VIPs.

EBAY PARTNER API MEMORABILIA INTEGRATION
- Go to Appearance > VIPSVault eBay API.
- Add eBay Client ID/App ID, Client Secret/Cert ID, ePN Campaign ID, Marketplace ID, and Cache Hours.
- On any VIP profile, add Top eBay Memorabilia Keywords and Bottom eBay Memorabilia Keywords.
- If keywords are left blank, the theme uses: VIP Name + memorabilia.
- Use this shortcode anywhere in a memorabilia field:
  [vipsvault_ebay keywords="harry potter" item_count="4" title="eBay Memorabilia"]
- Legacy shortcode also works:
  [ebay_search keywords="frank sinatra memorabilia" item_count="4"]
- The theme caches eBay results to keep pages fast and reduce API calls.

EBAY API DEBUG UPDATE
- eBay API errors are now shown to admins by default.
- Appearance > VIPSVault eBay API now includes a Test Connection button.
- Clear Token Cache button added.
- If the API fails, the theme can show a direct eBay search affiliate fallback link instead of a blank/error-only section.
- Use Production App ID and Production Cert ID for live eBay.com results.
- ePN Campaign ID is the 10-digit campid from eBay Partner Network.

EBAY MEMORABILIA UPDATE
- OAuth uses the Browse API scope: https://api.ebay.com/oauth/api_scope
- VIP memorabilia searches now use fallback keyword variations automatically.
- Example fallback chain: Frank Sinatra, Frank Sinatra memorabilia, Frank Sinatra autograph, Frank Sinatra signed photo, Frank Sinatra trading card, Frank Sinatra collectible, Frank Sinatra card.
- Admin debug mode shows each searched term and result count on VIP pages.
- If no API result is found, the theme shows a direct eBay search button instead of leaving the area blank.
