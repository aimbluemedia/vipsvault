<?php
if(!defined('ABSPATH')) exit;

function vipsvault_setup(){
    add_theme_support('title-tag'); add_theme_support('post-thumbnails'); add_theme_support('custom-logo'); add_theme_support('align-wide'); add_theme_support('editor-styles');
    register_nav_menus(array(
        'primary' => 'Header Navigation',
        'footer'  => 'Footer Navigation'
    ));
}
add_action('after_setup_theme','vipsvault_setup');

function vipsvault_assets(){ wp_enqueue_style('vipsvault-style', get_stylesheet_uri(), array(), '2.0'); }
add_action('wp_enqueue_scripts','vipsvault_assets');

function vipsvault_register_types(){
    register_post_type('vip_collectible', array(
        'labels'=>array('name'=>'VIP Collectibles','singular_name'=>'VIP Collectible','add_new_item'=>'Add Collectible'),
        'public'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'collectibles'),'menu_icon'=>'dashicons-vault',
        'supports'=>array('title','editor','excerpt','thumbnail'),'show_in_rest'=>true
    ));
    register_taxonomy('collectible_category','vip_collectible',array('labels'=>array('name'=>'Collectible Categories'),'public'=>true,'hierarchical'=>true,'rewrite'=>array('slug'=>'collectible-category'),'show_in_rest'=>true));
    register_taxonomy('collectible_tag','vip_collectible',array('labels'=>array('name'=>'Collectible Tags'),'public'=>true,'hierarchical'=>false,'rewrite'=>array('slug'=>'collectible-tag'),'show_in_rest'=>true));

    register_post_type('vip', array(
        'labels'=>array('name'=>'VIPS','singular_name'=>'VIP','add_new_item'=>'Add VIP','edit_item'=>'Edit VIP'),
        'public'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'vips'),'menu_icon'=>'dashicons-star-filled',
        'supports'=>array('title','editor','excerpt','thumbnail'),'show_in_rest'=>true
    ));
    register_taxonomy('vip_category','vip',array(
        'labels'=>array('name'=>'VIP Categories','singular_name'=>'VIP Category'),
        'public'=>true,'hierarchical'=>true,'rewrite'=>array('slug'=>'vips/category'),'show_in_rest'=>true
    ));
    register_post_type('vip_career', array(
        'labels'=>array('name'=>'VIP Career Items','singular_name'=>'VIP Career Item','add_new_item'=>'Add Career Item','edit_item'=>'Edit Career Item'),
        'public'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'vip-career'),'menu_icon'=>'dashicons-awards',
        'supports'=>array('title','editor','excerpt','thumbnail'),'show_in_rest'=>true
    ));
}
add_action('init','vipsvault_register_types');

function vipsvault_default_terms(){
    foreach(array('Baseball','Football','Basketball','Hockey','Golf','Movies','TV','Music') as $t){ if(!term_exists($t,'vip_category')) wp_insert_term($t,'vip_category'); }
    foreach(array('Sports','Celebrities','Music','Movies & TV','Autographs','Memorabilia','Rookie Cards','Graded Cards') as $t){ if(!term_exists($t,'collectible_category')) wp_insert_term($t,'collectible_category'); }
}
add_action('init','vipsvault_default_terms',20);

function vipsvault_add_meta_boxes(){
    add_meta_box('vv_card_details','Collectible Details','vipsvault_card_meta_box','vip_collectible','normal','high');
    add_meta_box('vv_vip_details','VIP Wiki Details','vipsvault_vip_meta_box','vip','normal','high');
    add_meta_box('vv_career_details','Career Item Details','vipsvault_career_meta_box','vip_career','normal','high');
}
add_action('add_meta_boxes','vipsvault_add_meta_boxes');

function vipsvault_input($key,$label,$type='text',$textarea=false){
    $value=get_post_meta(get_the_ID(),$key,true);
    echo '<p><label for="'.$key.'"><strong>'.esc_html($label).'</strong></label><br>';
    if($textarea) echo '<textarea style="width:100%;min-height:90px" id="'.$key.'" name="'.$key.'">'.esc_textarea($value).'</textarea>';
    else echo '<input style="width:100%" type="'.esc_attr($type).'" id="'.$key.'" name="'.$key.'" value="'.esc_attr($value).'">';
    echo '</p>';
}
function vipsvault_card_meta_box(){ wp_nonce_field('vv_save','vv_nonce'); foreach(array('_vv_person_name'=>'Player / Celebrity Name','_vv_profession'=>'Sport / Profession','_vv_team_role'=>'Team / Movie / Show / Band / Role','_vv_year'=>'Year','_vv_brand'=>'Brand / Set','_vv_card_number'=>'Card Number','_vv_condition'=>'Condition','_vv_grade'=>'Grade','_vv_price'=>'Asking Price','_vv_marketplace_url'=>'Marketplace URL','_vv_related_vip'=>'Related VIP Slug, example: jack-nicholson') as $k=>$l) vipsvault_input($k,$l); vipsvault_input('_vv_ebay_shortcode','eBay Plugin Shortcode / Embed Code','text',true); }
function vipsvault_vip_repeater_field($key,$label){
    $items=json_decode(get_post_meta(get_the_ID(),$key,true), true);
    if(!is_array($items)) $items=array();
    echo '<div class="vv-repeater" data-key="'.esc_attr($key).'"><h3>'.esc_html($label).'</h3><p><button type="button" class="button vv-add-row">Create</button></p><div class="vv-rows">';
    foreach($items as $i=>$item){
        $title=isset($item['title'])?$item['title']:''; $summary=isset($item['summary'])?$item['summary']:''; $api=isset($item['api'])?$item['api']:'';
        echo '<div class="vv-row" style="border:1px solid #ccd0d4;padding:12px;margin:12px 0;background:#fff"><p><label><strong>Title</strong></label><br><input style="width:100%" name="'.esc_attr($key).'['.$i.'][title]" value="'.esc_attr($title).'"></p><p><label><strong>Summary</strong></label><br><textarea style="width:100%;min-height:80px" name="'.esc_attr($key).'['.$i.'][summary]">'.esc_textarea($summary).'</textarea></p><p><label><strong>Memorabilia API Code</strong></label><br><textarea style="width:100%;min-height:80px" name="'.esc_attr($key).'['.$i.'][api]">'.esc_textarea($api).'</textarea></p><p><button type="button" class="button vv-remove-row">Remove</button></p></div>';
    }
    echo '</div><template class="vv-template"><div class="vv-row" style="border:1px solid #ccd0d4;padding:12px;margin:12px 0;background:#fff"><p><label><strong>Title</strong></label><br><input style="width:100%" data-name="title"></p><p><label><strong>Summary</strong></label><br><textarea style="width:100%;min-height:80px" data-name="summary"></textarea></p><p><label><strong>Memorabilia API Code</strong></label><br><textarea style="width:100%;min-height:80px" data-name="api"></textarea></p><p><button type="button" class="button vv-remove-row">Remove</button></p></div></template></div>';
}
function vipsvault_vip_meta_box(){ wp_nonce_field('vv_save','vv_nonce');
    vipsvault_input('_vip_full_name','Full Name');
    vipsvault_input('_vip_birth','Born','date');
    vipsvault_input('_vip_died','Died','date');
    foreach(array('_vip_birthplace'=>'Birthplace','_vip_profession'=>'Profession / Position','_vip_active_years'=>'Active Years') as $k=>$l) vipsvault_input($k,$l);
    vipsvault_input('_vip_memorabilia_top','Top Memorabilia API Shortcode / Embed','text',true);
    vipsvault_input('_vip_ebay_keywords_top','Top eBay Memorabilia Keywords');
    vipsvault_input('_vip_ebay_keywords_bottom','Bottom eBay Memorabilia Keywords');
    vipsvault_input('_vip_ebay_item_count','eBay Item Count (1-20)','number');
    vipsvault_input('_vip_bio','Bio Section','text',true);
    vipsvault_vip_repeater_field('_vip_accomplishments','Accomplishments');
    vipsvault_vip_repeater_field('_vip_news','News');
    vipsvault_input('_vip_memorabilia_bottom','Bottom Memorabilia API Shortcode / Embed','text',true);
    echo '<script>
    document.addEventListener("click", function(e){
      if(e.target.classList.contains("vv-add-row")){
        const wrap=e.target.closest(".vv-repeater"); const rows=wrap.querySelector(".vv-rows"); const key=wrap.dataset.key; const index=rows.children.length; const node=wrap.querySelector(".vv-template").content.cloneNode(true);
        node.querySelectorAll("[data-name]").forEach(function(el){ el.name=key+"["+index+"]["+el.dataset.name+"]"; }); rows.appendChild(node);
      }
      if(e.target.classList.contains("vv-remove-row")){ e.target.closest(".vv-row").remove(); }
    });</script>';
}
function vipsvault_career_meta_box(){ wp_nonce_field('vv_save','vv_nonce');
    vipsvault_input('_career_year','Year / Season'); vipsvault_input('_career_type','Type: Movie, TV Show, Album, Team, Event'); vipsvault_input('_career_role','Role / Team / Credit'); vipsvault_input('_career_vip_slug','Related VIP Slug, example: jack-nicholson'); vipsvault_input('_career_summary','Summary','text',true); vipsvault_input('_career_memorabilia','Career Item Memorabilia API Shortcode / Embed','text',true);
}
function vipsvault_normalize_date($date){
    $date = trim((string)$date);
    if($date === '') return '';
    $formats = array('Y-m-d','m/d/Y','n/j/Y','m-d-Y','n-j-Y','F j, Y','M j, Y');
    foreach($formats as $format){
        $dt = DateTime::createFromFormat($format, $date);
        if($dt instanceof DateTime) return $dt->format('Y-m-d');
    }
    $timestamp = strtotime($date);
    return $timestamp ? date('Y-m-d', $timestamp) : sanitize_text_field($date);
}
function vipsvault_format_vip_date($date){
    $date = trim((string)$date);
    if($date === '') return '';
    $timestamp = strtotime($date);
    return $timestamp ? date_i18n('F j, Y', $timestamp) : $date;
}
function vipsvault_save_meta($post_id){
    if(!isset($_POST['vv_nonce']) || !wp_verify_nonce($_POST['vv_nonce'],'vv_save') || defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    $keys=array('_vv_person_name','_vv_profession','_vv_team_role','_vv_year','_vv_brand','_vv_card_number','_vv_condition','_vv_grade','_vv_price','_vv_marketplace_url','_vv_related_vip','_vv_ebay_shortcode','_vip_full_name','_vip_birth','_vip_died','_vip_birthplace','_vip_profession','_vip_active_years','_vip_memorabilia_top','_vip_ebay_keywords_top','_vip_ebay_keywords_bottom','_vip_ebay_item_count','_vip_bio','_vip_memorabilia_bottom','_career_year','_career_type','_career_role','_career_vip_slug','_career_summary','_career_memorabilia');
    foreach($keys as $key){ if(isset($_POST[$key])){ if(in_array($key,array('_vip_birth','_vip_died'), true)) { $val = vipsvault_normalize_date($_POST[$key]); } else { $val=in_array($key,array('_vv_ebay_shortcode','_vip_memorabilia_top','_vip_ebay_keywords_top','_vip_ebay_keywords_bottom','_vip_ebay_item_count','_vip_bio','_vip_memorabilia_bottom','_career_summary','_career_memorabilia'), true) ? wp_kses_post($_POST[$key]) : sanitize_text_field($_POST[$key]); } update_post_meta($post_id,$key,$val); }}
    foreach(array('_vip_accomplishments','_vip_news') as $rkey){
        $clean=array();
        if(isset($_POST[$rkey]) && is_array($_POST[$rkey])){
            foreach($_POST[$rkey] as $row){
                $title=isset($row['title']) ? sanitize_text_field($row['title']) : '';
                $summary=isset($row['summary']) ? wp_kses_post($row['summary']) : '';
                $api=isset($row['api']) ? wp_kses_post($row['api']) : '';
                if($title || $summary || $api) $clean[]=array('title'=>$title,'summary'=>$summary,'api'=>$api);
            }
        }
        update_post_meta($post_id,$rkey, wp_json_encode($clean));
    }
}
add_action('save_post','vipsvault_save_meta');

function vv_meta($key){ return get_post_meta(get_the_ID(),$key,true); }
function vv_api_box($title,$content){ if(!$content) return; echo '<section class="api-box"><h2>'.esc_html($title).'</h2><div class="api-embed">'.do_shortcode(wp_kses_post($content)).'</div></section>'; }
function vv_repeater_section($title,$key){ $items=json_decode(get_post_meta(get_the_ID(),$key,true), true); if(!is_array($items) || empty($items)) return; echo '<section class="wiki-section"><h2>'.esc_html($title).'</h2><div class="vv-info-list">'; foreach($items as $item){ echo '<div class="vv-info-card"><h3>'.esc_html($item['title'] ?? '').'</h3><div class="content-box">'.wpautop(wp_kses_post($item['summary'] ?? '')).'</div>'; if(!empty($item['api'])) echo '<div class="api-embed mini-api">'.do_shortcode(wp_kses_post($item['api'])).'</div>'; echo '</div>'; } echo '</div></section>'; }

function vipsvault_price_number($price){
    return floatval(preg_replace('/[^0-9.]/','',$price));
}

function vipsvault_collectible_search_form(){
    $q = isset($_GET['vvq']) ? sanitize_text_field(wp_unslash($_GET['vvq'])) : '';
    $cat = isset($_GET['vvcat']) ? sanitize_text_field(wp_unslash($_GET['vvcat'])) : '';
    $sort = isset($_GET['vvsort']) ? sanitize_text_field(wp_unslash($_GET['vvsort'])) : 'newest';
    echo '<form class="filter-bar vv-search-filters vv-collectibles-clean-filter" method="get" action="'.esc_url(get_post_type_archive_link('vip_collectible')).'">';
    echo '<input type="search" name="vvq" value="'.esc_attr($q).'" placeholder="Search name, team, movie, artist, brand, year...">';
    echo '<select name="vvcat"><option value="">All Collectible Categories</option>';
    $terms = get_terms(array('taxonomy'=>'collectible_category','hide_empty'=>false));
    if(!is_wp_error($terms)){ foreach($terms as $term){ echo '<option value="'.esc_attr($term->slug).'" '.selected($cat,$term->slug,false).'>'.esc_html($term->name).'</option>'; }}
    echo '</select>';
    echo '<select name="vvsort">';
    foreach(array('newest'=>'Newest','oldest'=>'Oldest','az'=>'A-Z','za'=>'Z-A','price_high'=>'Highest Price','price_low'=>'Lowest Price') as $value=>$label){ echo '<option value="'.esc_attr($value).'" '.selected($sort,$value,false).'>'.esc_html($label).'</option>'; }
    echo '</select><button class="btn btn-primary" type="submit">Search Collectibles</button><a class="btn btn-secondary" href="'.esc_url(get_post_type_archive_link('vip_collectible')).'">Reset</a></form>';
}

function vipsvault_header_search_form(){
    echo '<form class="header-search" method="get" action="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'"><input type="search" name="vvq" placeholder="Search VIPS" value="'.esc_attr(isset($_GET['vvq']) ? sanitize_text_field(wp_unslash($_GET['vvq'])) : '').'"><button type="submit">Search</button></form>';
}


function vipsvault_vip_search_form(){
    $q = isset($_GET['vvq']) ? sanitize_text_field(wp_unslash($_GET['vvq'])) : '';
    $cat = isset($_GET['vipcat']) ? sanitize_text_field(wp_unslash($_GET['vipcat'])) : '';
    $sort = isset($_GET['vipsort']) ? sanitize_text_field(wp_unslash($_GET['vipsort'])) : 'newest';
    echo '<form class="filter-bar vv-search-filters vip-search-filters" method="get" action="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">';
    echo '<input type="search" name="vvq" value="'.esc_attr($q).'" placeholder="Search VIP name, movie, team, profession, keyword...">';
    echo '<select name="vipcat"><option value="">All VIP Categories</option>';
    $terms = get_terms(array('taxonomy'=>'vip_category','hide_empty'=>false));
    if(!is_wp_error($terms)){ foreach($terms as $term){ echo '<option value="'.esc_attr($term->slug).'" '.selected($cat,$term->slug,false).'>'.esc_html($term->name).'</option>'; }}
    echo '</select>';
    echo '<select name="vipsort">';
    foreach(array('newest'=>'Newest','oldest'=>'Oldest','az'=>'A-Z','za'=>'Z-A') as $value=>$label){ echo '<option value="'.esc_attr($value).'" '.selected($sort,$value,false).'>'.esc_html($label).'</option>'; }
    echo '</select><button class="btn btn-primary" type="submit">Search VIPS</button><a class="btn btn-secondary" href="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">Reset</a></form>';
}

function vipsvault_filter_vips_query($query){
    if(is_admin() || !$query->is_main_query()) return;
    if(is_post_type_archive('vip') || is_tax('vip_category') || (isset($_GET['post_type']) && $_GET['post_type']==='vip')){
        if(!empty($_GET['vvq'])){
            $query->set('_vip_custom_search', sanitize_text_field(wp_unslash($_GET['vvq'])));
        }
        $tax_query = array();
        if(!empty($_GET['vipcat'])){
            $tax_query[] = array('taxonomy'=>'vip_category','field'=>'slug','terms'=>sanitize_text_field(wp_unslash($_GET['vipcat'])));
        }
        if($tax_query) $query->set('tax_query', $tax_query);
        $sort = !empty($_GET['vipsort']) ? sanitize_text_field(wp_unslash($_GET['vipsort'])) : 'newest';
        if($sort==='oldest'){ $query->set('orderby','date'); $query->set('order','ASC'); }
        elseif($sort==='az'){ $query->set('orderby','title'); $query->set('order','ASC'); }
        elseif($sort==='za'){ $query->set('orderby','title'); $query->set('order','DESC'); }
        else { $query->set('orderby','date'); $query->set('order','DESC'); }
    }
}
add_action('pre_get_posts','vipsvault_filter_vips_query');

function vipsvault_filter_collectibles_query($query){
    if(is_admin() || !$query->is_main_query()) return;
    if(is_post_type_archive('vip_collectible') || (isset($_GET['post_type']) && $_GET['post_type']==='vip_collectible')){
        if(!empty($_GET['vvq'])){
            $query->set('_vv_custom_search', sanitize_text_field(wp_unslash($_GET['vvq'])));
        }
        $tax_query = array();
        if(!empty($_GET['vvcat'])){
            $tax_query[] = array('taxonomy'=>'collectible_category','field'=>'slug','terms'=>sanitize_text_field(wp_unslash($_GET['vvcat'])));
        }
        if($tax_query) $query->set('tax_query', $tax_query);
        $sort = !empty($_GET['vvsort']) ? sanitize_text_field(wp_unslash($_GET['vvsort'])) : 'newest';
        if($sort==='oldest'){ $query->set('orderby','date'); $query->set('order','ASC'); }
        elseif($sort==='az'){ $query->set('orderby','title'); $query->set('order','ASC'); }
        elseif($sort==='za'){ $query->set('orderby','title'); $query->set('order','DESC'); }
        elseif($sort==='price_high' || $sort==='price_low'){ $query->set('meta_key','_vv_price'); $query->set('orderby','meta_value_num'); $query->set('order',$sort==='price_high'?'DESC':'ASC'); }
        else { $query->set('orderby','date'); $query->set('order','DESC'); }
    }
}
add_action('pre_get_posts','vipsvault_filter_collectibles_query');

function vipsvault_collectible_search_join($join, $query){
    global $wpdb;
    if($query->get('_vv_custom_search') || $query->get('_vip_custom_search')){
        $join .= " LEFT JOIN {$wpdb->postmeta} vvsearchmeta ON ({$wpdb->posts}.ID = vvsearchmeta.post_id) ";
    }
    return $join;
}
add_filter('posts_join','vipsvault_collectible_search_join',10,2);
function vipsvault_collectible_search_where($where, $query){
    global $wpdb;
    $term = $query->get('_vv_custom_search') ?: $query->get('_vip_custom_search');
    if($term){
        $like = '%' . $wpdb->esc_like($term) . '%';
        $where .= $wpdb->prepare(" AND ({$wpdb->posts}.post_title LIKE %s OR {$wpdb->posts}.post_content LIKE %s OR vvsearchmeta.meta_value LIKE %s)", $like, $like, $like);
    }
    return $where;
}
add_filter('posts_where','vipsvault_collectible_search_where',10,2);
function vipsvault_collectible_search_groupby($groupby, $query){
    global $wpdb;
    if($query->get('_vv_custom_search') || $query->get('_vip_custom_search')) return "{$wpdb->posts}.ID";
    return $groupby;
}
add_filter('posts_groupby','vipsvault_collectible_search_groupby',10,2);


function vipsvault_related_collectibles($vip_id=null){
    if(!$vip_id) $vip_id = get_the_ID();
    $slug = get_post_field('post_name', $vip_id);
    $name = get_post_meta($vip_id,'_vip_full_name',true) ?: get_the_title($vip_id);
    $args = array(
        'post_type'=>'vip_collectible',
        'posts_per_page'=>8,
        'meta_query'=>array('relation'=>'OR', array('key'=>'_vv_related_vip','value'=>$slug,'compare'=>'='), array('key'=>'_vv_person_name','value'=>$name,'compare'=>'LIKE')),
    );
    $related = new WP_Query($args);
    echo '<section id="related-collectibles" class="wiki-section related-collectibles"><h2>Related Collectibles</h2><p class="meta-line">Cards and memorabilia connected to this VIP. Add the VIP slug to a collectible using the Related VIP Slug field.</p>';
    if($related->have_posts()){ echo '<div class="card-grid">'; while($related->have_posts()){ $related->the_post(); get_template_part('template-parts/collectible-card'); } echo '</div>'; wp_reset_postdata(); }
    else { echo '<div class="api-embed">No related collectibles yet. Edit a collectible and add <strong>'.esc_html($slug).'</strong> in the Related VIP Slug field.</div>'; }
    echo '</section>';
}


function vipsvault_demo_content(){
    if(get_option('vipsvault_vips_demo_imported')) return; vipsvault_default_terms();
    $home=get_page_by_title('VIPSVault Home'); if(!$home){ $hero='<!-- wp:group {"className":"vv-hero-edit"} --><div class="wp-block-group vv-hero-edit"><!-- wp:columns {"verticalAlignment":"center","className":"vv-hero-columns"} --><div class="wp-block-columns are-vertically-aligned-center vv-hero-columns"><!-- wp:column {"width":"45%","className":"vv-hero-image"} --><div class="wp-block-column vv-hero-image" style="flex-basis:45%"><!-- wp:image --><figure class="wp-block-image"><img src="'.esc_url(get_template_directory_uri().'/assets/vipsvault-logo.png').'" alt="VIPSVault logo vault image"/></figure><!-- /wp:image --></div><!-- /wp:column --><!-- wp:column {"width":"55%","className":"vv-hero-copy"} --><div class="wp-block-column vv-hero-copy" style="flex-basis:55%"><!-- wp:paragraph {"className":"kicker"} --><p class="kicker">The Vault for Iconic Collectibles</p><!-- /wp:paragraph --><!-- wp:heading {"level":1} --><h1>Rare cards. Famous names. One powerful vault.</h1><!-- /wp:heading --><!-- wp:paragraph --><p>VIPSVault.com showcases sports cards, celebrity cards, music legends, movie icons, autographs, graded collectibles, and memorabilia with a premium visual experience built to get attention.</p><!-- /wp:paragraph --><!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button {"className":"btn-primary"} --><div class="wp-block-button btn-primary"><a class="wp-block-button__link wp-element-button" href="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">Explore VIPS</a></div><!-- /wp:button --><!-- wp:button {"className":"btn-secondary"} --><div class="wp-block-button btn-secondary"><a class="wp-block-button__link wp-element-button" href="'.esc_url(admin_url('post-new.php?post_type=vip_collectible')).'">Add Collectible</a></div><!-- /wp:button --></div><!-- /wp:buttons --></div><!-- /wp:column --></div><!-- /wp:columns --></div><!-- /wp:group -->'; $id=wp_insert_post(array('post_type'=>'page','post_title'=>'VIPSVault Home','post_content'=>$hero,'post_status'=>'publish')); update_option('show_on_front','page'); update_option('page_on_front',$id); }
    $vip_id=wp_insert_post(array('post_type'=>'vip','post_title'=>'Jack Nicholson','post_content'=>'A demo VIP wiki profile for movies, famous names, and memorabilia listings.','post_status'=>'publish','post_excerpt'=>'Academy Award-winning actor and screen icon.'));
    if($vip_id && !is_wp_error($vip_id)){ wp_set_object_terms($vip_id,'Movies','vip_category'); update_post_meta($vip_id,'_vip_full_name','Jack Nicholson'); update_post_meta($vip_id,'_vip_birth','April 22, 1937'); update_post_meta($vip_id,'_vip_birthplace','Neptune City, New Jersey'); update_post_meta($vip_id,'_vip_died',''); update_post_meta($vip_id,'_vip_profession','Actor / Filmmaker'); update_post_meta($vip_id,'_vip_active_years','1950s–2010s'); update_post_meta($vip_id,'_vip_memorabilia_top','Paste your memorabilia shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson memorabilia" item_count="4"]'); update_post_meta($vip_id,'_vip_ebay_keywords_top','Jack Nicholson memorabilia'); update_post_meta($vip_id,'_vip_ebay_keywords_bottom','Jack Nicholson cards memorabilia'); update_post_meta($vip_id,'_vip_ebay_item_count','4'); update_post_meta($vip_id,'_vip_bio','Jack Nicholson is one of the most recognizable actors in modern film history, known for intense performances, dark humor, and iconic screen presence.'); update_post_meta($vip_id,'_vip_accomplishments', wp_json_encode(array(array('title'=>'Academy Award Winner','summary'=>'Add major awards, records, career milestones, championships, albums, films, or cultural moments here.','api'=>'Paste memorabilia API shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson Oscar memorabilia"]')))); update_post_meta($vip_id,'_vip_news', wp_json_encode(array(array('title'=>'Latest Collecting Interest','summary'=>'Add news items, market interest, auctions, card releases, or memorabilia updates here.','api'=>'Paste news memorabilia API shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson autograph"]')))); update_post_meta($vip_id,'_vip_memorabilia_bottom','Paste bottom memorabilia API shortcode here. Example: [vipsvault_ebay keywords="Jack Nicholson cards memorabilia"]'); }
    $cid=wp_insert_post(array('post_type'=>'vip_collectible','post_title'=>'Jack Nicholson Signed Movie Icon Card','post_content'=>'Demo related collectible connected to the Jack Nicholson VIP page.','post_status'=>'publish','post_excerpt'=>'Related VIP collectible demo.')); if($cid){ wp_set_object_terms($cid,array('Celebrities','Movies & TV'),'collectible_category'); update_post_meta($cid,'_vv_person_name','Jack Nicholson'); update_post_meta($cid,'_vv_profession','Actor'); update_post_meta($cid,'_vv_team_role','Movies'); update_post_meta($cid,'_vv_year','1980'); update_post_meta($cid,'_vv_brand','VIPSVault Demo Series'); update_post_meta($cid,'_vv_card_number','VIP-JN-01'); update_post_meta($cid,'_vv_condition','Near Mint'); update_post_meta($cid,'_vv_grade','Raw'); update_post_meta($cid,'_vv_price','250'); update_post_meta($cid,'_vv_related_vip','jack-nicholson'); }
    foreach(array(array('1975','Movie','One Flew Over the Cuckoo’s Nest','A rebellious patient clashes with institutional control in one of Nicholson’s defining performances.'),array('1980','Movie','The Shining','A psychological horror classic featuring one of the most famous performances in movie history.'),array('1989','Movie','Batman','Nicholson brought a bold, theatrical version of the Joker to a blockbuster comic-book film.')) as $m){ $pid=wp_insert_post(array('post_type'=>'vip_career','post_title'=>$m[2],'post_content'=>$m[3],'post_status'=>'publish')); if($pid){ update_post_meta($pid,'_career_year',$m[0]); update_post_meta($pid,'_career_type',$m[1]); update_post_meta($pid,'_career_vip_slug','jack-nicholson'); update_post_meta($pid,'_career_summary',$m[3]); update_post_meta($pid,'_career_memorabilia','Paste career item memorabilia API shortcode here. Example: [vipsvault_ebay keywords="'.$m[2].' Jack Nicholson card"]'); }}
    $menu=wp_create_nav_menu('VIPSVault Main Menu'); if(!is_wp_error($menu)){ wp_update_nav_menu_item($menu,0,array('menu-item-title'=>'Home','menu-item-url'=>home_url('/'),'menu-item-status'=>'publish')); wp_update_nav_menu_item($menu,0,array('menu-item-title'=>'Collectibles','menu-item-url'=>get_post_type_archive_link('vip_collectible'),'menu-item-status'=>'publish')); wp_update_nav_menu_item($menu,0,array('menu-item-title'=>'VIPS','menu-item-url'=>(function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip')),'menu-item-status'=>'publish')); $loc=get_theme_mod('nav_menu_locations'); $loc['primary']=$menu; set_theme_mod('nav_menu_locations',$loc); }
    update_option('vipsvault_vips_demo_imported',current_time('mysql')); flush_rewrite_rules();
}
add_action('after_switch_theme','vipsvault_demo_content');

/* WordPress menu support: map the header nav to Appearance > Menus without overwriting user edits. */
function vipsvault_primary_menu_fallback(){
    echo '<ul class="primary-menu">';
    echo '<li><a href="'.esc_url(home_url('/')).'">Home</a></li>';
    echo '<li><a href="'.esc_url(get_post_type_archive_link('vip_collectible')).'">Collectibles</a></li>';
    echo '<li><a href="'.esc_url((function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip'))).'">VIPS</a></li>';
    $about = get_page_by_title('About VIPSVault');
    if($about){ echo '<li><a href="'.esc_url(get_permalink($about)).'">About</a></li>'; }
    $blog = get_page_by_title('Blog');
    if($blog){ echo '<li><a href="'.esc_url(get_permalink($blog)).'">Blog</a></li>'; }
    echo '</ul>';
}
function vipsvault_get_or_create_page($title, $content=''){
    $page = get_page_by_title($title);
    if($page) return $page->ID;
    return wp_insert_post(array('post_type'=>'page','post_title'=>$title,'post_content'=>$content,'post_status'=>'publish'));
}
function vipsvault_ensure_primary_menu_mapping(){
    vipsvault_default_terms();
    $menu = wp_get_nav_menu_object('VIPSVault Main Menu');
    if(!$menu){
        $menu_id = wp_create_nav_menu('VIPSVault Main Menu');
        if(is_wp_error($menu_id)) return;
    } else {
        $menu_id = $menu->term_id;
    }

    $items = wp_get_nav_menu_items($menu_id);
    if(empty($items)){
        $about_id = vipsvault_get_or_create_page('About VIPSVault','<h2>The Vault for Iconic Collectibles</h2><p>VIPSVault.com showcases sports cards, celebrity cards, music legends, movie icons, autographs, graded collectibles, and memorabilia.</p>');
        $blog_id  = vipsvault_get_or_create_page('Blog','');
        wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'Home','menu-item-url'=>home_url('/'),'menu-item-status'=>'publish'));
        wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'Collectibles','menu-item-url'=>get_post_type_archive_link('vip_collectible'),'menu-item-status'=>'publish'));
        wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'VIPS','menu-item-url'=>(function_exists('vipsvault_vips_archive_url') ? vipsvault_vips_archive_url() : get_post_type_archive_link('vip')),'menu-item-status'=>'publish'));
        if($about_id && !is_wp_error($about_id)) wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'About','menu-item-url'=>get_permalink($about_id),'menu-item-status'=>'publish'));
        if($blog_id && !is_wp_error($blog_id)) wp_update_nav_menu_item($menu_id,0,array('menu-item-title'=>'Blog','menu-item-url'=>get_permalink($blog_id),'menu-item-status'=>'publish'));
    }

    $locations = get_theme_mod('nav_menu_locations');
    if(!is_array($locations)) $locations = array();
    if(empty($locations['primary'])){
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
    update_option('vipsvault_nav_mapping_version','5');
}
add_action('after_switch_theme','vipsvault_ensure_primary_menu_mapping',30);
add_action('admin_init', function(){
    if(get_option('vipsvault_nav_mapping_version') !== '5'){
        vipsvault_ensure_primary_menu_mapping();
    }
});

/* VIPS archive/single rewrite hardening: keeps /vips/ as main VIPS directory and /vips/person-name/ as VIP profiles. */
function vipsvault_vips_rewrite_rules(){
    add_rewrite_rule('^vips/category/([^/]+)/?$', 'index.php?vip_category=$matches[1]', 'top');
    add_rewrite_rule('^vips/page/([0-9]+)/?$', 'index.php?post_type=vip&paged=$matches[1]', 'top');
    add_rewrite_rule('^vips/([^/]+)/?$', 'index.php?vip=$matches[1]', 'top');
    add_rewrite_rule('^vips/?$', 'index.php?post_type=vip', 'top');
}
add_action('init','vipsvault_vips_rewrite_rules',30);

function vipsvault_flush_rewrites_for_vips_fix(){
    $version = 'vips-directory-fix-1';
    if(get_option('vipsvault_rewrite_version') !== $version){
        flush_rewrite_rules(false);
        update_option('vipsvault_rewrite_version', $version);
    }
}
add_action('admin_init','vipsvault_flush_rewrites_for_vips_fix');
add_action('after_switch_theme','vipsvault_flush_rewrites_for_vips_fix',50);

function vipsvault_vips_archive_url(){
    return home_url('/vips/');
}

/* VIPSVault category fallback images and VIP age helper */
function vipsvault_category_fallback_image_url($post_id = null){
    $post_id = $post_id ?: get_the_ID();
    $type = get_post_type($post_id);
    $taxonomy = ($type === 'vip') ? 'vip_category' : 'collectible_category';
    $terms = get_the_terms($post_id, $taxonomy);
    $slugs = array();
    if($terms && !is_wp_error($terms)){
        foreach($terms as $term){ $slugs[] = strtolower($term->slug); $slugs[] = strtolower($term->name); }
    }
    $map = array(
        'baseball'=>'category-baseball.svg','football'=>'category-football.svg','basketball'=>'category-basketball.svg','hockey'=>'category-hockey.svg','golf'=>'category-golf.svg',
        'movies'=>'category-movies.svg','movies-tv'=>'category-movies.svg','movie'=>'category-movies.svg','tv'=>'category-tv.svg','music'=>'category-music.svg',
        'celebrities'=>'category-celebrity.svg','celebrity'=>'category-celebrity.svg','autographs'=>'category-autograph.svg','autograph'=>'category-autograph.svg',
        'memorabilia'=>'category-memorabilia.svg','rookie-cards'=>'category-basketball.svg','graded-cards'=>'category-memorabilia.svg','sports'=>'category-basketball.svg'
    );
    foreach($map as $needle=>$file){
        if(in_array($needle, $slugs, true)) return get_template_directory_uri().'/assets/'.$file;
    }
    return get_template_directory_uri().'/assets/category-default.svg';
}
function vipsvault_post_image_html($post_id = null, $alt = ''){
    $post_id = $post_id ?: get_the_ID();
    if(has_post_thumbnail($post_id)) return get_the_post_thumbnail($post_id, 'large', array('alt'=>$alt ?: get_the_title($post_id)));
    return '<img src="'.esc_url(vipsvault_category_fallback_image_url($post_id)).'" alt="'.esc_attr($alt ?: get_the_title($post_id)).'">';
}
function vipsvault_calculate_vip_age($born, $died = ''){
    if(!$born) return '';
    try { $birth = new DateTime($born); } catch(Exception $e) { $birth = date_create($born); }
    if(!$birth) return '';
    if($died){
        try { $end = new DateTime($died); } catch(Exception $e) { $end = date_create($died); }
    } else { $end = new DateTime('now'); }
    if(!$end || $end < $birth) return '';
    return (string)$birth->diff($end)->y;
}

require_once get_template_directory() . '/inc/ebay-partner-api.php';
