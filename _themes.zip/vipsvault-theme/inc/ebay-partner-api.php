<?php
if(!defined('ABSPATH')) exit;

/**
 * VIPSVault eBay Partner Network / Browse API Memorabilia Integration
 * Adds Appearance > VIPSVault eBay API settings, VIP keyword fields,
 * shortcode [vipsvault_ebay keywords="frank sinatra memorabilia" item_count="4"],
 * cached eBay Browse API Search results with affiliate tracking URLs.
 */
function vipsvault_ebay_default_options(){
    return array(
        'client_id' => '', // App ID / Client ID
        'dev_id' => '', // Dev ID is stored for completeness; Browse API OAuth does not send it.
        'client_secret' => '', // Cert ID / Client Secret
        'campaign_id' => '',
        'custom_id' => 'vipsvault',
        'marketplace_id' => 'EBAY_US',
        'endpoint' => 'https://api.ebay.com',
        'cache_hours' => 12,
        'debug' => 1,
        'fallback_links' => 1,
        'last_error' => '',
        'last_test' => '',
    );
}
function vipsvault_ebay_options(){
    $saved = get_option('vipsvault_ebay_options', array());
    return wp_parse_args(is_array($saved) ? $saved : array(), vipsvault_ebay_default_options());
}
function vipsvault_ebay_admin_menu(){
    add_theme_page('VIPSVault eBay API', 'VIPSVault eBay API', 'manage_options', 'vipsvault-ebay-api', 'vipsvault_ebay_settings_page');
}
add_action('admin_menu','vipsvault_ebay_admin_menu');
function vipsvault_ebay_register_settings(){
    register_setting('vipsvault_ebay_group', 'vipsvault_ebay_options', 'vipsvault_ebay_sanitize_options');
}
add_action('admin_init','vipsvault_ebay_register_settings');
function vipsvault_ebay_sanitize_options($input){
    $defaults = vipsvault_ebay_default_options();
    $out = array();
    $out['client_id'] = sanitize_text_field($input['client_id'] ?? '');
    $out['dev_id'] = sanitize_text_field($input['dev_id'] ?? '');
    $out['client_secret'] = sanitize_text_field($input['client_secret'] ?? '');
    $out['campaign_id'] = sanitize_text_field($input['campaign_id'] ?? '');
    $out['custom_id'] = sanitize_text_field($input['custom_id'] ?? 'vipsvault');
    $out['marketplace_id'] = sanitize_text_field($input['marketplace_id'] ?? $defaults['marketplace_id']);
    $out['endpoint'] = esc_url_raw($input['endpoint'] ?? $defaults['endpoint']);
    $out['cache_hours'] = max(1, min(72, intval($input['cache_hours'] ?? 12)));
    $out['debug'] = !empty($input['debug']) ? 1 : 0;
    $out['fallback_links'] = !empty($input['fallback_links']) ? 1 : 0;
    $out['last_error'] = sanitize_textarea_field($input['last_error'] ?? '');
    $out['last_test'] = sanitize_text_field($input['last_test'] ?? '');
    delete_transient('vipsvault_ebay_oauth_token');
    return $out;
}
function vipsvault_ebay_settings_page(){
    if(!current_user_can('manage_options')) return;
    $o = vipsvault_ebay_options();
    if(isset($_POST['vipsvault_ebay_clear_cache']) && check_admin_referer('vipsvault_ebay_tools')){
        delete_transient('vipsvault_ebay_oauth_token');
        echo '<div class="notice notice-success"><p>eBay token cache cleared.</p></div>';
    }
    if(isset($_POST['vipsvault_ebay_diagnostic']) && check_admin_referer('vipsvault_ebay_tools')){
        delete_transient('vipsvault_ebay_oauth_token');
        $diag = vipsvault_ebay_safe_oauth_diagnostic();
        echo '<div class="notice notice-info"><p><strong>Safe eBay OAuth Diagnostic</strong></p>';
        echo '<table style="margin:8px 0 12px;border-collapse:collapse">';
        foreach($diag as $label => $value){
            echo '<tr><td style="padding:4px 18px 4px 0;font-weight:600">'.esc_html($label).'</td><td><code>'.esc_html((string)$value).'</code></td></tr>';
        }
        echo '</table><p><em>No Client Secret or OAuth token is displayed by this diagnostic.</em></p></div>';
        $o = vipsvault_ebay_options();
    }
    if(isset($_POST['vipsvault_ebay_test']) && check_admin_referer('vipsvault_ebay_tools')){
        delete_transient('vipsvault_ebay_oauth_token');
        $test_keywords = sanitize_text_field($_POST['vv_test_keywords'] ?? 'Frank Sinatra memorabilia');
        $test = vipsvault_ebay_search_items($test_keywords, 1, true);
        if(is_wp_error($test)){
            $msg = $test->get_error_message();
            vipsvault_ebay_store_last_error($msg);
            echo '<div class="notice notice-error"><p><strong>eBay test failed:</strong> '.esc_html($msg).'</p></div>';
        } else {
            echo '<div class="notice notice-success"><p>eBay test successful. Returned '.count($test).' item(s).</p></div>';
        }
        $o = vipsvault_ebay_options();
    }
    ?>
    <div class="wrap">
        <h1>VIPSVault eBay API</h1>
        <p>Connect eBay Buy Browse API and eBay Partner Network so VIP pages can display affiliate memorabilia products. Use <code>[vipsvault_ebay keywords="frank sinatra memorabilia" item_count="4"]</code> in any memorabilia field.</p>
        <div class="notice notice-info"><p><strong>Use your three eBay Developer keys here:</strong> App ID goes in Client ID, Dev ID goes in Dev ID, and Cert ID goes in Client Secret. The modern Browse API uses App ID + Cert ID to create an OAuth app token; Dev ID is saved in the settings but is mainly for legacy APIs.</p></div>
        <form method="post" action="options.php">
            <?php settings_fields('vipsvault_ebay_group'); ?>
            <table class="form-table" role="presentation">
                <tr><th scope="row"><label for="vv_ebay_client_id">App ID / Client ID</label></th><td><input class="regular-text" id="vv_ebay_client_id" name="vipsvault_ebay_options[client_id]" value="<?php echo esc_attr($o['client_id']); ?>"><p class="description">Paste your eBay App ID here. Use Production keys, not Sandbox keys, for live eBay.com results.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_dev_id">Dev ID</label></th><td><input class="regular-text" id="vv_ebay_dev_id" name="vipsvault_ebay_options[dev_id]" value="<?php echo esc_attr($o['dev_id'] ?? ''); ?>"><p class="description">Stored for your eBay keyset. The Buy Browse API token flow does not send this field, but keeping it here makes your keyset complete.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_client_secret">Cert ID / Client Secret</label></th><td><input class="regular-text" type="password" id="vv_ebay_client_secret" name="vipsvault_ebay_options[client_secret]" value="<?php echo esc_attr($o['client_secret']); ?>"><p class="description">Paste your eBay Cert ID here. It must be from the same Production keyset as the App ID.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_campaign_id">ePN Campaign ID</label></th><td><input class="regular-text" id="vv_ebay_campaign_id" name="vipsvault_ebay_options[campaign_id]" value="<?php echo esc_attr($o['campaign_id']); ?>" placeholder="10 digit campaign ID"><p class="description">This is your eBay Partner Network campid. It is not your App ID.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_custom_id">Affiliate Reference ID / Custom ID</label></th><td><input class="regular-text" id="vv_ebay_custom_id" name="vipsvault_ebay_options[custom_id]" value="<?php echo esc_attr($o['custom_id']); ?>" placeholder="vipsvault"><p class="description">Optional tracking label. eBay calls this customid / SUB-ID.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_marketplace">Marketplace ID</label></th><td><input class="regular-text" id="vv_ebay_marketplace" name="vipsvault_ebay_options[marketplace_id]" value="<?php echo esc_attr($o['marketplace_id']); ?>" placeholder="EBAY_US"><p class="description">Examples: EBAY_US, EBAY_GB, EBAY_CA, EBAY_AU.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_endpoint">API Endpoint</label></th><td><input class="regular-text" id="vv_ebay_endpoint" name="vipsvault_ebay_options[endpoint]" value="<?php echo esc_attr($o['endpoint']); ?>" placeholder="https://api.ebay.com"><p class="description">Live: https://api.ebay.com. Sandbox: https://api.sandbox.ebay.com.</p></td></tr>
                <tr><th scope="row"><label for="vv_ebay_cache">Cache Hours</label></th><td><input type="number" min="1" max="72" id="vv_ebay_cache" name="vipsvault_ebay_options[cache_hours]" value="<?php echo esc_attr($o['cache_hours']); ?>"></td></tr>
                <tr><th scope="row">Debug Errors</th><td><label><input type="checkbox" name="vipsvault_ebay_options[debug]" value="1" <?php checked($o['debug'],1); ?>> Show detailed API errors to admins</label></td></tr>
                <tr><th scope="row">Fallback Search Links</th><td><label><input type="checkbox" name="vipsvault_ebay_options[fallback_links]" value="1" <?php checked($o['fallback_links'],1); ?>> If API fails, show a direct eBay search button instead of a blank section</label></td></tr>
                <input type="hidden" name="vipsvault_ebay_options[last_error]" value="<?php echo esc_attr($o['last_error']); ?>">
                <input type="hidden" name="vipsvault_ebay_options[last_test]" value="<?php echo esc_attr($o['last_test']); ?>">
            </table>
            <?php submit_button('Save eBay API Settings'); ?>
        </form>
        <hr>
        <h2>Test Connection</h2>
        <form method="post">
            <?php wp_nonce_field('vipsvault_ebay_tools'); ?>
            <p><input class="regular-text" name="vv_test_keywords" value="Frank Sinatra memorabilia"> <button class="button button-primary" name="vipsvault_ebay_test" value="1">Run eBay API Test</button> <button class="button" name="vipsvault_ebay_diagnostic" value="1">Run Safe OAuth Diagnostic</button> <button class="button" name="vipsvault_ebay_clear_cache" value="1">Clear Token Cache</button></p>
        </form>
        <?php if(!empty($o['last_error'])): ?><h2>Last eBay Error</h2><textarea class="large-text code" rows="5" readonly><?php echo esc_textarea($o['last_error']); ?></textarea><?php endif; ?>
        <h2>Shortcode Examples</h2>
        <p><code>[vipsvault_ebay keywords="Frank Sinatra memorabilia" item_count="4"]</code></p>
        <p><code>[vipsvault_ebay keywords="Harry Potter cards" item_count="6" title="Harry Potter on eBay"]</code></p>
    </div>
    <?php
}
function vipsvault_ebay_store_last_error($message){
    $o = vipsvault_ebay_options();
    $o['last_error'] = wp_strip_all_tags((string)$message);
    $o['last_test'] = current_time('mysql');
    update_option('vipsvault_ebay_options', $o, false);
}
function vipsvault_ebay_error_to_message($error){
    if(!is_wp_error($error)) return '';
    return $error->get_error_message();
}
function vipsvault_ebay_affiliate_search_url($keywords){
    $o = vipsvault_ebay_options();
    $url = 'https://www.ebay.com/sch/i.html?_nkw=' . rawurlencode($keywords);
    if(!empty($o['campaign_id'])){
        $url .= '&mkevt=1&mkcid=1&mkrid=711-53200-19255-0&campid=' . rawurlencode($o['campaign_id']) . '&toolid=10001';
        if(!empty($o['custom_id'])) $url .= '&customid=' . rawurlencode($o['custom_id']);
    }
    return $url;
}
function vipsvault_ebay_is_configured(){
    $o = vipsvault_ebay_options();
    return !empty($o['client_id']) && !empty($o['client_secret']);
}
function vipsvault_ebay_safe_oauth_diagnostic(){
    $o = vipsvault_ebay_options();
    $raw_client_id = (string)($o['client_id'] ?? '');
    $raw_client_secret = (string)($o['client_secret'] ?? '');
    $client_id = trim($raw_client_id);
    $client_secret = trim($raw_client_secret);
    $endpoint = rtrim(trim((string)($o['endpoint'] ?? '')), '/');
    $token_url = $endpoint . '/identity/v1/oauth2/token';

    $diag = array(
        'API endpoint' => $endpoint ?: '(empty)',
        'Environment' => stripos($endpoint, 'sandbox') !== false ? 'Sandbox' : (stripos($endpoint, 'api.ebay.com') !== false ? 'Production' : 'Custom / check endpoint'),
        'Client ID present' => $client_id !== '' ? 'YES' : 'NO',
        'Client ID length' => strlen($client_id),
        'Client ID prefix' => $client_id !== '' ? substr($client_id, 0, min(8, strlen($client_id))) . '…' : '(empty)',
        'Client ID outer whitespace removed' => strlen($raw_client_id) !== strlen($client_id) ? 'YES - resave/copy carefully' : 'NO',
        'Client Secret present' => $client_secret !== '' ? 'YES' : 'NO',
        'Client Secret length' => strlen($client_secret),
        'Client Secret outer whitespace removed' => strlen($raw_client_secret) !== strlen($client_secret) ? 'YES - resave/copy carefully' : 'NO',
        'Dev ID present' => !empty(trim((string)($o['dev_id'] ?? ''))) ? 'YES (not used for OAuth)' : 'NO (not required for OAuth)',
        'Token URL' => $token_url,
    );

    if($client_id === '' || $client_secret === ''){
        $diag['OAuth request'] = 'NOT SENT - Client ID or Client Secret is empty';
        return $diag;
    }

    $response = wp_remote_post($token_url, array(
        'timeout' => 20,
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($client_id . ':' . $client_secret),
            'Content-Type' => 'application/x-www-form-urlencoded',
            'Accept' => 'application/json',
        ),
        'body' => http_build_query(array(
            'grant_type' => 'client_credentials',
            'scope' => 'https://api.ebay.com/oauth/api_scope',
        )),
    ));

    if(is_wp_error($response)){
        $diag['OAuth request'] = 'WORDPRESS HTTP ERROR';
        $diag['WordPress error'] = $response->get_error_message();
        return $diag;
    }

    $code = wp_remote_retrieve_response_code($response);
    $raw_body = wp_remote_retrieve_body($response);
    $body = json_decode($raw_body, true);
    $diag['OAuth HTTP status'] = $code;

    if($code >= 200 && $code < 300 && !empty($body['access_token'])){
        $diag['OAuth result'] = 'SUCCESS - eBay accepted Client ID + Client Secret';
        $diag['Token returned'] = 'YES (hidden)';
        $diag['Expires in'] = !empty($body['expires_in']) ? intval($body['expires_in']) . ' seconds' : 'not provided';
    } else {
        $diag['OAuth result'] = 'FAILED - eBay rejected or could not authenticate the request';
        $diag['eBay error'] = isset($body['error']) ? sanitize_text_field($body['error']) : 'unknown';
        $diag['eBay description'] = isset($body['error_description']) ? sanitize_text_field($body['error_description']) : wp_strip_all_tags(substr($raw_body, 0, 300));
        if($code === 401 && isset($body['error']) && $body['error'] === 'invalid_client'){
            $diag['Likely cause'] = 'Production/Sandbox key mismatch, incorrect App ID/Cert ID pair, disabled Production keyset, or a copied credential mismatch.';
        }
    }

    return $diag;
}
function vipsvault_ebay_get_token(){
    $o = vipsvault_ebay_options();
    $cached = get_transient('vipsvault_ebay_oauth_token');
    if($cached) return $cached;
    if(!vipsvault_ebay_is_configured()) return new WP_Error('not_configured','eBay API is not configured. Add App ID / Client ID and Cert ID / Client Secret in Appearance > VIPSVault eBay API.');
    $url = trailingslashit(trim((string)$o['endpoint'])) . 'identity/v1/oauth2/token';
    $client_id = trim((string)$o['client_id']);
    $client_secret = trim((string)$o['client_secret']);
    $response = wp_remote_post($url, array(
        'timeout' => 20,
        'headers' => array(
            'Authorization' => 'Basic ' . base64_encode($client_id . ':' . $client_secret),
            'Content-Type' => 'application/x-www-form-urlencoded',
        ),
        'body' => http_build_query(array('grant_type'=>'client_credentials','scope'=>'https://api.ebay.com/oauth/api_scope')),
    ));
    if(is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);
    if($code < 200 || $code >= 300 || empty($body['access_token'])){
        $err = new WP_Error('token_failed', 'eBay OAuth failed: HTTP '.$code.' '.wp_remote_retrieve_body($response)); vipsvault_ebay_store_last_error($err->get_error_message()); return $err;
    }
    $ttl = max(300, intval($body['expires_in'] ?? 7200) - 300);
    set_transient('vipsvault_ebay_oauth_token', $body['access_token'], $ttl);
    return $body['access_token'];
}
function vipsvault_ebay_search_items($keywords, $limit = 4, $force = false){
    $o = vipsvault_ebay_options();
    $keywords = trim((string)$keywords);
    $limit = max(1, min(20, intval($limit)));
    if($keywords === '') return new WP_Error('missing_keywords','No eBay keywords were provided.');
    $cache_key = 'vv_ebay_' . md5(strtolower($keywords).'|'.$limit.'|'.$o['marketplace_id'].'|'.$o['campaign_id'].'|v2');
    $cached = get_transient($cache_key);
    if(!$force && $cached !== false) return $cached;
    $token = vipsvault_ebay_get_token();
    if(is_wp_error($token)){ vipsvault_ebay_store_last_error($token->get_error_message()); return $token; }
    $url = trailingslashit($o['endpoint']) . 'buy/browse/v1/item_summary/search?' . http_build_query(array('q'=>$keywords,'limit'=>$limit));
    $headers = array(
        'Authorization' => 'Bearer ' . $token,
        'X-EBAY-C-MARKETPLACE-ID' => $o['marketplace_id'],
        'Accept' => 'application/json',
    );
    if(!empty($o['campaign_id'])){
        $ctx = 'affiliateCampaignId=' . rawurlencode($o['campaign_id']);
        if(!empty($o['custom_id'])) $ctx .= ',affiliateReferenceId=' . rawurlencode($o['custom_id']);
        $headers['X-EBAY-C-ENDUSERCTX'] = $ctx;
    }
    $response = wp_remote_get($url, array('timeout'=>20, 'headers'=>$headers));
    if(is_wp_error($response)) return $response;
    $code = wp_remote_retrieve_response_code($response);
    $raw = wp_remote_retrieve_body($response);
    $body = json_decode($raw, true);
    if($code < 200 || $code >= 300){ $err = new WP_Error('search_failed', 'eBay Search failed: HTTP '.$code.' '.$raw); vipsvault_ebay_store_last_error($err->get_error_message()); return $err; }
    $items = isset($body['itemSummaries']) && is_array($body['itemSummaries']) ? $body['itemSummaries'] : array();
    set_transient($cache_key, $items, HOUR_IN_SECONDS * intval($o['cache_hours']));
    return $items;
}
function vipsvault_ebay_keyword_variations($keywords){
    $keywords = trim(wp_strip_all_tags((string)$keywords));
    $base = $keywords;
    $variations = array();
    if($base !== '') $variations[] = $base;
    foreach(array('memorabilia','autograph','signed photo','trading card','collectible','card') as $suffix){
        if($base && stripos($base, $suffix) === false) $variations[] = trim($base . ' ' . $suffix);
    }
    return array_values(array_unique(array_filter($variations)));
}
function vipsvault_ebay_search_with_fallbacks($keywords, $limit = 4){
    $searched = array();
    $last_error = null;
    foreach(vipsvault_ebay_keyword_variations($keywords) as $term){
        $items = vipsvault_ebay_search_items($term, $limit);
        $searched[] = array('term'=>$term, 'count'=>is_wp_error($items) ? 'error' : count($items));
        if(is_wp_error($items)){ $last_error = $items; break; }
        if(!empty($items)) return array('items'=>$items, 'used_term'=>$term, 'searched'=>$searched, 'error'=>null);
    }
    return array('items'=>array(), 'used_term'=>$keywords, 'searched'=>$searched, 'error'=>$last_error);
}
function vipsvault_ebay_render_products($keywords, $limit = 4, $title = 'eBay Memorabilia'){
    $o = vipsvault_ebay_options();
    $result = vipsvault_ebay_search_with_fallbacks($keywords, $limit);
    $items = $result['items'];
    echo '<section class="ebay-memorabilia-box api-box"><h2>'.esc_html($title).'</h2>';
    if(is_wp_error($result['error'])){
        $message = current_user_can('manage_options') && !empty($o['debug']) ? $result['error']->get_error_message() : 'eBay API request failed. Check the eBay API settings.';
        echo '<p class="vv-ebay-error">'.esc_html($message).'</p>';
        if(!empty($o['fallback_links'])){
            echo '<p><a class="btn btn-primary" target="_blank" rel="nofollow sponsored noopener" href="'.esc_url(vipsvault_ebay_affiliate_search_url($keywords)).'">Search '.esc_html($keywords).' on eBay</a></p>';
        }
        if(current_user_can('manage_options') && !empty($o['debug'])) vipsvault_ebay_debug_output($result);
        echo '</section>'; return;
    }
    if(empty($items)){
        echo '<p class="meta-line">No eBay memorabilia found for this search.</p>';
        if(!empty($o['fallback_links'])) echo '<p><a class="btn btn-primary" target="_blank" rel="nofollow sponsored noopener" href="'.esc_url(vipsvault_ebay_affiliate_search_url($keywords)).'">Search '.esc_html($keywords).' on eBay</a></p>';
        if(current_user_can('manage_options') && !empty($o['debug'])) vipsvault_ebay_debug_output($result);
        echo '</section>'; return;
    }
    if(current_user_can('manage_options') && !empty($o['debug'])) vipsvault_ebay_debug_output($result);
    echo '<div class="ebay-products-grid">';
    foreach($items as $item){
        $url = $item['itemAffiliateWebUrl'] ?? ($item['itemWebUrl'] ?? '#');
        $image = $item['image']['imageUrl'] ?? '';
        $item_title = $item['title'] ?? 'eBay item';
        $price = '';
        if(!empty($item['price']['value'])) $price = ($item['price']['currency'] ?? 'USD') . ' ' . $item['price']['value'];
        echo '<a class="ebay-product-card" target="_blank" rel="nofollow sponsored noopener" href="'.esc_url($url).'">';
        if($image) echo '<img src="'.esc_url($image).'" alt="'.esc_attr($item_title).'">';
        echo '<span class="ebay-title">'.esc_html($item_title).'</span>';
        if($price) echo '<strong class="ebay-price">'.esc_html($price).'</strong>';
        echo '<span class="ebay-button">View on eBay</span></a>';
    }
    echo '</div></section>';
}
function vipsvault_ebay_debug_output($result){
    echo '<details class="vv-ebay-debug"><summary>eBay Debug</summary><ul>';
    foreach($result['searched'] as $row){
        echo '<li><strong>'.esc_html($row['term']).'</strong>: '.esc_html((string)$row['count']).' result(s)</li>';
    }
    echo '</ul></details>';
}
function vipsvault_ebay_shortcode($atts){
    $atts = shortcode_atts(array('keywords'=>'','item_count'=>'4','title'=>'eBay Memorabilia'), $atts, 'vipsvault_ebay');
    ob_start(); vipsvault_ebay_render_products($atts['keywords'], intval($atts['item_count']), $atts['title']); return ob_get_clean();
}
add_shortcode('vipsvault_ebay','vipsvault_ebay_shortcode');
add_shortcode('ebay_search','vipsvault_ebay_shortcode');
function vipsvault_vip_ebay_box($position, $post_id){
    $keywords = get_post_meta($post_id, $position === 'top' ? '_vip_ebay_keywords_top' : '_vip_ebay_keywords_bottom', true);
    if(!$keywords) $keywords = get_the_title($post_id) . ' memorabilia';
    $count = intval(get_post_meta($post_id, '_vip_ebay_item_count', true));
    if($count < 1) $count = 4;
    $title = $position === 'top' ? 'Featured eBay Memorabilia' : 'More eBay Memorabilia';
    vipsvault_ebay_render_products($keywords, $count, $title);
}
