<?php get_header(); ?>
<main class="single-wrap vip-single">
    <?php while(have_posts()): the_post(); $slug = get_post_field('post_name', get_the_ID()); ?>
    <div class="container single-grid">
        <aside>
            <div class="feature-image">
                <?php echo function_exists('vipsvault_post_image_html') ? vipsvault_post_image_html(get_the_ID(), 'VIPSVault VIP profile') : (has_post_thumbnail() ? get_the_post_thumbnail(get_the_ID(), 'large') : '<img src="'.esc_url(get_template_directory_uri().'/assets/vipsvault-logo.png').'" alt="VIPSVault VIP profile">'); ?>
            </div>
            <?php if(function_exists('vv_api_box')) vv_api_box('Featured Memorabilia', vv_meta('_vip_memorabilia_top')); ?>
            <?php if(function_exists('vipsvault_vip_ebay_box')) vipsvault_vip_ebay_box('top', get_the_ID()); ?>
        </aside>
        <article class="detail-panel vip-wiki">
            <div class="kicker">VIP Profile</div>
            <h1><?php echo esc_html(vv_meta('_vip_full_name') ?: get_the_title()); ?></h1>
            <?php $terms = get_the_terms(get_the_ID(), 'vip_category'); if($terms && !is_wp_error($terms)): ?>
                <div class="cat-pills vip-page-cats"><?php foreach($terms as $term) echo '<a href="'.esc_url(get_term_link($term)).'">'.esc_html($term->name).'</a>'; ?></div>
            <?php endif; ?>
            <div class="stats">
                <?php
                $stat_fields = array('Born'=>'_vip_birth','Died'=>'_vip_died');
                foreach($stat_fields as $label=>$key){ $value = vv_meta($key); if($value) echo '<div class="stat"><b>'.esc_html($label).'</b>'.esc_html(function_exists('vipsvault_format_vip_date') ? vipsvault_format_vip_date($value) : $value).'</div>'; }
                $age = function_exists('vipsvault_calculate_vip_age') ? vipsvault_calculate_vip_age(vv_meta('_vip_birth'), vv_meta('_vip_died')) : '';
                if($age){ echo '<div class="stat"><b>'.(vv_meta('_vip_died') ? 'Age at Death' : 'Age').'</b>'.esc_html($age).'</div>'; }
                $extra_stat_fields = array('Birthplace'=>'_vip_birthplace','Profession'=>'_vip_profession','Active Years'=>'_vip_active_years');
                foreach($extra_stat_fields as $label=>$key){ $value = vv_meta($key); if($value) echo '<div class="stat"><b>'.esc_html($label).'</b>'.esc_html($value).'</div>'; }
                ?>
            </div>

            <nav class="wiki-nav tabs">
                <a href="#bio">Bio</a>
                <a href="#accomplishments">Accomplishments</a>
                <a href="#career">Career Items</a>
                <a href="#news">News</a>
                <a href="#memorabilia">Memorabilia</a>
                <a href="#related-collectibles">Related Collectibles</a>
            </nav>

            <section id="bio" class="wiki-section">
                <h2>Bio</h2>
                <div class="content-box">
                    <?php
                    $bio = vv_meta('_vip_bio');
                    if($bio){ echo wpautop(wp_kses_post($bio)); }
                    elseif(trim(get_the_content())){ the_content(); }
                    else { echo '<p class="meta-line">No bio has been added yet. Edit this VIP and add a Bio Section or main page content.</p>'; }
                    ?>
                </div>
                <?php edit_post_link('Edit this VIP', '<p class="edit-link-wrap">', '</p>'); ?>
            </section>

            <div id="accomplishments">
                <?php if(function_exists('vv_repeater_section')) vv_repeater_section('Accomplishments', '_vip_accomplishments'); ?>
            </div>

            <section id="career" class="wiki-section">
                <h2>Career Items</h2>
                <p class="meta-line">Movies, TV shows, albums, teams, events, roles, seasons, and major career entries.</p>
                <div class="career-list">
                <?php
                $career = new WP_Query(array(
                    'post_type'=>'vip_career',
                    'posts_per_page'=>50,
                    'meta_query'=>array(array('key'=>'_career_vip_slug','value'=>$slug,'compare'=>'=')),
                    'meta_key'=>'_career_year',
                    'orderby'=>'meta_value_num',
                    'order'=>'ASC'
                ));
                if($career->have_posts()): while($career->have_posts()): $career->the_post(); ?>
                    <a class="career-card" href="<?php the_permalink(); ?>">
                        <div class="career-year"><?php echo esc_html(get_post_meta(get_the_ID(),'_career_year',true)); ?></div>
                        <div>
                            <h3><?php the_title(); ?></h3>
                            <p class="meta-line"><?php echo esc_html(get_post_meta(get_the_ID(),'_career_type',true)); ?><?php $role = get_post_meta(get_the_ID(),'_career_role',true); echo $role ? ' — '.esc_html($role) : ''; ?></p>
                        </div>
                    </a>
                <?php endwhile; wp_reset_postdata(); else: ?>
                    <p class="meta-line">No career items added yet. Add items from Dashboard &gt; VIP Career Items, then use this VIP slug: <strong><?php echo esc_html($slug); ?></strong>.</p>
                <?php endif; ?>
                </div>
            </section>

            <div id="news">
                <?php if(function_exists('vv_repeater_section')) vv_repeater_section('News', '_vip_news'); ?>
            </div>

            <div id="memorabilia">
                <?php if(function_exists('vv_api_box')) vv_api_box('Bottom Memorabilia', vv_meta('_vip_memorabilia_bottom')); ?>
                <?php if(function_exists('vipsvault_vip_ebay_box')) vipsvault_vip_ebay_box('bottom', get_the_ID()); ?>
            </div>

            <?php if(function_exists('vipsvault_related_collectibles')) vipsvault_related_collectibles(get_the_ID()); ?>
        </article>
    </div>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
